# Reviewing a sample of annotations (`sk.py review`)

    PY sk.py review project.synp [--size 30] [--seed 1] [--focus X] [--strata S] [--open]  # draw + review/index.html
    PY sk.py review project.synp --sample ID                       # rebuild the page of a sample
    PY sk.py review project.synp --import FILE [FILE...]           # one file per rater; prints the report
    PY sk.py review project.synp --report [--sample ID]
    PY sk.py review project.synp --corrections [--sample ID]       # review/corrections-<sample>.md

## The sample

- The script draws it, never you nor the researcher: stratified by group (sklib/sample.py), at least
  one annotation per group, the rest in proportion to the group, seed recorded.
- It is **frozen** in `runs/audit/samples/<id>.json`: each annotation is stored as it was when drawn
  (its Synesis block, its values, the excerpt in its source). The page always shows that copy. If the
  project changes later, the page marks the annotations that changed and the report counts them.
- Size: 30 by default. Explain it simply: with no rejection in 30 judged, the rejection rate *of what
  the sample represents* is below 10% with 95% confidence (rule of three); about 96 give ±10 points.
  Small projects: review everything (`--size` above the number of annotations).

## The page

- It asks only what a person must judge (codes, chains, notes, categories); the excerpt is checked
  by the computer and shown as a seal, with the excerpt in its source context.
- Blind: model and run are not shown.
- Verdict with keys 1/2/3 (approved, rejected, doubt); optional 1-5 scale per field; for rejections
  and doubts a reason mapped to the triage classes (SKILL.md §5) and a note; optionally the block as
  the researcher thinks it should be (**proposed correction**).
- Each rater name has its own session in the browser, empty at the start: a colleague on the same
  computer never inherits someone else's answers.
- Stopping rule: if many of the first 20 are rejected, the page suggests stopping and doing the
  triage first; a template change usually fixes several at once, then draw a new sample.
- **Export for the coordinator**: one Markdown file (`<project>-review-<sample>-<rater>.md`) with a
  line for people, instructions for the AI that will read it, the summary, every judged annotation
  (block as reviewed, verdict, reason, note, proposed correction) and a data block for `--import`.

## Several researchers, one coordinator

1. The coordinator (with Claude) draws the sample and sends `review/index.html` to each researcher.
   The page works offline on any computer; it contains excerpts of the sources, so send it only to
   people allowed to read them.
2. Each researcher judges on their own computer, writes their name, and exports. They send the `.md`
   file to the coordinator (they can also give it to their own AI: the instructions in the file tell
   it not to apply anything).
3. The coordinator gives the files to Claude: `--import A.md B.md C.md`. The import refuses files of
   another sample, judgements of annotations outside the sample, and annotations judged twice in the
   same file; importing the same rater again replaces the earlier file.
4. `--corrections` writes `review/corrections-<sample>.md`: per annotation with a rejection, a doubt
   or a proposal, every rater's verdict and reason, where they disagree, the block as reviewed, the
   current block if it changed, and each proposed correction, plus the instructions for the AI.
5. Go through it with the coordinator. Corrections are **proposals**: apply one only after the
   coordinator approves it, keep QUOTATION values word for word, check that the block is still the
   same in the project, record each edit (`sk.py decide --type manual_edit --item ID --note ...`),
   then `sk.py validate` and `sk.py anchor`. When the same reason repeats, prefer a template change
   and a new run (triage) to many hand edits.

## The report

- Per rater: approved / rejected / doubt; the **rejection observed in the sample** with the Wilson
  95% interval *of the sample*; the rule of three when nothing was rejected; reasons; groups;
  proposals; mean of each scale.
- `weighted_by_group`: an estimate for the whole project, each group's observed rate weighted by the
  group's size, without an interval. Say plainly that the sample over-represents small groups (at
  least one per group), so the observed rate is not the rate of the project.
- With two or more raters: percent agreement, Cohen's kappa (first two raters), Krippendorff's alpha
  (all raters). Disagreements are material for refining the template, not errors to hide.
- Doubts are for the conversation: go through them with the researcher.

## Confidentiality

The page and the exported files contain excerpts and their source context. In modality B generate
the page and give the path, never open it, nor the exported files, nor the corrections file; the
report prints counts only. `sk.py marks` (older versions) is kept only to import old files.
