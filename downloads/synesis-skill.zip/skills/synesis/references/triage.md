# Triage before correction

A wrong annotation does not always mean a wrong template. Rewriting GUIDELINES
to fix one case can make others worse. Classify first, propose the class to the
researcher, record the confirmed class, then act.

| Class (`--class`) | Signals | What to do |
|---|---|---|
| `ambiguous_instruction` | same error in several sources; the model follows one possible reading of the GUIDELINES | new template version (record why) → re-code the audited sample → keep the change only if the sample did not get worse |
| `model_failure` | isolated error; the GUIDELINES are clear | re-run that source (new run), record it |
| `source_conversion` | truncated text, mixed columns, broken hyphenation | fix the text in `fontes/`, re-run that source |
| `interpretive_divergence` | the researcher disagrees but the reading is defensible | the researcher decides; record it; change the template only if they want the criterion changed for every source |

Record: `sk.py decide project.synp --type triage --class <class> --item <id> --note "<why>"`.

## Audited sample

The researcher's marks in the dashboard (correct / wrong / doubt + note), exported
and imported with `sk.py marks`, form the audited sample. After any template
change, re-code the sources of that sample and compare with the marks.

Quality is measured against the audited sample: correct codes, pertinent
quotations, relations the sources sustain. Compiling, having GUIDELINES in every
field and anchored quotations are **necessary** conditions, never evidence that
the interpretation is adequate.

## Hand edits

Only when the researcher asks. Record them
(`--type manual_edit --item <id> --note ...`). The dashboard flags every file
changed after acceptance; the record explains why.
