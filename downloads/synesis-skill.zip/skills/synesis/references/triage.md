# Triage before correction

A wrong annotation does not always mean a wrong template. Rewriting GUIDELINES
to fix one case can make others worse. Classify first, propose the class to the
researcher, record the confirmed class, then act.

| Class (`--class`) | Signals | What to do |
|---|---|---|
| `ambiguous_instruction` | same error in several sources; the model follows one possible reading of the GUIDELINES | new template version (record why) → re-code the audited sample → keep the change only if the sample did not get worse |
| `model_failure` | isolated error; the GUIDELINES are clear | re-run that source (new run), record it |
| `source_conversion` | truncated text, mixed columns, broken hyphenation | fix the text in `fontes/`, re-run that source |
| `interpretive_divergence` | the researcher disagrees but the reading is defensible | the researcher decides; record it; change the template only if they want the criterion changed for every source |

Record: `sk.py decide project.synp --type triage --class <class> --item <id> --note "<why>"`.

## Audited sample

The review sample (`sk.py review`, SKILL.md §4b) is the audited sample: drawn by the
script, stratified, frozen in `runs/audit/samples/`, judged on the review page
(approved / rejected / doubt, reason, note) and imported with `sk.py review --import`.
The reasons the researcher chose are a first proposal of the class above; confirm it
with them before recording it. Corrections proposed on the review page (one or several
raters, `sk.py review --corrections`) are proposals too: apply one only after the
coordinator approves it, and record it as `manual_edit`; a reason that repeats points
to the template, not to many edits (see `references/review.md`). After any template change, re-code the sources of
that sample, rebuild its page (`--sample ID`) and compare the new judgements with
the old ones. Draw a new sample only to estimate the quality of the new version.

Quality is measured against the audited sample: correct codes, pertinent
quotations, relations the sources sustain. Compiling, having GUIDELINES in every
field and anchored quotations are **necessary** conditions, never evidence that
the interpretation is adequate.

## Hand edits

Only when the researcher asks. Record them
(`--type manual_edit --item <id> --note ...`). The dashboard flags every file
changed after acceptance; the record explains why.
