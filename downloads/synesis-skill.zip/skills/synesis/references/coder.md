# Running synesis-coder through the skill

`sk.py code` runs the coder's own modes (document, abstract, ontology) as a
library. The coder builds every prompt from the template and validates every
answer; the skill only decides *who answers* and *records everything* in
`runs/<id>/`.

## Run record

| Path | Content |
|---|---|
| `manifest.json` | versions, backend, model, mode, target, project state before the run, input hashes, outputs, status |
| `inputs/` | the source exactly as sent (raw copy + cleaned text, or the single .bib entry) |
| `requests/`, `responses/` | every request and answer, including correction rounds |
| `calls.jsonl` | API calls (api backend) |
| `output/` | what the run produced; `accept` copies it into the project |
| `runs/decisions.jsonl` | human decisions: template approval, acceptance, triage, corrections |

`runs/` is research data: version it. Request ids hash everything that
determines the answer; an answer can never be applied to a different request.
If the project changes while a run is pending or before it is accepted, the run
becomes `stale` and must be started again; `accept` also refuses outputs whose
hash differs from the manifest. Anchoring compares each accepted file with the
source text of the run that produced it.

## Backends

**api**: the coder calls the model from the `.env` settings
(`SYNESIS_CODER_BACKEND`, `SYNESIS_CODER_API_URL`, `SYNESIS_CODER_API_KEY`,
`SYNESIS_CODER_MODEL`; OpenRouter + Sonnet 5.5 needs `SYNESIS_CODER_REASONING_EFFORT=low`).
Create the `.env` with empty values and let the researcher paste the key into the
file. Never ask for a key in the chat. Use `--env-file` only for a file the researcher points to.

**handoff**: no API key; the researcher's own Claude Code session answers. This is
ordinary use of Claude Code by its subscriber: the coder never touches
credentials. Loop:

1. `sk.py code ... --backend handoff --model "<your model id> (Claude Code session)"`
2. For each pending `runs/<id>/requests/<rid>.md`, launch a **fresh subagent**
   (general-purpose) with exactly this prompt:

   > You are acting as the language model for one request of a qualitative-coding
   > tool. Read the file `<run>/requests/<rid>.md` and answer it exactly as it
   > instructs, as an API model would: follow its SYSTEM and USER sections, use only
   > the source text inside it, and add no commentary. Then write ONLY your raw
   > answer (no markdown fences, nothing else) with the Write tool to
   > `<run>/responses/<rid>.txt`. Do not read or modify any other file. Reply "done".

   Never answer requests yourself in the main conversation: you know the
   project, the researcher's hopes and earlier answers; an API call does not.
   Independent requests can go to subagents in parallel. For many small requests
   (ontology: one per concept) a subagent may take a group, told to treat each
   request on its own; prefer one per request when quality matters most.
3. `sk.py code project.synp --run <id>`: repeat 2-3 until `complete`.

Typical passes: document 2-3, abstract 2, ontology 2. Responses that end up
unused (a free-text fallback answered before the JSON answer existed) are listed
in the manifest as `unused_responses`; they are harmless and stay in the record.

Not yet measured: whether a handoff answer matches an API answer from the same
model (the request reaches the subagent inside Claude Code's own system prompt).
The skill's proof compared different models only.

## Reproducibility (tell the researcher)

- **Re-running the protocol** (same template, same pipeline, same validator)
  gives *similar*, not identical, annotations: model inference is not deterministic.
- **Reconstructing a recorded run** gives *these* annotations, analytic JSON,
  reports and dashboard byte for byte: `sk.py rebuild project.synp --out <dir>`
  (tested from a copy in another folder).

## Issues of older versions the skill still guards against

The installers pin synesis 0.16.0 and synesis-coder 0.15.1, which fix these. The skill detects
the installed version and only applies the guards below with older ones:

- Before synesis 0.16.0, an empty `.syno` does not compile, so `synesis-coder ontology` cannot
  create a first ontology. During `sk.py code --mode ontology` only, empty content is treated as
  "no blocks".
- Before synesis 0.16.0, continuation lines of field values are dropped by the compiler
  (`sk.py check` lists them; see `template_design.md`).
- Before synesis-coder 0.15.1, `anchor` skips sources without an abstract and checks only the
  first QUOTATION field. `sk.py anchor` is still the one to use: it reads the sources from the
  inputs of the run that produced each accepted file.
