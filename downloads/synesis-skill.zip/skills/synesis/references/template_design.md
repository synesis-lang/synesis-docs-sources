# Writing a template the coder and the researcher can share

The template is the method. synesis-coder sends each field's DESCRIPTION and
GUIDELINES to the model; anyone who receives the project runs the same
instructions. A field without GUIDELINES is coded by improvisation (the coder
falls back to the DESCRIPTION alone, or to nothing).

## Rules

- **GUIDELINES in every field**, including fields filled by hand (they document the
  criterion for the human who decides). `sk.py check` blocks coding otherwise.
- **One atomic instruction per field**: what to extract, what not to, in what form.
- **Correct / Wrong pairs** instead of dense prose; rules that prose loses, a pair keeps.
- **Examples from another topic**, never from the sources to be coded (the model copies them).
- **No `#` inside GUIDELINES**: there a comment reaches the model. Use `#` only for section titles.
- **No language keyword at the start of a GUIDELINES line** (Include, Topic, Item,
  Source, Field, End, Bundle...). The parser alters such lines; `sk.py check` lists them.
- **DESCRIPTION defines, GUIDELINES instruct.** The coder sends both.
- **One-line values in hand-written .syn/.syno** when the compiler is older than 0.16.0:
  synesis 0.13.4–0.15.0 silently drop indented continuation lines, and `sk.py check` lists them.
  From 0.16.0 (the version the installers pin) a value may continue on indented lines.

## Project file

    PROJECT name
    TEMPLATE "template.synt"
    INCLUDE BIBLIOGRAPHY "referencias.bib"
    INCLUDE ANNOTATIONS "anotacoes"        # a folder: runs add one file per source
    INCLUDE ONTOLOGY "ontologia"           # a folder: an empty .syno file does not compile
    DESCRIPTION
    One paragraph on the project; the coder sends it to the model.
    END DESCRIPTION
    QUESTIONS
        Q1: ...
    END QUESTIONS
    EXPORT JSON
        OUTPUT "saida/name.json"
        GENERATED_AT "2026-01-01T00:00:00Z"   # fixed: exports become reproducible
    END EXPORT
    END PROJECT

## Choosing field types

Ask what the researcher wants to read at the end, then map:

| They want | Field type |
|---|---|
| the exact words of the source | QUOTATION |
| an analytic memo | MEMO |
| free or emerging codes | CODE (concepts defined later in the ontology) |
| relations stated by the source (cause, enables, restricts) | CHAIN with ARITY and RELATIONS |
| a closed list of categories | ENUMERATED with VALUES |
| an ordered scale with labels | ORDERED |
| a number in a range | SCALE with FORMAT |
| a theme that groups concepts | TOPIC (ontology scope) |

Check each type with `synesis help-field <TYPE>` and `PY sk.py help --lookup TYPE_<TYPE>`;
search anything else with `PY sk.py help <words>` (see `help.md`).

**Start from a case study.** `PY sk.py help --category case_study` lists nine complete
projects adapted from real research (literature review with epistemic status, factors
with sign and condition, a term across passages, news framing, linked assessments,
survey answers, topical index as SKOS, participatory diagnosis, causation coding).
Copy the closest one and adapt its vocabulary; its code compiles.

**Language of the template.** Keywords stay English. DESCRIPTION, GUIDELINES, value
descriptions, QUESTIONS and DESCRIPTION of the project are written in the researcher's
language (SKILL.md §0b); field names and values may be too (`snake_case`, no spaces,
preferably no accents).

A complete, small, working example: `SKILL_DIR/examples/prova/template.synt` (fictitious sources; copy it as a starting point).
