# Confidentiality modalities

Everything you (Claude) read leaves the researcher's machine: a source file you
open, the output of a command that prints quotations, a dashboard you inspect.
Choosing Ollama for the coder does not change what *you* read. Declare the
modality before opening any source, and get the researcher's agreement.

| Modality | You read | Coder | Guarantee you may state |
|---|---|---|---|
| A, cloud | sources, annotations, diagnostics | API or handoff | none about locality: data goes to Anthropic, and with the API also to the chosen provider |
| B, reduced exposure | methodology, template, fictitious examples, counts | Ollama (local) | the skill does not send the sources; the flow is **not** fully local |
| C, local | nothing; you do not take part | Ollama, run by the researcher (VS Code + `@synesis`) | fully local processing |

## Rules for modality B

- Never open `fontes/`, `anotacoes/`, `.syno`, `runs/*/requests|responses`, or the dashboard.
- Redirect command output you do not need into files you do not read; from the
  terminal take only counts and exit codes. Compiler diagnostics can quote field
  values: do not read them in full.
- The handoff backend is unavailable (it sends the sources to you by design).
- Write the template with fictitious examples only.
- The researcher audits alone, in the dashboard.

Say it plainly: B reduces exposure but a procedural slip (a printed quotation, a
file opened by mistake) exposes data. For data under strict legal or ethical
confidentiality, recommend C before starting.
