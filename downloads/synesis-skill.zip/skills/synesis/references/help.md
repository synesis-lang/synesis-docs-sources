# synesis-help for agents

`synesis-help` is the reference guide of the language, installed in the same
environment as the compiler. Its generated entries are derived from that
compiler, so it is the source to trust over memory or the static
`language.md`. It is English-only; translate when you relay it.

## Commands (JSON contract)

    PY sk.py help <words>                 # = synesis-help search <words> --format=json
    PY sk.py help --lookup <ID or term>   # = synesis-help lookup <term> --format=json
    PY sk.py help --category <name>       # = synesis-help list --category <name> --format=json

Or call `synesis-help` directly through the `bin` path the installer printed.

- Every answer has `help_version`, `synesis_version` and `locale`. If
  `synesis_version` is older than `synesis --version`, say the guide may lag.
- `lookup` accepts short forms (`E047`, `chain`, `export`) and returns
  `match` (`id`, `title`, `prefix`, `search`). With `found: false` it returns
  `suggestions`: try one of them before giving up.
- Exit codes: 0 found, 1 not found, 2 usage error.

## What to look up, when

| Situation | Query |
|---|---|
| choosing a design for a new project | `--category case_study`, then `--lookup CASE_...` |
| writing a field of a given type | `--lookup TYPE_<TYPE>` |
| a compiler diagnostic | `--lookup SYNESIS_E0NN` |
| qualifying claims (status, sign, condition) | `help bundle status`, `--lookup MOD_BUNDLE` |
| records in TOML instead of typed metadata | `--lookup MOD_ON_BIBLIOGRAPHY` |
| linking projects | `--lookup GUIDE_MULTIPROJECT` |
| taxonomy, synonyms, SKOS | `--lookup MOD_ROLE`, `--lookup BLOCK_EXPORT` |
| fine-tuning data that keeps the status | `--lookup BLOCK_EXPORT` (ALPACA) |

## Case studies

Nine complete projects (template, annotations, ontology, `.synp`, exports)
adapted from real research, with fictitious names and excerpts. Each one is
compiled by the guide's own checks, so its code is valid for the installed
compiler. To start a project from a case:

1. Read the case (`--lookup CASE_...`) and show the researcher its research
   question and "Design decisions" in their language.
2. Copy the code blocks: the first line of each block is its file name.
3. Rename fields and values to the researcher's vocabulary, rewrite the
   GUIDELINES with pairs from their material, then `PY sk.py check`.
