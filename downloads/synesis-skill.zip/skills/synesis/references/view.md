# The project view (`sk.py view`)

One offline page, read-only, at `view/index.html`, built from the project itself: field names, types,
scopes, relations and values come from the template; nothing is tied to a particular template. It
shows only the files the `.synp` includes (its template and its `INCLUDE` lines); copies kept in the
folder (backups, tests) are counted in a note, not shown. A `.synp` without `INCLUDE` shows the whole
folder.

## Tabs

- **Overview** (*Resumo* in Portuguese): title, description, research questions; corpus size; a
  *validation and review* strip (compiler errors and warnings in plain words, excerpts not located in
  the source, files changed since acceptance, runs awaiting acceptance); the concepts matrix (by
  source, or by group in a large project), whose cells open the occurrences.
- **Your sources**: formats, PDF instructions and the inventory of the inbox (SKILL.md §1b); it opens
  first while nothing is coded.
- **Where to start**: the next steps for this project, computed from its state, and how to cite
  Synesis.
- One tab per kind of file (awaiting acceptance, project, template, ontology, annotations,
  references): every block is a card with its line, its problems, where it came from (accepted in run
  N, changed since acceptance, written by hand) and an **Ask Claude** button.
- **Possibilities**: research intentions (compare, connect, organize, support an interpretation)
  mapped to Synesis features, with what this project already has and a request to adapt.

Hovering a word of the language (SCOPE, TYPE, END ITEM...) explains it in plain words.

## Large projects: breadth and depth

After breadth-and-depth analysis (Weller, Davidson, Edwards and Jamieson, *Big Qual: A Guide to
Breadth-and-Depth Analysis*, Palgrave Macmillan, 2023). Counts, the concepts matrix and the problems
always cover the **whole** project; only the cards are selected. A banner says what the page shows,
with requests for more and the time of a complete view.

| Depth | Shows | Default for |
|---|---|---|
| `overview` (panoramic; aerial survey) | template and `.synp` whole; one source drawn from each of the **eight largest groups at most** (5 sources when there are no groups); the 8 most used ontology blocks, 4 used once | `large` |
| `sample` (test pits) | 30 sources drawn in every group in proportion to its size, at least 2 per group (`--sources N`); 20 most used, 10 rare and 10 random ontology blocks | `medium` |
| `full` (deep excavation) | everything; with `--focus`, one group, source or concept read whole (a concept brings the 10 concepts that appear most with it) | `small` |

- **Groups**: the folders of the annotations when there are two or more, otherwise the first SOURCE
  field with closed values (ENUMERATED or ORDERED); `--strata FIELD|folder|none` changes it. In a
  project with groups and more than 16 sources the matrix is **concepts by group**.
- Draws use `--seed` (default 1): the same project gives the same page.
- Blocks with a problem (error, warning, excerpt not found, edit after acceptance) are shown outside
  the selection, **up to 40**, marked "outside the selection"; beyond that they stay listed in the
  validation strip, with their file and line.
- `--depth`, `--focus`, `--seed`, `--strata` and `--sources` are kept in `view/view-settings.json` for
  the automatic refreshes; `--depth auto` goes back to the size of the project. The command prints
  depth, size class, sources shown, groups and page size.
- A complete view of a large project is slow to build and heavy to open: give the time and size from
  `sk.py size` first; to dig, suggest `--focus` on a group or concept.

## Requests pasted from the view

*Ask Claude* and *Copy request to adapt* copy a request that the researcher pastes into the
conversation. They name the project, the file and the line, quote the compiler message, and end with
"do not change any file before I approve". Treat them as the researcher's own request: read the file
at that line (in modality B, do not: explain from the diagnostic and let the researcher look),
explain in plain language, propose the change and wait for approval. When the problem is in a
`.syn`, propose its class first (SKILL.md §5). Requests from *Possibilities* ask you to clarify the
intention first; follow §2 (template design) for any change.

## Language

The page follows, in this order: the `project_language` decision (SKILL.md §0b),
`SYNESIS_CODER_LANGUAGE` in the project `.env`, the language of the latest coder run, the project's
own prose (never the excerpts, which are in the language of the source), then the operating system.
`sk.py view` prints the language and where it came from; `--lang en|pt|es|fr|de|it|zh` forces it for
one build. Other languages fall back to English. Only the interface is translated.

## Confidentiality

It reads the Synesis, `.bib` and `.toml` files and compiles the project; to say whether each excerpt
is located in its source it runs the same check as `sk.py anchor`. In **modality B** generate it and
give the path, but do not open it. It never changes the project and loads nothing from the network.
