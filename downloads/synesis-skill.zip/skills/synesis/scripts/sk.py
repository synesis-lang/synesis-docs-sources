#!/usr/bin/env python
"""synesis-skill command line. Run it with the Python of the Synesis tool environment:

    <python> sk.py <command> [options]

Commands
    doctor                       versions and environment
    check     PROJECT            GUIDELINES in every field; multi-line values (compiler drops them)
    validate  PROJECT [--out F]  diagnostics as JSON (never blocks on errors)
    anchor    PROJECT [--out F] [--literal]
    code      PROJECT --backend api|handoff --mode document|abstract|ontology --target KEY
              [--input FILE] [--model M] [--env-file F] [--run ID] [--language L]
    accept    PROJECT --run ID [--note TEXT]
    decide    PROJECT --type TYPE [--class C] [--item ID] [--run ID] --note TEXT
    marks     PROJECT --import FILE
    dashboard PROJECT [--out FILE]
    rebuild   PROJECT --out DIR   regenerate analytic, validation, anchoring and dashboard
    runs      PROJECT            list runs and their status
    locale    [PROJECT]          language of the environment and of the project (JSON)
    help      WORDS...           search synesis-help (JSON); --lookup ID for one entry
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

# Request ids hash the coder's prompts; prompts that iterate over sets would
# change between processes without a fixed hash seed.
if os.environ.get("PYTHONHASHSEED") != "0":
    env = dict(os.environ, PYTHONHASHSEED="0", PYTHONIOENCODING="utf-8")
    raise SystemExit(subprocess.call([sys.executable, *sys.argv], env=env))

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sklib import anchor as anchor_mod  # noqa: E402
from sklib import dashboard as dash  # noqa: E402
from sklib import runs  # noqa: E402
from sklib.common import read_json, write_json  # noqa: E402
from sklib.project import check_template, compile_project, find_continuation_lines  # noqa: E402


def _p(path: str) -> Path:
    p = Path(path).resolve()
    if not p.exists():
        raise SystemExit(f"error: {path} not found")
    return p


def cmd_doctor(_: argparse.Namespace) -> int:
    import importlib.metadata as md
    import shutil

    print(f"python          {sys.executable}")
    for pkg in ("synesis", "synesis-coder", "synesis-help"):
        try:
            print(f"{pkg:<15} {md.version(pkg)}")
        except md.PackageNotFoundError:
            print(f"{pkg:<15} NOT INSTALLED")
    for exe in ("uv", "synesis", "synesis-coder", "synesis-help"):
        print(f"{exe + ' (PATH)':<15} {shutil.which(exe) or 'not on PATH'}")
    return 0


def cmd_check(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    t = check_template(synp)
    cont = find_continuation_lines(synp)
    print(f"template fields: {t.get('fields', 0)}")
    for m in t["missing"]:
        print(f"  MISSING GUIDELINES  {m['field']} ({m['type']}, {m['scope']})")
    for x in t["altered"]:
        print(f"  ALTERED BY PARSER   {x['field']}: {x['line']}")
    for c in cont:
        print(f"  MULTI-LINE VALUE    {c['file']}:{c['line']}  (synesis drops this line) {c['text']}")
    ok = t["ok"] and not cont
    print("OK" if ok else "NOT OK")
    return 0 if ok else 1


def cmd_validate(a: argparse.Namespace) -> int:
    c = compile_project(_p(a.project))
    v = c["validation"]
    if a.out:
        write_json(Path(a.out), v)
    for d in v["diagnostics"]:
        print(f"{d['file']}:{d['line']}:{d['column']}  [{d['severity'].upper()}]  {d['code']}")
    print(f"errors={v['errors']} warnings={v['warnings']} ready={v['ready']}")
    return 0 if v["ready"] else 1


def cmd_anchor(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    c = compile_project(synp)
    r = anchor_mod.check(synp.parent, c["analytic"] or {}, c["state"]["state"], literal=a.literal)
    if a.out:
        write_json(Path(a.out), r)
    for x in r["results"]:
        if x["status"] != "found":
            print(f"  {x['status'].upper():<13} {x['item']} [{x['field']}] {x['excerpt'][:70]}")
    s = r["summary"]
    print(f"mode={r['mode']} found={s['found']} not_found={s['not_found']} "
          f"unverifiable={s['unverifiable']} verified={r['verified']}")
    return 0 if r["verified"] else 1


def cmd_code(a: argparse.Namespace) -> int:
    m = runs.code(_p(a.project), a.backend, a.mode, a.target,
                  input_path=_p(a.input) if a.input else None, model=a.model,
                  env_file=_p(a.env_file) if a.env_file else None, run_id=a.run,
                  concurrent=a.concurrent, language=a.language)
    print(f"run {m['id']}: {m['status']} (pass {m.get('passes')})")
    for p in m.get("pending", []):
        print(f"  pending  runs/{m['id']}/{p}")
    if m.get("error"):
        print(f"  error: {m['error']}")
    return {"complete": 0, "accepted": 0, "pending": 3}.get(m["status"], 1)


def cmd_locale(a: argparse.Namespace) -> int:
    from sklib import locale as loc

    print(json.dumps(loc.report(_p(a.project) if a.project else None), ensure_ascii=False, indent=2))
    return 0


def cmd_help(a: argparse.Namespace) -> int:
    """synesis-help through the same environment, so the guide matches the compiler."""
    import shutil

    exe = shutil.which("synesis-help") or str(Path(sys.executable).parent / "synesis-help")
    if a.lookup:
        argv = [exe, "lookup", a.lookup, "--format=json"]
    elif a.words:
        argv = [exe, "search", *a.words, "--format=json"]
    else:
        argv = [exe, "list", "--format=json"] + (["--category", a.category] if a.category else [])
    try:
        return subprocess.call(argv)
    except OSError:
        argv[0:1] = [sys.executable, "-m", "synesis_help.cli"]
        return subprocess.call(argv)


def cmd_accept(a: argparse.Namespace) -> int:
    m = runs.accept(_p(a.project), a.run, note=a.note or "")
    for f in m.get("accepted_files", {}):
        print(f"  accepted  {f}")
    return 0


def cmd_decide(a: argparse.Namespace) -> int:
    e = runs.decide(_p(a.project), a.type, note=a.note, triage_class=a.cls, item=a.item, run=a.run)
    print(f"recorded {e['type']}")
    return 0


def cmd_marks(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    data = read_json(_p(a.import_file))
    target = runs.runs_dir(synp) / "audit" / "marks.json"
    write_json(target, dash.normalize_marks(data))
    runs.decide(synp, "import_marks", note=f"imported {len(data.get('marks', []))} marks",
                file=str(target.relative_to(synp.parent).as_posix()))
    print(f"imported into {target.relative_to(synp.parent).as_posix()}")
    return 0


def cmd_dashboard(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    out = Path(a.out) if a.out else synp.parent / "dashboard" / "dashboard.html"
    info = dash.build(synp, out)
    print(f"dashboard: {out}  ({info['bytes']:,} bytes)  ready={info['ready']}  stale={info['stale']}")
    return 0


def cmd_rebuild(a: argparse.Namespace) -> int:
    hashes = dash.rebuild(_p(a.project), Path(a.out))
    for name, h in hashes.items():
        print(f"{h}  {name}")
    return 0


def cmd_runs(a: argparse.Namespace) -> int:
    for m in runs.list_runs(_p(a.project)):
        print(f"{m['id']:<32} {m['status']:<9} {m['backend']:<8} {m.get('model')}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="sk", description="synesis-skill helpers")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor").set_defaults(fn=cmd_doctor)
    for name, fn in (("check", cmd_check), ("runs", cmd_runs)):
        s = sub.add_parser(name)
        s.add_argument("project")
        s.set_defaults(fn=fn)
    s = sub.add_parser("validate"); s.add_argument("project"); s.add_argument("--out")
    s.set_defaults(fn=cmd_validate)
    s = sub.add_parser("anchor"); s.add_argument("project"); s.add_argument("--out")
    s.add_argument("--literal", action="store_true"); s.set_defaults(fn=cmd_anchor)
    s = sub.add_parser("code"); s.add_argument("project")
    s.add_argument("--backend", choices=["api", "handoff"], default="handoff")
    s.add_argument("--mode", choices=list(runs.MODES), default="document")
    s.add_argument("--target", default="ontology"); s.add_argument("--input")
    s.add_argument("--model"); s.add_argument("--env-file"); s.add_argument("--run")
    s.add_argument("--concurrent", type=int, default=3)
    s.add_argument("--language", help='output language of the coder, e.g. "Brazilian Portuguese"')
    s.set_defaults(fn=cmd_code)
    s = sub.add_parser("locale"); s.add_argument("project", nargs="?"); s.set_defaults(fn=cmd_locale)
    s = sub.add_parser("help"); s.add_argument("words", nargs="*")
    s.add_argument("--lookup"); s.add_argument("--category"); s.set_defaults(fn=cmd_help)
    s = sub.add_parser("accept"); s.add_argument("project"); s.add_argument("--run", required=True)
    s.add_argument("--note"); s.set_defaults(fn=cmd_accept)
    s = sub.add_parser("decide"); s.add_argument("project"); s.add_argument("--type", required=True)
    s.add_argument("--class", dest="cls",
                   choices=["ambiguous_instruction", "model_failure", "source_conversion",
                            "interpretive_divergence"])
    s.add_argument("--item"); s.add_argument("--run"); s.add_argument("--note", required=True)
    s.set_defaults(fn=cmd_decide)
    s = sub.add_parser("marks"); s.add_argument("project")
    s.add_argument("--import", dest="import_file", required=True); s.set_defaults(fn=cmd_marks)
    s = sub.add_parser("dashboard"); s.add_argument("project"); s.add_argument("--out")
    s.set_defaults(fn=cmd_dashboard)
    s = sub.add_parser("rebuild"); s.add_argument("project"); s.add_argument("--out", required=True)
    s.set_defaults(fn=cmd_rebuild)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
