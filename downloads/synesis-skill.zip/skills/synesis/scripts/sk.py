#!/usr/bin/env python
# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""synesis-skill command line. Run it with the Python of the Synesis tool environment:

    <python> sk.py <command> [options]

Commands
    doctor                       versions and environment
    check     PROJECT            GUIDELINES in every field; multi-line values (only for synesis < 0.16.0)
    validate  PROJECT [--out F]  diagnostics as JSON (never blocks on errors)
    anchor    PROJECT [--out F] [--literal]
    code      PROJECT --backend api|handoff --mode document|abstract|dataset|ontology --target KEY
              [--input FILE] [--model M] [--env-file F] [--run ID] [--language L]
    accept    PROJECT --run ID [--note TEXT]
    decide    PROJECT --type TYPE [--class C] [--item ID] [--run ID] --note TEXT
    marks     PROJECT --import FILE
    dashboard PROJECT [--out FILE] [--anyway]   results page; a large project is sent to the Synesis tools
    rebuild   PROJECT --out DIR   regenerate analytic, validation, anchoring and dashboard
    runs      PROJECT            list runs and their status
    size      PROJECT            size class, counts and the time of a complete view (no compiling)
    review    PROJECT [--size N] [--seed N] [--focus X] [--strata S] [--open]
                                 draw a sample of annotations and write review/index.html
              PROJECT --sample ID            rebuild the page of a sample (a second rater)
              PROJECT --import FILE...       import the reviews exported by the page (one per rater), and report
              PROJECT --report [--sample ID] observed and weighted rejection rate, reasons, agreement
              PROJECT --corrections [--sample ID]  every rater's proposals, for the coordinator (review/)
    view      PROJECT [--out DIR] [--lang L] [--open] [--depth auto|overview|sample|full]
              [--focus GROUP|SOURCE|CONCEPT] [--seed N] [--strata folder|FIELD|none] [--sources N]
                                 friendly offline HTML view of the Synesis files
    intake    FOLDER|PROJECT     inventory of the raw source files; [--lang L] [--names] [--open] [--inbox NAME]
              [--join]           joins NAME.p001-010.md, NAME.p011-020.md... (PDF converted in parts)
              PROJECT --apply [--keys name|neutral] [--prefix P] [--only FILE]...  prepare what was approved
    locale    [PROJECT]          language of the environment and of the project (JSON)
    help      WORDS...           search synesis-help (JSON); --lookup ID for one entry
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

# Request ids hash the coder's prompts; prompts that iterate over sets would
# change between processes without a fixed hash seed.
if os.environ.get("PYTHONHASHSEED") != "0":
    env = dict(os.environ, PYTHONHASHSEED="0", PYTHONIOENCODING="utf-8")
    raise SystemExit(subprocess.call([sys.executable, *sys.argv], env=env))

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sklib import anchor as anchor_mod  # noqa: E402
from sklib import dashboard as dash  # noqa: E402
from sklib import intake  # noqa: E402
from sklib import runs  # noqa: E402
from sklib import view as viewer  # noqa: E402
from sklib.common import read_json, write_json  # noqa: E402
from sklib.project import check_template, compile_project, find_continuation_lines  # noqa: E402


def _refresh_view(synp: Path) -> None:
    """Rebuild the friendly view after files change. A failure here never breaks a command."""
    try:
        print(f"view: {viewer.build_view(synp)}  (open it in a browser to read the files)")
    except Exception as exc:  # noqa: BLE001
        print(f"view: not updated ({type(exc).__name__}: {exc})")


def _p(path: str) -> Path:
    p = Path(path).resolve()
    if not p.exists():
        raise SystemExit(f"error: {path} not found")
    return p


def cmd_doctor(_: argparse.Namespace) -> int:
    import importlib.metadata as md
    import shutil

    print(f"python          {sys.executable}")
    for pkg in ("synesis", "synesis-coder", "synesis-help"):
        try:
            print(f"{pkg:<15} {md.version(pkg)}")
        except md.PackageNotFoundError:
            print(f"{pkg:<15} NOT INSTALLED")
    for exe in ("uv", "synesis", "synesis-coder", "synesis-help"):
        print(f"{exe + ' (PATH)':<15} {shutil.which(exe) or 'not on PATH'}")
    return 0


def cmd_check(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    t = check_template(synp)
    cont = find_continuation_lines(synp)
    print(f"template fields: {t.get('fields', 0)}")
    for m in t["missing"]:
        print(f"  MISSING GUIDELINES  {m['field']} ({m['type']}, {m['scope']})")
    for x in t["altered"]:
        print(f"  ALTERED BY PARSER   {x['field']}: {x['line']}")
    for c in cont:
        print(f"  MULTI-LINE VALUE    {c['file']}:{c['line']}  (synesis drops this line) {c['text']}")
    ok = t["ok"] and not cont
    print("OK" if ok else "NOT OK")
    _refresh_view(synp)
    return 0 if ok else 1


def cmd_validate(a: argparse.Namespace) -> int:
    c = compile_project(_p(a.project))
    v = c["validation"]
    if a.out:
        write_json(Path(a.out), v)
    for d in v["diagnostics"]:
        print(f"{d['file']}:{d['line']}:{d['column']}  [{d['severity'].upper()}]  {d['code']}")
    print(f"errors={v['errors']} warnings={v['warnings']} ready={v['ready']}")
    return 0 if v["ready"] else 1


def cmd_anchor(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    c = compile_project(synp)
    r = anchor_mod.check(synp.parent, c["analytic"] or {}, c["state"]["state"], literal=a.literal)
    if a.out:
        write_json(Path(a.out), r)
    for x in r["results"]:
        if x["status"] != "found":
            print(f"  {x['status'].upper():<13} {x['item']} [{x['field']}] {x['excerpt'][:70]}")
    s = r["summary"]
    print(f"mode={r['mode']} found={s['found']} not_found={s['not_found']} "
          f"unverifiable={s['unverifiable']} verified={r['verified']}")
    return 0 if r["verified"] else 1


def cmd_code(a: argparse.Namespace) -> int:
    m = runs.code(_p(a.project), a.backend, a.mode, a.target,
                  input_path=_p(a.input) if a.input else None, model=a.model,
                  env_file=_p(a.env_file) if a.env_file else None, run_id=a.run,
                  concurrent=a.concurrent, language=a.language)
    print(f"run {m['id']}: {m['status']} (pass {m.get('passes')})")
    for p in m.get("pending", []):
        print(f"  pending  runs/{m['id']}/{p}")
    if m.get("error"):
        print(f"  error: {m['error']}")
    if m["status"] in ("complete", "accepted"):
        _refresh_view(_p(a.project))      # the proposal appears under "Awaiting your acceptance"
    return {"complete": 0, "accepted": 0, "pending": 3}.get(m["status"], 1)


def cmd_view(a: argparse.Namespace) -> int:
    target = viewer.build_view(_p(a.project), Path(a.out) if a.out else None, a.lang, depth=a.depth,
                               focus=a.focus, seed=a.seed, strata=a.strata, sources=a.sources)
    lang, why = (a.lang, "--lang") if a.lang else viewer.page_language(_p(a.project))
    info = viewer.LAST
    print(f"view: {target}  (language: {lang}, from {why})")
    print(f"  depth={info['depth']} size={info['size']} sources_shown={info['shown']}/{info['total']} "
          f"groups={info['groups'] or 'none'} page_mb={info['page_mb']}"
          + (f" focus_matched={info['matched']}" if info["focus"] else "")
          + (f" outside_files={info['outside']}" if info["outside"] else ""))
    if info["focus"] and info["matched"] == "none":
        print("  focus: no group, source or concept has this name; the page shows nothing of the annotations")
    if a.open:
        viewer.open_in_browser(target)
    return 0


def cmd_review(a: argparse.Namespace) -> int:
    """Draw a sample of annotations and write the review page; import a review; report."""
    from sklib import review

    synp = _p(a.project)
    if a.import_file:
        for f in a.import_file:
            r = review.import_review(synp, _p(f))
            print(f"imported review of sample {r['sample']} by {r['rater']}: {len(r['judgments'])} judgments, "
                  f"{sum(1 for j in r['judgments'] if j['proposal'])} corrections proposed"
                  + (" (replaced this rater's earlier import)" if r["replaced"] else ""))
        a.report, a.sample = True, r["sample"]
    if a.corrections:
        lang = a.lang or viewer.page_language(synp)[0]
        path, n = review.corrections(synp, a.sample, review.LANGUAGE_NAMES.get(lang, "English"),
                                     Path(a.out) if a.out else None)
        print(f"corrections: {path}")
        print(f"  annotations={n['items']} proposals={n['proposals']} disagreements={n['disagreements']} "
              f"changed_since_draw={n['changed']}")
        return 0
    if a.report:
        rep = review.report(synp, a.sample)
        print(f"sample {rep['sample']}: {rep['size']} of {rep['population']} annotations"
              + (f"; {rep['changed_since_draw']} changed in the project since the draw" if rep["changed_since_draw"] else ""))
        for r in rep["raters"]:
            c = r["counts"]
            line = (f"  rater {r['rater']}: judged={r['judged']} approved={c['approved']} rejected={c['rejected']} "
                    f"doubt={c['doubt']} proposals={r['proposals']}")
            if r["observed_rejection_rate"] is not None:
                line += (f" observed_rejection_rate={r['observed_rejection_rate']} "
                         f"sample_wilson95={r['sample_wilson95']}")
            if r["rule_of_three"] is not None:
                line += f" rule_of_three_upper={r['rule_of_three']}"
            if r["weighted_rejection_rate"] is not None:
                line += f" weighted_by_group={r['weighted_rejection_rate']}"
            print(line)
            if r["reasons"]:
                print("    reasons: " + ", ".join(f"{k}={v}" for k, v in sorted(r["reasons"].items())))
            for g, v in r["by_group"].items():
                print(f"    group {g or '-'}: " + " ".join(f"{k}={n}" for k, n in v.items()))
            if r["likert_mean"]:
                print("    likert mean: " + ", ".join(f"{k}={v}" for k, v in r["likert_mean"].items()))
        if rep.get("agreement"):
            g = rep["agreement"]
            print(f"  agreement: items_in_common={g['items_in_common']} percent={g['percent']} "
                  f"cohen_kappa={g['cohen_kappa_first_two']} krippendorff_alpha={g['krippendorff_alpha']}")
        return 0
    rec = review.load_sample(synp, a.sample) if a.sample else review.draw(
        synp, size=a.size, seed=a.seed, focus=a.focus, strata=a.strata)
    lang = a.lang or viewer.page_language(synp)[0]
    page = review.build_page(synp, rec, lang, Path(a.out) if a.out else None)
    print(f"review: {page}  (language: {lang})")
    print(f"  sample={rec['id']} annotations={len(rec['items'])}/{rec['population']} groups={rec['groups_rule'] or 'none'} "
          f"seed={rec['seed']}")
    if a.open:
        viewer.open_in_browser(page)
    return 0


def cmd_size(a: argparse.Namespace) -> int:
    """Counts only (no names): safe in modality B. Read it before any heavy step."""
    from sklib import size as sizing

    m = sizing.measure(_p(a.project))
    c = m["counts"]
    print(f"size={m['class']} view_depth={m['depth']} data_mb={m['mb']} units={m['units']}")
    print(f"  sources={c['sources']} items={c['items']} concepts={c['concepts']} "
          f"references={c['references']} records={c['records']}")
    e = m["estimate"]["full"]
    print(f"  complete_view: ~{e['seconds']} s, page ~{e['page_mb']} MB")
    if m["outside"]:
        print(f"  outside_files={m['outside']} (Synesis files in the folder that the .synp does not include)")
    return 0


def cmd_intake(a: argparse.Namespace) -> int:
    """Counts only by default: file names may identify people, and what is printed is read by Claude."""
    target = Path(a.target)
    if target.suffix.lower() == ".synp":
        synp = _p(a.target)
        folder = synp.parent
    else:
        target.mkdir(parents=True, exist_ok=True)
        folder = target.resolve()
        found = sorted(folder.glob("*.synp"))
        if len(found) > 1:
            print(f"error: {len(found)} projects in this folder; give the .synp file", file=sys.stderr)
            return 2
        synp = found[0] if found else None
    if a.apply and synp is None:
        print("error: --apply needs the project file (.synp); create the project first", file=sys.stderr)
        return 2
    lang = a.lang or (viewer.page_language(synp)[0] if synp else viewer.default_language())
    inbox = intake.make_inbox(folder, a.inbox or viewer.SOURCES[lang]["inbox"])
    if a.join:
        j = intake.join_parts(folder)
        print(f"joined={j['joined']} incomplete={j['incomplete']} exists={j['exists']}")
    if a.apply:
        r = intake.apply(synp, keys=a.keys, prefix=a.prefix, only=a.only)
        print(f"prepared: texts={len(r['texts'])} references={len(r['references'])} records={len(r['records'])} "
              f"already={r['skipped']} left={r['left']} conflicts={len(r['conflicts'])}")
        if a.names or a.keys == "neutral":
            for kind in ("texts", "records"):
                for key in r[kind]:
                    print(f"  {kind[:-1]:<7} fontes/{key}")
        if r["conflicts"]:
            print("  CONFLICT: reference keys already in the project with different content were left as they are"
                  + (": " + ", ".join(sorted(set(r["conflicts"]))) if a.names else " (--names lists them)"))
    inv = intake.scan(folder)
    print(f"inbox: {inbox.name}/  files={len(inv['files'])}")
    for kind, n in intake.counts(inv).items():
        print(f"  {kind:<12} {n}")
    if a.names:
        for f in inv["files"]:
            print(f"    {f['kind']:<12} {f['name']}")
    if intake.gitignore_hint(folder, inbox):
        print(f"note: if this folder goes to git, add {inbox.name}/ to .gitignore (raw material may have personal data)")
    page = viewer.build_view(synp, None, a.lang) if synp else viewer.build_intake(folder, lang)
    print(f"view: {page}  (language: {lang})")
    if a.open:
        viewer.open_in_browser(page)
    return 0


def cmd_locale(a: argparse.Namespace) -> int:
    from sklib import locale as loc

    print(json.dumps(loc.report(_p(a.project) if a.project else None), ensure_ascii=False, indent=2))
    return 0


def cmd_help(a: argparse.Namespace) -> int:
    """synesis-help through the same environment, so the guide matches the compiler."""
    import shutil

    exe = shutil.which("synesis-help") or str(Path(sys.executable).parent / "synesis-help")
    if a.lookup:
        argv = [exe, "lookup", a.lookup, "--format=json"]
    elif a.words:
        argv = [exe, "search", *a.words, "--format=json"]
    else:
        argv = [exe, "list", "--format=json"] + (["--category", a.category] if a.category else [])
    try:
        return subprocess.call(argv)
    except OSError:
        argv[0:1] = [sys.executable, "-m", "synesis_help.cli"]
        return subprocess.call(argv)


def cmd_accept(a: argparse.Namespace) -> int:
    m = runs.accept(_p(a.project), a.run, note=a.note or "")
    for f in m.get("accepted_files", {}):
        print(f"  accepted  {f}")
    _refresh_view(_p(a.project))
    return 0


def cmd_decide(a: argparse.Namespace) -> int:
    e = runs.decide(_p(a.project), a.type, note=a.note, triage_class=a.cls, item=a.item, run=a.run)
    print(f"recorded {e['type']}")
    return 0


def cmd_marks(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    data = read_json(_p(a.import_file))
    target = runs.runs_dir(synp) / "audit" / "marks.json"
    write_json(target, dash.normalize_marks(data))
    runs.decide(synp, "import_marks", note=f"imported {len(data.get('marks', []))} marks",
                file=str(target.relative_to(synp.parent).as_posix()))
    print(f"imported into {target.relative_to(synp.parent).as_posix()}")
    return 0


def cmd_dashboard(a: argparse.Namespace) -> int:
    synp = _p(a.project)
    m = None if a.anyway else dash.too_large(synp)
    if m:
        # The skill teaches and reviews; it does not replace the Synesis tools. A large project's
        # results are read with them, not in one heavy page built in the conversation.
        e = m["estimate"]["full"]
        print(f"dashboard: not built. The project is large ({m['units']} items and concepts, {m['mb']} MB of data); "
              f"the results page would take about {e['seconds']} s and weigh about {m['page_mb']} MB, "
              "too heavy to open comfortably.")
        print("  Read the results with the Synesis tools directly:")
        print(f"    synesis compile {synp.name} --xls results.xlsx      (or --csv DIR, --json FILE)")
        print(f"    synesis export {synp.name}                          (the EXPORT blocks of the project)")
        print("    the Synesis extension for VS Code (explorer, graph, chat with the project)")
        print("  Review and the project view stay available here: sk.py review, sk.py view.")
        print(f"  To build it anyway, after the researcher agrees to the time: sk.py dashboard {synp.name} --anyway")
        return 3
    out = Path(a.out) if a.out else synp.parent / "dashboard" / "dashboard.html"
    info = dash.build(synp, out)
    print(f"dashboard: {out}  ({info['bytes']:,} bytes)  ready={info['ready']}  stale={info['stale']}")
    return 0


def cmd_rebuild(a: argparse.Namespace) -> int:
    hashes = dash.rebuild(_p(a.project), Path(a.out))
    for name, h in hashes.items():
        print(f"{h}  {name}")
    return 0


def cmd_runs(a: argparse.Namespace) -> int:
    for m in runs.list_runs(_p(a.project)):
        print(f"{m['id']:<32} {m['status']:<9} {m['backend']:<8} {m.get('model')}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="sk", description="synesis-skill helpers")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor").set_defaults(fn=cmd_doctor)
    for name, fn in (("check", cmd_check), ("runs", cmd_runs)):
        s = sub.add_parser(name)
        s.add_argument("project")
        s.set_defaults(fn=fn)
    s = sub.add_parser("validate"); s.add_argument("project"); s.add_argument("--out")
    s.set_defaults(fn=cmd_validate)
    s = sub.add_parser("anchor"); s.add_argument("project"); s.add_argument("--out")
    s.add_argument("--literal", action="store_true"); s.set_defaults(fn=cmd_anchor)
    s = sub.add_parser("code"); s.add_argument("project")
    s.add_argument("--backend", choices=["api", "handoff"], default="handoff")
    s.add_argument("--mode", choices=list(runs.MODES), default="document")
    s.add_argument("--target", default="ontology"); s.add_argument("--input")
    s.add_argument("--model"); s.add_argument("--env-file"); s.add_argument("--run")
    s.add_argument("--concurrent", type=int, default=3)
    s.add_argument("--language", help='output language of the coder, e.g. "Brazilian Portuguese"')
    s.set_defaults(fn=cmd_code)
    s = sub.add_parser("view"); s.add_argument("project"); s.add_argument("--out")
    s.add_argument("--lang", choices=sorted(viewer.LANGS)); s.add_argument("--open", action="store_true")
    s.add_argument("--depth", choices=["auto", "overview", "sample", "full"],
                   help="default: by project size (sk.py size); kept for later refreshes until 'auto'")
    s.add_argument("--focus", help="a group (folder or value), a source key or a concept")
    s.add_argument("--seed", type=int, help="draw of the selection (default 1)")
    s.add_argument("--strata", help="'folder', a SOURCE field name, or 'none' (default: folders, else the first closed SOURCE field)")
    s.add_argument("--sources", type=int, help="sources in the sampled view (default 30)")
    s.set_defaults(fn=cmd_view)
    s = sub.add_parser("size"); s.add_argument("project"); s.set_defaults(fn=cmd_size)
    s = sub.add_parser("review"); s.add_argument("project")
    s.add_argument("--size", type=int, default=30, help="annotations in the sample (default 30)")
    s.add_argument("--seed", type=int, default=1)
    s.add_argument("--focus", help="a group, a source key or a concept")
    s.add_argument("--strata", help="'folder', a SOURCE field name, or 'none'")
    s.add_argument("--sample", help="an existing sample id: rebuild its page (e.g. for a second rater)")
    s.add_argument("--import", dest="import_file", nargs="+", help="review files exported by the page (.md or .json)")
    s.add_argument("--report", action="store_true", help="counts, rates and agreement of a sample")
    s.add_argument("--corrections", action="store_true",
                   help="consolidate every rater's verdicts and proposed corrections for the coordinator")
    s.add_argument("--lang", choices=sorted(viewer.LANGS)); s.add_argument("--out"); s.add_argument("--open", action="store_true")
    s.set_defaults(fn=cmd_review)
    s = sub.add_parser("intake")
    s.add_argument("target")
    s.add_argument("--lang", choices=sorted(viewer.LANGS))
    s.add_argument("--inbox")
    s.add_argument("--names", action="store_true", help="print file names (never in modality B)")
    s.add_argument("--join", action="store_true", help="join the parts of PDFs converted by a connector")
    s.add_argument("--apply", action="store_true")
    s.add_argument("--keys", choices=["name", "neutral"], default="name")
    s.add_argument("--prefix", default="src")
    s.add_argument("--only", action="append")
    s.add_argument("--open", action="store_true")
    s.set_defaults(fn=cmd_intake)
    s = sub.add_parser("locale"); s.add_argument("project", nargs="?"); s.set_defaults(fn=cmd_locale)
    s = sub.add_parser("help"); s.add_argument("words", nargs="*")
    s.add_argument("--lookup"); s.add_argument("--category"); s.set_defaults(fn=cmd_help)
    s = sub.add_parser("accept"); s.add_argument("project"); s.add_argument("--run", required=True)
    s.add_argument("--note"); s.set_defaults(fn=cmd_accept)
    s = sub.add_parser("decide"); s.add_argument("project"); s.add_argument("--type", required=True)
    s.add_argument("--class", dest="cls",
                   choices=["ambiguous_instruction", "model_failure", "source_conversion",
                            "interpretive_divergence"])
    s.add_argument("--item"); s.add_argument("--run"); s.add_argument("--note", required=True)
    s.set_defaults(fn=cmd_decide)
    s = sub.add_parser("marks"); s.add_argument("project")
    s.add_argument("--import", dest="import_file", required=True); s.set_defaults(fn=cmd_marks)
    s = sub.add_parser("dashboard"); s.add_argument("project"); s.add_argument("--out")
    s.add_argument("--anyway", action="store_true",
                   help="build it for a large project too (slow, heavy page; ask the researcher first)")
    s.set_defaults(fn=cmd_dashboard)
    s = sub.add_parser("rebuild"); s.add_argument("project"); s.add_argument("--out", required=True)
    s.set_defaults(fn=cmd_rebuild)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
