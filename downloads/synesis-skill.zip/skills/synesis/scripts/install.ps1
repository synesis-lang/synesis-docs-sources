# Synesis installer for Windows (PowerShell). Idempotent: run it again to check or repair.
# Installs uv if missing, then synesis + synesis-coder + synesis-help in ONE tool
# environment, and prints a report. Optional: -WithGraph adds synesis-graph.
param([switch]$WithGraph)
$ErrorActionPreference = "Stop"

# Exact versions this skill was tested with. Raise them together at each release.
$SynesisVersion = "0.16.0"
$CoderVersion = "0.15.1"
$HelpVersion = "0.4.0"
$GraphVersion = "0.13.1"
$report = [ordered]@{}

function Find-Uv {
    $cmd = Get-Command uv -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($p in @("$env:USERPROFILE\.local\bin\uv.exe", "$env:USERPROFILE\.cargo\bin\uv.exe")) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

$uv = Find-Uv
if (-not $uv) {
    Write-Host "Installing uv (https://astral.sh/uv)..."
    try {
        powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
    } catch {
        Write-Host "The uv script was blocked; trying winget..."
        winget install --id=astral-sh.uv -e --accept-source-agreements --accept-package-agreements
    }
    $uv = Find-Uv
    if (-not $uv) { throw "uv could not be installed. Install it manually: https://docs.astral.sh/uv/" }
}
$report["uv"] = (& $uv --version)

$extra = "synesis-coder,synesis-help"
$with = @("--with", "synesis-coder==$CoderVersion", "--with", "synesis-help==$HelpVersion")
if ($WithGraph) {
    $extra = "$extra,synesis-graph"
    $with += @("--with", "synesis-graph==$GraphVersion")
}
& $uv tool install "synesis==$SynesisVersion" --with-executables-from $extra @with --force
if (-not $env:SYNESIS_SKILL_NO_PATH) { & $uv tool update-shell | Out-Null }

$bin = (& $uv tool dir --bin).Trim()
$toolDir = (& $uv tool dir).Trim()
$python = Join-Path $toolDir "synesis\Scripts\python.exe"
$report["bin"] = $bin
$report["python"] = $python
$report["synesis"] = (& (Join-Path $bin "synesis.exe") --version | Select-Object -First 1)
$report["synesis-coder"] = (& (Join-Path $bin "synesis-coder.exe") --version | Select-Object -First 1)
$report["synesis-help"] = (& (Join-Path $bin "synesis-help.exe") --version | Select-Object -First 1)

# Smoke test in a temporary folder.
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("synesis-smoke-" + [guid]::NewGuid().ToString("N").Substring(0,8))
New-Item -ItemType Directory -Path $tmp | Out-Null
Push-Location $tmp
try {
    & (Join-Path $bin "synesis.exe") init | Out-Null
    & (Join-Path $bin "synesis.exe") compile project.synp | Out-Null
    $report["smoke_test"] = if ($LASTEXITCODE -eq 0) { "ok" } else { "FAILED (exit $LASTEXITCODE)" }
} finally {
    Pop-Location
    Remove-Item -Recurse -Force $tmp
}

Write-Host ""
Write-Host "SYNESIS INSTALL REPORT"
$report.GetEnumerator() | ForEach-Object { Write-Host ("{0,-14} {1}" -f $_.Key, $_.Value) }
Write-Host "New terminals find the commands on PATH; in this one, use the 'bin' folder above."
