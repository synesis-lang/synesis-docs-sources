#!/usr/bin/env sh
# Synesis installer for macOS and Linux. Idempotent: run it again to check or repair.
# Installs uv if missing, then synesis + synesis-coder + synesis-help in ONE tool
# environment, and prints a report. Optional: --with-graph adds synesis-graph
# (not available on Intel Macs: arcadedb-embedded has no build there).
set -eu

# Exact versions this skill was tested with. Raise them together at each release.
SYNESIS_VERSION=0.16.0
CODER_VERSION=0.15.1
HELP_VERSION=0.4.0
GRAPH_VERSION=0.13.1

EXTRA="synesis-coder,synesis-help"
WITH="--with synesis-coder==$CODER_VERSION --with synesis-help==$HELP_VERSION"
if [ "${1:-}" = "--with-graph" ]; then
    if [ "$(uname -s)" = "Darwin" ] && [ "$(uname -m)" != "arm64" ]; then
        echo "note: synesis-graph is not available on Intel Macs; skipping it."
    else
        EXTRA="$EXTRA,synesis-graph"
        WITH="$WITH --with synesis-graph==$GRAPH_VERSION"
    fi
fi

find_uv() {
    command -v uv 2>/dev/null && return 0
    for p in "$HOME/.local/bin/uv" "$HOME/.cargo/bin/uv"; do
        [ -x "$p" ] && { echo "$p"; return 0; }
    done
    return 1
}

UV=$(find_uv || true)
if [ -z "$UV" ]; then
    echo "Installing uv (https://astral.sh/uv)..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    UV=$(find_uv) || { echo "uv could not be installed: https://docs.astral.sh/uv/"; exit 1; }
fi

# shellcheck disable=SC2086
"$UV" tool install "synesis==$SYNESIS_VERSION" --with-executables-from "$EXTRA" $WITH --force
[ -n "${SYNESIS_SKILL_NO_PATH:-}" ] || "$UV" tool update-shell >/dev/null 2>&1 || true

BIN=$("$UV" tool dir --bin)
PY="$("$UV" tool dir)/synesis/bin/python"

TMP=$(mktemp -d)
( cd "$TMP" && "$BIN/synesis" init >/dev/null && "$BIN/synesis" compile project.synp >/dev/null ) \
    && SMOKE=ok || SMOKE=FAILED
rm -rf "$TMP"

echo ""
echo "SYNESIS INSTALL REPORT"
echo "uv             $("$UV" --version)"
echo "bin            $BIN"
echo "python         $PY"
echo "synesis        $("$BIN/synesis" --version | head -1)"
echo "synesis-coder  $("$BIN/synesis-coder" --version | head -1)"
echo "synesis-help   $("$BIN/synesis-help" --version | head -1)"
echo "smoke_test     $SMOKE"
echo "New terminals find the commands on PATH; in this one, use the 'bin' folder above."
