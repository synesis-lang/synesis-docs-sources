"""synesis-skill helper library.

Uses the published `synesis` and `synesis-coder` packages as libraries and never
modifies them. Everything here could later move into those packages; see
the skill README ("What should move upstream").
"""
