# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Run records: `runs/<id>/` holds manifest, inputs, requests, responses and outputs.

A run codes one target (a document, one .bib reference, or the ontology) with
one backend. Handoff runs take several passes: each pass replays the answered
requests and writes the unanswered ones; when a pass leaves nothing pending,
the run is complete. `accept` copies the outputs into the project and records
the decision. Everything under `runs/` is research data: version it.
"""

from __future__ import annotations

import datetime as _dt
import importlib.metadata as _md
import os
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from .common import (PROTOCOL_VERSION, append_jsonl, compiler_has_fixes, die, project_state, read_json,
                     read_jsonl, rel, sha256_file, write_json)
from .handoff import PendingRequest, make_handoff_client, make_recording_client
from .project import include_target

MODES = ("document", "abstract", "dataset", "ontology")


def _today() -> str:
    return _dt.date.today().isoformat()


def _versions() -> Dict[str, str]:
    out = {}
    for pkg in ("synesis", "synesis-coder"):
        try:
            out[pkg] = _md.version(pkg)
        except _md.PackageNotFoundError:
            out[pkg] = "not installed"
    return out


def runs_dir(synp: Path) -> Path:
    return Path(synp).resolve().parent / "runs"


def decisions_path(synp: Path) -> Path:
    return runs_dir(synp) / "decisions.jsonl"


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_") or "x"


def _next_run_id(synp: Path, mode: str, target: str) -> str:
    rd = runs_dir(synp)
    existing = [p.name for p in rd.iterdir()] if rd.is_dir() else []
    n = 1 + max([int(m.group(1)) for x in existing if (m := re.match(r"^(\d{3})-", x))] or [0])
    return f"{n:03d}-{mode}-{_slug(target)}"


def _bib_entry(bib_text: str, key: str) -> Optional[str]:
    """Raw text of one BibTeX entry (balanced braces)."""
    m = re.search(r"@\w+\s*\{\s*" + re.escape(key) + r"\s*,", bib_text)
    if not m:
        return None
    depth, i = 0, bib_text.index("{", m.start())
    for j in range(i, len(bib_text)):
        if bib_text[j] == "{":
            depth += 1
        elif bib_text[j] == "}":
            depth -= 1
            if depth == 0:
                return bib_text[m.start(): j + 1] + "\n"
    return None


def _prepare_inputs(synp: Path, run_dir: Path, mode: str, target: str,
                    input_path: Optional[Path]) -> Dict[str, Any]:
    inputs: Dict[str, Any] = {}
    idir = run_dir / "inputs"
    idir.mkdir(parents=True, exist_ok=True)
    if mode == "document":
        if input_path is None:
            die("--input is required for mode document")
        from synesis_coder.modes.document_mode import read_document
        from synesis_coder.text_cleaner import clean_document

        raw_copy = idir / f"{_slug(target)}{input_path.suffix.lower()}"
        shutil.copyfile(input_path, raw_copy)
        cleaned = clean_document(read_document(input_path))
        text_path = idir / f"{_slug(target)}.text.txt"
        text_path.write_text(cleaned, encoding="utf-8", newline="\n")
        inputs[target] = {"kind": "document_text", "path": rel(text_path, run_dir),
                          "raw": rel(raw_copy, run_dir), "source": rel(input_path, synp.parent),
                          "sha256": sha256_file(raw_copy)}
    elif mode == "abstract":
        bib = include_target(synp, "BIBLIOGRAPHY")
        if bib is None or not bib.exists():
            die("the project declares no readable INCLUDE BIBLIOGRAPHY")
        entry = _bib_entry(bib.read_text(encoding="utf-8"), target)
        if entry is None:
            die(f"reference '{target}' not found in {bib.name}")
        if "abstract" not in entry.lower():
            die(f"reference '{target}' has no abstract to code")
        bib_path = idir / f"{_slug(target)}.bib"
        bib_path.write_text(entry, encoding="utf-8", newline="\n")
        inputs[target] = {"kind": "bib_entry", "path": rel(bib_path, run_dir),
                          "sha256": sha256_file(bib_path)}
    elif mode == "dataset":
        if input_path is None or input_path.suffix.lower() != ".toml":
            die("--input RECORD.toml is required for mode dataset")
        rec_path = idir / f"{_slug(target)}.toml"
        shutil.copyfile(input_path, rec_path)
        inputs[target] = {"kind": "dataset_record", "path": rel(rec_path, run_dir),
                          "source": rel(input_path, synp.parent), "sha256": sha256_file(rec_path)}
    return inputs


def _load_env(synp: Path, env_file: Optional[Path]) -> Optional[str]:
    """Load the coder settings the same way the CLI does, plus an explicit file."""
    from dotenv import find_dotenv, load_dotenv

    if env_file is not None:
        load_dotenv(env_file, override=False)
        return "explicit file (--env-file)"  # the path itself stays out of the shared record
    local = Path(synp).resolve().parent / ".env"
    if local.exists():
        load_dotenv(local, override=False)
        return ".env (project)"
    found = find_dotenv(usecwd=True)
    if found:
        load_dotenv(found, override=False)
        return "found from working directory"
    return None


def code(synp: Path, backend: str, mode: str, target: str, input_path: Optional[Path] = None,
         model: Optional[str] = None, env_file: Optional[Path] = None,
         run_id: Optional[str] = None, concurrent: int = 3,
         language: Optional[str] = None) -> Dict[str, Any]:
    synp = Path(synp).resolve()
    if mode not in MODES:
        die(f"mode must be one of {MODES}")
    if backend not in ("api", "handoff"):
        die("backend must be api or handoff")
    state = project_state(synp)

    if run_id:
        run_dir = runs_dir(synp) / run_id
        if not (run_dir / "manifest.json").exists():
            die(f"run {run_id} not found")
        manifest = read_json(run_dir / "manifest.json")
        if manifest["status"] in ("complete", "accepted"):
            return manifest
        if manifest["project_state_before"] != state["state"]:
            # The context of every request depends on the project: answers given
            # for another state must not be applied (stale responses).
            manifest["status"] = "stale"
            write_json(run_dir / "manifest.json", manifest)
            die(f"the project changed since run {run_id} started; start a new run")
        backend, mode, target = manifest["backend"], manifest["mode"], manifest["target"]
    else:
        run_id = _next_run_id(synp, mode, target)
        run_dir = runs_dir(synp) / run_id
        run_dir.mkdir(parents=True)
        manifest = {
            "kind": "synesis-skill/run",
            "protocol": PROTOCOL_VERSION,
            "id": run_id,
            "mode": mode,
            "target": target,
            "backend": backend,
            "model": model,
            "versions": _versions(),
            "created_on": _today(),
            "project_state_before": state["state"],
            "project_files_before": state["files"],
            "inputs": _prepare_inputs(synp, run_dir, mode, target, input_path),
            "passes": 0,
            "status": "started",
        }
        write_json(run_dir / "manifest.json", manifest)

    # The project .env shapes the prompt (for example SYNESIS_CODER_LANGUAGE) in
    # both backends, not only the API credentials: load it before any coder code
    # runs. synesis-coder itself no longer reads a .env from where it is installed.
    manifest["settings_from"] = _load_env(synp, env_file)
    # Output language of the coder's free text. An explicit --language wins over
    # the project .env; a continuation pass keeps the language the run started
    # with, so every request of one run is written in one language.
    chosen = language or manifest.get("output_language")
    if chosen:
        os.environ["SYNESIS_CODER_LANGUAGE"] = chosen
    manifest["output_language"] = os.environ.get("SYNESIS_CODER_LANGUAGE") or None
    if backend == "api":
        client_cls, queue = make_recording_client(run_dir)
    else:
        # A continuation pass keeps the model declared when the run started.
        declared = (model or manifest.get("model")
                    or os.environ.get("SYNESIS_SKILL_SESSION_MODEL") or "claude-code-session")
        manifest["model"] = declared
        client_cls, queue = make_handoff_client(run_dir, declared)

    staging = run_dir / "staging"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir()
    error: Optional[str] = None
    module = _mode_module(mode)
    api_model = model if backend == "api" else None
    # synesis-coder with D-4 accepts `client=`; older versions build the client
    # by name inside the mode module, so the name is replaced for this run only.
    injectable = _accepts_client(mode)
    client_kw: Dict[str, Any] = {"client": client_cls(model=api_model)} if injectable else {}
    manifest["client_injection"] = "parameter" if injectable else "module-patch"
    original = module.LLMClient
    if not injectable:
        module.LLMClient = client_cls
    try:
        _run_mode(mode, synp, run_dir, staging, manifest, api_model, concurrent, client_kw)
    except PendingRequest:
        pass
    except SystemExit as exc:  # the coder aborts with SystemExit on fatal problems
        error = f"coder exited: {exc}"
    except Exception as exc:  # recorded, never hidden
        error = f"{type(exc).__name__}: {exc}"
    finally:
        module.LLMClient = original

    manifest["passes"] = int(manifest.get("passes", 0)) + 1
    if backend == "api" and getattr(queue, "model", None):
        manifest["model"] = queue.model
    pending = sorted(queue.pending)
    if pending:
        manifest["status"] = "pending"
        manifest["pending"] = [f"requests/{rid}.md" for rid in pending]
        shutil.rmtree(staging, ignore_errors=True)
    elif error:
        manifest["status"] = "failed"
        manifest["error"] = error
    else:
        out = run_dir / "output"
        shutil.rmtree(out, ignore_errors=True)
        staging.rename(out)
        manifest["status"] = "complete"
        manifest.pop("pending", None)
        manifest["outputs"] = {rel(p, run_dir): sha256_file(p)
                               for p in sorted(out.rglob("*")) if p.is_file()}
        answered = {p.stem for p in (run_dir / "responses").glob("*.txt")}
        manifest["requests_answered"] = len(answered)
        manifest["unused_responses"] = sorted(answered - queue.used)
    write_json(run_dir / "manifest.json", manifest)
    return manifest


class _EmptySynoShim:
    """Workaround for synesis before 0.16.0: empty or comment-only content does not parse.
    From 0.16.0 (C-2) the compiler accepts it, and this does nothing.

    `synesis-coder ontology` validates the previous state of the destination
    .syno before writing; for a first ontology that state is empty and the
    compiler raises "Unexpected token <EOF>", so no ontology can be created
    from scratch. During a run only, content without any non-comment text
    compiles to "no blocks". Remove when the compiler accepts empty files.
    """

    def __enter__(self):
        import synesis.api as api

        self._api = api
        self._original = api.compile_string
        if compiler_has_fixes():          # synesis >= 0.16.0 accepts an empty file: change nothing
            self._active = False
            return self
        self._active = True

        def compile_string(content: str, filename: str = "<string>"):
            meaningful = [ln for ln in content.splitlines()
                          if ln.strip() and not ln.lstrip().startswith("#")]
            if not meaningful:
                return []
            return self._original(content, filename)

        api.compile_string = compile_string
        return self

    def __exit__(self, *exc):
        if getattr(self, "_active", False):
            self._api.compile_string = self._original
        return False


def _mode_module(mode: str):
    import importlib

    return importlib.import_module(f"synesis_coder.modes.{mode}_mode")


def _accepts_client(mode: str) -> bool:
    import inspect

    entry = {"document": "process_document", "abstract": "process_abstract",
             "dataset": "process_dataset", "ontology": "process_ontology"}[mode]
    return "client" in inspect.signature(getattr(_mode_module(mode), entry)).parameters


def _run_mode(mode: str, synp: Path, run_dir: Path, staging: Path, manifest: Dict[str, Any],
              model: Optional[str], concurrent: int, client_kw: Dict[str, Any]) -> None:
    target = manifest["target"]
    info = (manifest.get("inputs") or {}).get(target, {})
    if mode == "document":
        from synesis_coder.modes.document_mode import process_document

        process_document(synp, target, run_dir / info["raw"], staging / f"{_slug(target)}.syn",
                         concurrent=concurrent, model=model, overwrite=True, **client_kw)
    elif mode == "abstract":
        from synesis_coder.modes.abstract_mode import process_abstract

        process_abstract(synp, run_dir / info["path"], staging, concurrent=concurrent,
                         per_reference=True, model=model, overwrite=True, **client_kw)
    elif mode == "dataset":
        from synesis_coder.modes.dataset_mode import process_dataset

        process_dataset(synp, staging, concurrent=concurrent, model=model,
                        dataset_glob=str((run_dir / info["path"]).resolve()), **client_kw)
    else:
        from synesis_coder.modes.ontology_mode import process_ontology

        with _EmptySynoShim():
            process_ontology(synp, staging / "ontology.syno", update=True, concurrent=concurrent,
                             model=model, overwrite=True, **client_kw)


def accept(synp: Path, run_id: str, note: str = "") -> Dict[str, Any]:
    synp = Path(synp).resolve()
    run_dir = runs_dir(synp) / run_id
    manifest = read_json(run_dir / "manifest.json")
    if manifest["status"] == "accepted":
        return manifest
    if manifest["status"] != "complete":
        die(f"run {run_id} is {manifest['status']}, not complete")
    # The output is valid only for the project state it was generated from and
    # only as it was recorded: re-check both before publishing it.
    if project_state(synp)["state"] != manifest["project_state_before"]:
        manifest["status"] = "stale"
        write_json(run_dir / "manifest.json", manifest)
        die(f"the project changed since run {run_id} was generated; the run is stale, start a new run")
    for out_rel, sha in (manifest.get("outputs") or {}).items():
        out_path = run_dir / out_rel
        if not out_path.exists() or sha256_file(out_path) != sha:
            die(f"output {out_rel} of run {run_id} is missing or differs from the recorded hash")
    kind = "ONTOLOGY" if manifest["mode"] == "ontology" else "ANNOTATIONS"
    dest = include_target(synp, kind)
    if dest is None:
        die(f"the project declares no INCLUDE {kind}")
    if dest.suffix:  # a single file is declared: the skill needs a folder
        die(f"INCLUDE {kind} points to a file ({dest.name}); declare a folder so runs can be added")
    dest.mkdir(parents=True, exist_ok=True)
    copied: Dict[str, str] = {}
    for out_rel in sorted(manifest.get("outputs") or {}):
        src = run_dir / out_rel
        name = f"{run_id}.syno" if manifest["mode"] == "ontology" else src.name
        target = dest / name
        if target.exists() and sha256_file(target) == sha256_file(src):
            copied[rel(target, synp.parent)] = sha256_file(target)
            continue
        shutil.copyfile(src, target)
        copied[rel(target, synp.parent)] = sha256_file(target)
    manifest["status"] = "accepted"
    manifest["accepted_files"] = copied
    manifest["accepted_on"] = _today()
    write_json(run_dir / "manifest.json", manifest)
    decide(synp, "accept_run", note=note or f"accepted run {run_id}", run=run_id, files=copied)
    return manifest


def decide(synp: Path, dtype: str, note: str = "", **fields: Any) -> Dict[str, Any]:
    entry = {"type": dtype, "date": _today(), "note": note,
             "project_state": project_state(synp)["state"]}
    entry.update({k: v for k, v in fields.items() if v is not None})
    append_jsonl(decisions_path(synp), entry)
    return entry


def list_runs(synp: Path) -> List[Dict[str, Any]]:
    rd = runs_dir(synp)
    if not rd.is_dir():
        return []
    return [read_json(m) for m in sorted(rd.glob("*/manifest.json"))]


def decisions(synp: Path) -> List[Dict[str, Any]]:
    return read_jsonl(decisions_path(synp))
