# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""CSS, JavaScript and the page skeleton of the project view. Inline only: the page loads nothing."""

GH_SVG = ('<svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M8 0C3.58 0 0 3.58 0 8c0 '
          '3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52'
          '-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2'
          '-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82'
          ' 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>')

EXTRA_CSS = """
:root{--err:#c42b1c;--warn:#b26a00;--edit:#8250b6;--okc:#1a7f37;--errbg:#fdecea;--warnbg:#fff4e0;--editbg:#f3ecfb;--okbg:#e9f6ec}
[data-theme=dark]{--err:#f48771;--warn:#cca700;--edit:#c5a3f0;--okc:#73c991;--errbg:#3a2321;--warnbg:#3a3220;--editbg:#2f2740;--okbg:#1f3326}
.problems{background:var(--panel);border:1px solid var(--line);border-radius:10px;margin:4px 0 14px;box-shadow:var(--shadow)}
.problems .ph{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 14px;cursor:pointer;list-style:none}
.problems .ph::-webkit-details-marker{display:none}.problems .ph b{margin-right:4px}
.problems .ph .ask{margin-left:auto}
.problems ul{list-style:none;margin:0;padding:0 0 6px;border-top:1px solid var(--line)}
.problems li{display:grid;grid-template-columns:70px minmax(0,1fr) auto;gap:10px;align-items:baseline;padding:6px 14px;border-bottom:1px solid color-mix(in srgb,var(--line) 60%,transparent);font-size:13.5px}
.problems li:last-child{border-bottom:0}.problems li a{color:inherit;text-decoration:none}.problems li a:hover{text-decoration:underline}
.problems .pm{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.where{white-space:nowrap;font:12px ui-monospace,Consolas,monospace;color:var(--muted);display:flex;gap:10px}
.problems.ok p{padding:0 14px 10px;margin:0;color:var(--muted)}
.sev{font:600 10.5px/1.6 "Segoe UI",system-ui,sans-serif;text-transform:uppercase;letter-spacing:.06em;border-radius:4px;padding:0 6px;text-align:center;align-self:start;margin-top:2px}
.error .sev{background:var(--errbg);color:var(--err)}.warning .sev{background:var(--warnbg);color:var(--warn)}
.anchor .sev{background:var(--warnbg);color:var(--warn)}.edit .sev{background:var(--editbg);color:var(--edit)}.info .sev{background:var(--pill);color:var(--muted)}
.chip-s{display:inline-block;font-size:12px;border-radius:20px;padding:1px 9px;border:1px solid transparent;white-space:nowrap}
.chip-s.error{background:var(--errbg);color:var(--err)}.chip-s.warning{background:var(--warnbg);color:var(--warn)}
.chip-s.edit{background:var(--editbg);color:var(--edit)}.chip-s.ok{background:var(--okbg);color:var(--okc)}
.chip-s.muted{background:var(--pill);color:var(--muted)}.chip-s.pend{border-color:var(--s-field);color:var(--s-field)}
.head{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}.head .ht{flex:1;min-width:0}
.acts{display:flex;gap:8px;align-items:baseline;font:12px "Segoe UI",system-ui,sans-serif;margin-left:auto}
.ln{color:var(--muted);font:11.5px ui-monospace,Consolas,monospace}
.act{font:12px "Segoe UI",system-ui,sans-serif;color:var(--accent);background:none;border:1px solid transparent;border-radius:6px;padding:1px 7px;cursor:pointer;text-decoration:none}
.act:hover{border-color:var(--line);background:var(--pill)}
.act.ask{border-color:color-mix(in srgb,var(--accent) 40%,transparent)}
body.novs .act.vs{display:none}
.chips{display:flex;flex-wrap:wrap;gap:6px;padding:7px 14px 0}
.dgs{padding:6px 14px 0}
.dg{display:grid;grid-template-columns:70px minmax(0,1fr) auto;gap:10px;align-items:baseline;padding:6px 8px;border-radius:6px;margin:4px 0;font-size:13px}
.dg.error{background:color-mix(in srgb,var(--errbg) 70%,transparent)}.dg.warning,.dg.anchor{background:color-mix(in srgb,var(--warnbg) 70%,transparent)}
.dg .msg{white-space:pre-wrap;overflow-wrap:anywhere}.dg .dl{color:var(--muted);font:11.5px ui-monospace,Consolas,monospace;white-space:nowrap}
.card.has-error{border-left-color:var(--err)}.card.has-warn{border-left-color:var(--warn)}
.foot{display:flex;justify-content:space-between;gap:10px}.prov{font:11.5px "Segoe UI",system-ui,sans-serif;color:var(--muted)}
.fchip{font-size:12px;border-radius:20px;padding:0 9px;margin-left:auto}.fchip.ok{color:var(--okc)}.fchip.edit{background:var(--editbg);color:var(--edit)}.fchip.pend{color:var(--s-field);border:1px solid var(--s-field)}
details.file>summary{flex-wrap:wrap}
aside a{position:relative}.nb{float:right;font-size:10.5px;border-radius:10px;padding:0 6px;margin-left:4px}
.nb.error{background:var(--errbg);color:var(--err)}.nb.warning{background:var(--warnbg);color:var(--warn)}
[data-k]{cursor:help}.kw[data-k]:hover,.ftype[data-k]:hover,.chip[data-k]:hover{text-decoration:underline dotted;text-underline-offset:3px}
[data-f],[data-c],[data-r]{cursor:help;border-bottom:1px dotted color-mix(in srgb,currentColor 45%,transparent)}
.pill[data-c],.pill[data-f]{border-bottom:0}
.pill.undef,.concept.undef{background:none;border:1px dashed var(--warn);color:var(--warn)}
.concept.undef{border-radius:4px;padding:0 4px}
.rel.undef{color:var(--err);text-decoration:wavy underline;text-underline-offset:3px;border-bottom:0}
#pop{position:absolute;z-index:50;max-width:440px;background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:10px;box-shadow:0 6px 24px rgba(20,30,50,.18);padding:10px 13px;font-size:13px;line-height:1.5;display:none}
#pop h4{margin:0 0 2px;font-size:13.5px;color:var(--name)}#pop .meta{color:var(--muted);font-size:11.5px;margin-bottom:6px}
#pop .sec{font-size:10.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin:8px 0 2px}
#pop .g{margin:1px 0}#pop .g.good{color:var(--ok)}#pop .g.bad{color:var(--bad)}
#pop dl{margin:2px 0;display:grid;grid-template-columns:max-content 1fr;gap:2px 8px}#pop dt{color:var(--rel);font-weight:600}#pop dd{margin:0}
#pop .warnl{color:var(--warn);font-weight:600}#pop a{color:var(--accent)}
#toast{position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:var(--ink);color:var(--bg);padding:8px 16px;border-radius:8px;font-size:13.5px;opacity:0;transition:opacity .2s;pointer-events:none;z-index:60}
#toast.on{opacity:.95}
.problems .ph{cursor:default}
.psec{border-top:1px solid var(--line)}.psh{display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline;padding:9px 14px 4px}
.psh h4{margin:0;font-size:13.5px}.psh .ask{margin-left:auto}.psec ul{border-top:0}.none{margin:0;padding:2px 14px 10px;color:var(--muted);font-size:13px}
.prop .sev{border:1px solid var(--s-field);color:var(--s-field)}
.techd{margin-top:3px;font-size:12px}.techd summary{cursor:pointer;color:var(--muted)}
.techd pre{white-space:pre-wrap;overflow-wrap:anywhere;margin:4px 0 0;font:12px/1.45 ui-monospace,Consolas,monospace;color:var(--muted)}
body:not(.tech) .ln,body:not(.tech) .act.vs{display:none}
#code[aria-pressed=true]{border-color:var(--accent);color:var(--accent)}
.bad-row .bf{background:var(--err)}.badl{display:block;color:var(--err);font-size:11px;line-height:1.2}
.mx{width:auto}.mx th,.mx td{padding:2px 4px;border-bottom:0}.mx .mr{font-weight:400;text-align:left;padding-right:12px;white-space:nowrap}
.mx .mr a,.bl a{color:var(--ref);text-decoration:none}.mx .mr a:hover{text-decoration:underline}
.mx .mc{text-align:center;font:12px ui-monospace,Consolas,monospace;color:var(--muted);min-width:54px}
.cell{display:block;border-radius:4px;padding:3px 0;color:var(--ink);text-decoration:none;background:color-mix(in srgb,var(--accent) var(--p),var(--panel));border:2px solid var(--panel)}
.cell:hover{outline:2px solid var(--accent)}.cell.zero{background:color-mix(in srgb,var(--line) 35%,transparent);height:24px}
.mx .tot{color:var(--ink)}
.oc.has-error{border-left-color:var(--err)!important}.oc.has-warn{border-left-color:var(--warn)!important}#occ .oc .chips{padding:0 0 4px}
#occ .panel:focus{outline:none}.card:focus{outline:2px solid var(--accent);outline-offset:2px}
.nodef{color:var(--warn);font-size:11px;margin-left:4px}.mx .mr a.undef{color:var(--warn);text-decoration:underline dashed;text-underline-offset:3px}
.mxt{display:flex;flex-wrap:wrap;gap:8px 18px;margin:0 0 10px;font-size:13px;color:var(--muted)}
.mxt select{font:inherit;color:var(--ink);background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:2px 6px;margin-left:4px}
details.fold>summary{display:flex;gap:10px;align-items:baseline;cursor:pointer;list-style:none;padding:2px 0}
details.fold>summary::-webkit-details-marker{display:none}details.fold>summary h3{margin:10px 0}
details.fold>summary::before{content:"▸";color:var(--muted);font-size:12px}details.fold[open]>summary::before{content:"▾"}
.chain{display:inline-flex;flex-wrap:wrap;align-items:baseline;row-gap:2px}
mark.hit{background:color-mix(in srgb,var(--warn) 35%,transparent);color:inherit;border-radius:2px}
#found{color:var(--muted);font-size:12.5px;margin:0 0 8px;display:none}body.searching #found{display:block}
#occ{position:fixed;inset:0;z-index:70;display:none;background:rgba(10,14,20,.45)}#occ.on{display:block}
#occ .panel{position:absolute;right:0;top:0;bottom:0;width:min(560px,100%);background:var(--bg);border-left:1px solid var(--line);overflow:auto;padding:16px 18px 40px;box-shadow:-8px 0 30px rgba(0,0,0,.2)}
#occ h2{margin:0 0 2px;font-size:17px;color:var(--ref)}#occ .def{color:var(--muted);font-size:13px;margin:4px 0 10px}
#occ .x{float:right}#occ .oc{background:var(--panel);border:1px solid var(--line);border-left:4px solid var(--s-item);border-radius:8px;padding:8px 12px;margin:8px 0}
#occ .oc .src{font:12px ui-monospace,Consolas,monospace;color:var(--ref);display:flex;justify-content:space-between;gap:8px}
#occ .oc q{display:block;font-style:italic;color:color-mix(in srgb,var(--str) 72%,var(--ink));quotes:none;margin:4px 0}
#occ .oc .m{font-size:13px}
#occ .oc .src a{color:var(--accent);font:12.5px "Segoe UI",system-ui,sans-serif;text-decoration:none;white-space:nowrap}#occ .oc .src a:hover{text-decoration:underline}
@media(max-width:720px){.hrow{flex-wrap:wrap;padding:8px 12px 4px}.brand{flex:1}.hrow input{order:3;flex-basis:100%}
.hb{font-size:12px;padding:5px 8px}.tabs{padding:0 6px}.navpane{padding:6px 12px}main{padding:12px 12px 60px}
.head{flex-direction:column;gap:4px}.acts{margin-left:0;flex-wrap:wrap}.body{grid-template-columns:minmax(0,1fr)}.body .k{margin-top:4px}
.grid2{grid-template-columns:minmax(0,1fr)}
table.runs th:nth-child(2),table.runs td:nth-child(2),table.runs th:nth-child(6),table.runs td:nth-child(6){display:none}
table.runs td,table.runs th{padding:5px 8px 5px 0}table.runs .mono{font-size:11.5px}
table.tflds th:nth-child(3),table.tflds td:nth-child(3){display:none}.bar-row{grid-template-columns:minmax(0,45%) 1fr 26px}.psh .ask{margin-left:0}}
.card.flash{outline:2px solid var(--accent);outline-offset:2px;transition:outline-color 1s}
.card{scroll-margin-top:60px}
header.top{position:sticky;top:0;z-index:20;background:var(--panel);border-bottom:1px solid var(--line);box-shadow:var(--shadow)}
.hrow{display:flex;gap:10px;align-items:center;padding:10px 24px 4px;max-width:1160px;margin:0 auto}
.brand{display:flex;flex-direction:column;line-height:1.2;margin-right:10px;white-space:nowrap}.brand b{font-size:15.5px}.brand span{font-size:11.5px;color:var(--muted)}
.hrow input{flex:1;min-width:120px;padding:7px 12px;border-radius:8px;border:1px solid var(--line);background:var(--bg);color:var(--ink);font:inherit;font-size:14px}
.hb{padding:6px 11px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--ink);cursor:pointer;font:inherit;font-size:13px;white-space:nowrap}
.tabs{display:flex;gap:2px;overflow-x:auto;padding:0 18px;max-width:1160px;margin:0 auto;scrollbar-width:none}
.tab{font:inherit;font-size:14px;color:var(--muted);background:none;border:0;border-bottom:2px solid transparent;padding:8px 12px;cursor:pointer;white-space:nowrap;display:flex;gap:6px;align-items:baseline}
.tab small{font-size:11.5px;opacity:.75}.tab:hover{color:var(--ink)}
.tab[aria-selected=true]{color:var(--ink);border-bottom-color:var(--accent);font-weight:600}
.tab[data-tab=poss]{color:var(--accent)}.tab.pend{color:var(--s-field)}.tab.pend[aria-selected=true]{border-bottom-color:var(--s-field)}
.files{border-top:1px solid var(--line);background:color-mix(in srgb,var(--panel) 94%,var(--ink) 6%)}
.navpane{display:none;gap:6px;overflow-x:auto;padding:6px 22px;max-width:1160px;margin:0 auto;scrollbar-width:thin}
.navpane.on:not(:empty){display:flex}.files:has(.navpane.on:empty){display:none}
.navpane a{display:flex;gap:6px;align-items:baseline;white-space:nowrap;padding:3px 10px;border-radius:20px;color:var(--ink);text-decoration:none;font-size:13px;border:1px solid var(--line);background:var(--panel)}
.navpane a:hover{border-color:var(--accent)}.navpane a small{color:var(--muted);font-size:11px}
.tabpane{display:none}.tabpane.on{display:block}
body.searching .tabpane{display:block}body.searching .tabpane[data-tab=overview],body.searching .tabpane[data-tab=sources]{display:none}
body.searching .tabs,body.searching .files{opacity:.45;pointer-events:none}
main{max-width:1160px;margin:0 auto;padding:14px 24px 80px}
.card,details.file{scroll-margin-top:calc(var(--hh,120px) + 10px)}
.dash-head h1{margin:6px 0 4px;font-size:22px}.dash-head .desc{margin:0 0 8px;max-width:820px}
.dash-head h3,.box h3{font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:12px 0 6px}
.qs{margin:0 0 6px;padding-left:0;list-style:none}.qs li{margin:2px 0}.qs b{color:var(--name);margin-right:4px}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:14px 0}
.tile{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px;box-shadow:var(--shadow)}
.tv{font-size:26px;font-weight:600;font-variant-numeric:tabular-nums;line-height:1.15}.tl{color:var(--muted);font-size:12.5px}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px}
.box{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:4px 16px 12px;margin:12px 0;box-shadow:var(--shadow)}
.grid2 .box{margin:0}
.bars{display:grid;gap:5px}.bar-row{display:grid;grid-template-columns:minmax(110px,42%) 1fr 28px;gap:10px;align-items:center;font-size:13px}
.bl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bl a{color:var(--ref);text-decoration:none}.bl a:hover{text-decoration:underline}
.bt{height:10px;background:color-mix(in srgb,var(--line) 55%,transparent);border-radius:4px;overflow:hidden}
.bf{display:block;height:100%;background:var(--accent);border-radius:0 4px 4px 0}.bv{text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}
th{text-align:left;font-weight:600;color:var(--muted);font-size:12px;padding:6px 10px 6px 0;border-bottom:1px solid var(--line)}
td{padding:6px 10px 6px 0;border-bottom:1px solid color-mix(in srgb,var(--line) 60%,transparent);vertical-align:top}
.mono{font:12.5px ui-monospace,Consolas,monospace}.muted{color:var(--muted)}.small{font-size:12.5px}
@media(max-width:820px){.problems li,.dg{grid-template-columns:1fr}.acts{margin-left:0}}
"""

THEME_CSS = """
:root{--bg:#F7F8FA;--panel:#FFFFFF;--ink:#172536;--muted:#5B6878;--line:#DDE3E9;--accent:#006D77;
--kw:#4A6A96;--name:#1F3F63;--ref:#1C6E6A;--rel:#7D5E1E;--arrow:#8A6BB0;--str:#7A4B3A;--num:#2F6B3F;--com:#5C7A5C;
--ok:#067647;--bad:#B42318;--pill:#EEF2F5;--shadow:none;
--s-source:#4F8F86;--s-item:#5B7FA6;--s-ontology:#8571A8;--s-field:#A8823C;--s-project:#7A8794;
--err:#B42318;--warn:#B54708;--edit:#6941C6;--okc:#067647;--errbg:#FEF3F2;--warnbg:#FFFAEB;--editbg:#F4F3FF;--okbg:#ECFDF3;
--qline:#B8C4CF;--sp1:8px;--sp2:16px;--sp3:24px;--sp4:44px;--t:180ms;--ease:cubic-bezier(.2,0,0,1);
--f-sans:"IBM Plex Sans","Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;
--f-serif:"IBM Plex Serif",Georgia,Cambria,"Times New Roman",serif;
--f-mono:"IBM Plex Mono",ui-monospace,SFMono-Regular,Consolas,Menlo,monospace}
[data-theme=dark]{--bg:#11161C;--panel:#182029;--ink:#E4E9EF;--muted:#94A1AF;--line:#2A3440;--accent:#4FB3BD;
--kw:#8FADD6;--name:#B4CDEB;--ref:#6CC5BA;--rel:#D9C27E;--arrow:#BFA2E0;--str:#D9A88F;--num:#9CCB9F;--com:#86A986;
--ok:#47CD89;--bad:#F97066;--pill:#222C37;--s-source:#6FB3A9;--s-item:#86A6CC;--s-ontology:#AE9BD3;--s-field:#D0A85C;--s-project:#93A0AE;
--err:#F97066;--warn:#FDB022;--edit:#B692F6;--okc:#47CD89;--errbg:#3A1F1E;--warnbg:#3A2E14;--editbg:#2A2440;--okbg:#14301F;--qline:#4A5866}
body{font-family:var(--f-sans);font-size:15px;line-height:1.6;-webkit-font-smoothing:antialiased}
.head,.foot,.pk,.ln,.where,.dl,.mono,.rpill,.mx .mc,#occ .oc .src,.techd pre,.mxlegend{font-family:var(--f-mono)}
.fname{font-weight:600}.kw{opacity:1}
/* header */
header.top{box-shadow:none}.brand b{font-weight:600;letter-spacing:-.005em}
.tab{font-family:var(--f-sans)}.tab[aria-selected=true]{border-bottom-color:var(--accent)}
.hb,.hrow input{border-radius:6px}
main{padding:var(--sp3) var(--sp3) 80px}
/* opening */
.dash-head{padding:var(--sp2) 0 0}
.eyebrow{font:500 11.5px/1 var(--f-mono);letter-spacing:.16em;text-transform:uppercase;color:var(--accent);margin:0 0 var(--sp2)}
.dash-head h1{font-size:40px;line-height:1.1;font-weight:600;letter-spacing:-.015em;margin:0 0 var(--sp1)}
.dash-head .desc{font-size:17px;line-height:1.55;color:var(--muted);max-width:760px;margin:0 0 var(--sp3)}
.dash-head h3{margin:var(--sp3) 0 var(--sp1)}
.qs{max-width:820px}.qs li{display:grid;grid-template-columns:48px minmax(0,1fr);align-items:baseline;padding:10px 0;border-top:1px solid var(--line);margin:0}
.qs li:last-child{border-bottom:1px solid var(--line)}.qs b{font:500 13px var(--f-mono);color:var(--accent);margin:0}
/* indicator strip (size of the corpus) */
.kpis{display:flex;flex-wrap:wrap;margin:var(--sp4) 0 var(--sp3);border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.kpi{flex:1 1 120px;padding:var(--sp2) var(--sp3);border-left:1px solid var(--line);display:flex;flex-direction:column}
.kpi:first-child{border-left:0;padding-left:0}
.kv{font-size:36px;font-weight:500;line-height:1.1;font-variant-numeric:tabular-nums lining-nums;letter-spacing:-.01em}
.kl{color:var(--muted);font-size:13px}
/* status strip (state of the review) */
.problems{box-shadow:none;border-radius:10px;margin:0 0 var(--sp4)}
.problems .ph{padding:var(--sp2) var(--sp3);gap:6px 18px}
.problems .ph b{font-size:15px;margin-right:6px}
.problems .ph .chip-s{background:none!important;border:0!important;padding:0 0 0 14px;position:relative;color:var(--ink);font-size:13px}
.problems .ph .chip-s::before{content:"";position:absolute;left:0;top:.5em;width:8px;height:8px;border-radius:50%;background:var(--muted)}
.problems .ph .chip-s.error::before{background:var(--err)}.problems .ph .chip-s.warning::before{background:var(--warn)}
.problems .ph .chip-s.edit::before{background:var(--edit)}.problems .ph .chip-s.ok::before{background:var(--okc)}
.problems .ph .chip-s.pend::before{background:var(--s-field)}
.psh{padding:var(--sp2) var(--sp3) var(--sp1)}.problems li{padding:8px var(--sp3)}.none{padding:0 var(--sp3) var(--sp2)}
/* overview sections: space and alignment, no boxes */
.box{background:none;border:0;box-shadow:none;border-radius:0;padding:0;margin:var(--sp4) 0 0}
.grid2{gap:var(--sp4)}.grid2 .box{margin:0}
.box h3,.dash-head h3{font:600 12px var(--f-sans);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin:0 0 var(--sp2)}
details.fold{border-top:1px solid var(--line);padding-top:var(--sp1)}details.fold>summary h3{margin:var(--sp1) 0}
.bars{gap:8px}.bt{height:8px;border-radius:2px}.bf{border-radius:0 3px 3px 0}
/* matrix: the signature piece */
.mx{border-collapse:separate;border-spacing:3px}.mx th,.mx td{padding:0;vertical-align:middle}
.mx .mr{padding:0 var(--sp2) 0 0;font-size:13.5px}.mx th.mc{font:500 12px var(--f-mono);color:var(--muted);padding:0 0 6px;transition:color var(--t)}
.mx .mc{min-width:68px}.mx .tot{font:500 12.5px var(--f-mono);color:var(--muted);padding-left:6px}
.cell{display:flex;align-items:center;justify-content:center;height:32px;padding:0;border:0;border-radius:3px;font:500 12.5px var(--f-mono);
color:var(--ink);transition:box-shadow var(--t) var(--ease),background-color var(--t)}
.cell.zero{height:32px;background:color-mix(in srgb,var(--line) 40%,transparent)}
.mx tr.hl .mr a{font-weight:600}.mx th.hlc{color:var(--accent)}
.mx tr.hl .cell.zero,.mx td.hlc .cell.zero{background:color-mix(in srgb,var(--accent) 9%,var(--panel))}
.mx tr.hl .cell:not(.zero),.mx td.hlc .cell:not(.zero){box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--accent) 55%,transparent)}
.cell:hover{outline:0;box-shadow:inset 0 0 0 2px var(--accent)!important}
.cell.sel{box-shadow:0 0 0 2px var(--ink)!important}
.mxlegend{display:flex;align-items:center;gap:3px;margin-top:var(--sp2);font-size:12px;color:var(--muted)}
.mxlegend .sw{width:32px;height:18px;border-radius:3px;display:inline-flex;align-items:center;justify-content:center;color:var(--ink);
background:color-mix(in srgb,var(--accent) var(--p),var(--panel))}.mxlegend span:last-child{margin-left:8px}
/* block cards: lighter */
.card{box-shadow:none;border-radius:8px;border-left-width:3px;margin:var(--sp2) 0}
.card.nested{border-left-width:2px;margin:var(--sp1) var(--sp2)}
.head{background:transparent;padding:10px var(--sp2)}.body{padding:10px var(--sp2) 12px;row-gap:6px}.foot{padding:8px var(--sp2)}
.chips{padding:10px var(--sp2) 0}.dgs{padding:8px var(--sp2) 0}
.pill{background:var(--pill);border-radius:4px;padding:0 7px}
/* excerpts: editorial text, not code */
.quote{font-family:var(--f-serif);font-style:normal;font-size:17px;line-height:1.6;color:var(--ink);border-left:2px solid var(--qline);padding:1px 0 1px 14px}
/* occurrences panel: editorial unit, brief motion */
#occ{display:block;visibility:hidden;opacity:0;background:rgba(12,20,30,.38);transition:opacity var(--t) var(--ease),visibility 0s linear var(--t)}
#occ.on{visibility:visible;opacity:1;transition:opacity var(--t) var(--ease)}
#occ .panel{transform:translateX(28px);transition:transform 220ms var(--ease);padding:var(--sp3) var(--sp3) var(--sp4);box-shadow:-16px 0 48px rgba(10,20,30,.22);width:min(600px,100%)}
#occ.on .panel{transform:none}
#occ h2{font-size:22px;font-weight:600;color:var(--ink);letter-spacing:-.01em;margin-top:var(--sp1)}
#occ .def{font-size:14px;color:var(--muted);margin:var(--sp1) 0 var(--sp3)}
#occ .oc{background:none;border:0;border-top:1px solid var(--line);border-radius:0;padding:var(--sp3) 0 var(--sp3);margin:0}
#occ .oc.has-error,#occ .oc.has-warn{border-left:0!important;padding-left:14px}
#occ .oc.has-error{box-shadow:inset 3px 0 0 var(--err)}#occ .oc.has-warn{box-shadow:inset 3px 0 0 var(--warn)}
#occ .oc .src{font-size:12px;color:var(--muted)}#occ .oc .src a{font-family:var(--f-sans)}
#occ .oc q{font-family:var(--f-serif);font-style:normal;font-size:18px;line-height:1.6;color:var(--ink);border-left:2px solid var(--qline);padding-left:14px;margin:var(--sp1) 0 var(--sp2)}
#occ .oc .ml{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}
#occ .oc .m{font-size:14px;line-height:1.55;margin-top:2px}
#occ .oc .meta2{display:flex;flex-wrap:wrap;gap:6px;margin-top:var(--sp2)}
#pop{box-shadow:0 8px 28px rgba(10,20,30,.18);border-radius:8px}
/* possibilities tab in the same language */
.poss{box-shadow:none;border-radius:10px;padding:var(--sp3)}.poss h4{font-size:17px;line-height:1.4;letter-spacing:-.005em}
.poss-intro{box-shadow:none;border-left-width:3px;padding:var(--sp2) var(--sp3)}
.askbox p{font-size:13.5px}
@media(max-width:720px){.dash-head h1{font-size:30px}.kpi{flex:1 1 33%;padding:12px 12px 12px 0;border-left:0}.kv{font-size:28px}
main{padding:var(--sp2) 12px 60px}.problems .ph,.psh,.problems li{padding-left:14px;padding-right:14px}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{transition:none!important;animation:none!important;scroll-behavior:auto!important}}
"""

COMP_CSS = """
/* your sources */
.start.srcs{max-width:none}.srcs .steps,.srcs .tw{max-width:900px}.srcs h2{font-size:19px;margin:40px 0 12px}
.srcs .about{max-width:820px}
.srcs code{font:500 .92em var(--f-mono);background:var(--pill);border-radius:4px;padding:1px 6px}
.srcs .privacy{border-left:3px solid var(--warn);padding:4px 0 4px 14px;margin:20px 0;max-width:820px}
.srcs .warnl{color:var(--warn)}
.fmts{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(300px,100%),1fr));gap:14px}
.fmt{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:20px;min-width:0}.fmt h3{margin:0 0 10px;font-size:16px}
.fmt dt{color:var(--muted);font-size:12.5px;margin-top:10px}.fmt dd{margin:0;font-size:14.5px}.fmt dl{margin:0}
.fmt pre{font:12.5px/1.5 var(--f-mono);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:10px;overflow:auto;margin:4px 0 0}
.pdfbox{max-width:820px}.pdfbox ol{padding-left:22px}.pdfbox li{margin:6px 0}
.invt td:first-child{overflow-wrap:anywhere;width:34%}
/* scale: controls and helper texts a little larger */
.hb{font-size:14px;padding:7px 13px}.hrow input{font-size:15px;padding:8px 14px}
.tab{font-size:15px;padding:10px 14px}.navpane a{font-size:14px;padding:4px 12px}
.act{font-size:13.5px;padding:3px 9px}.chip-s{font-size:13px}.prov{font-size:12.5px}
.psh .muted.small,.lead,.muted.small{font-size:13.5px}.problems li{font-size:14.5px}
.box h3,.dash-head h3{font-size:12.5px}.bar-row{font-size:14px}.mxt{font-size:14px}
/* short help */
details.help{margin:0 0 var(--sp1);font-size:13.5px;color:var(--muted)}
details.help>summary{cursor:pointer;list-style:none;display:inline-flex;gap:6px;align-items:center}
details.help>summary::-webkit-details-marker{display:none}
details.help>summary::before{content:"?";display:inline-flex;width:18px;height:18px;border-radius:50%;border:1px solid var(--line);align-items:center;justify-content:center;font:600 11px var(--f-sans)}
.start{max-width:820px;padding:var(--sp2) 0}.start h1{font-size:34px;line-height:1.15;font-weight:600;letter-spacing:-.01em;margin:0 0 var(--sp2)}
.start .about{font-size:17px;line-height:1.6;color:var(--muted);margin:0 0 var(--sp3)}
.steps{list-style:none;counter-reset:st;margin:0 0 var(--sp3);padding:0}
.steps li{counter-increment:st;display:grid;grid-template-columns:44px minmax(0,1fr);gap:4px;padding:14px 0;border-top:1px solid var(--line);font-size:16px;line-height:1.6}
.steps li:last-child{border-bottom:1px solid var(--line)}
.steps li::before{content:counter(st,decimal-leading-zero);font:500 13px/1.9 var(--f-mono);color:var(--accent)}
.steps a{color:var(--accent);font-weight:500}
.tabs{gap:0}.tab{padding:10px 11px;gap:5px}.tab .nb{margin-left:0;padding:0 5px}
@media(max-width:1180px){.tab{font-size:14px;padding:9px 8px}.tab small{display:none}}
.tabs.ovf-r{-webkit-mask-image:linear-gradient(to right,#000 calc(100% - 48px),transparent);mask-image:linear-gradient(to right,#000 calc(100% - 48px),transparent)}
.tabs.ovf-l{-webkit-mask-image:linear-gradient(to left,#000 calc(100% - 48px),transparent);mask-image:linear-gradient(to left,#000 calc(100% - 48px),transparent)}
.tabs.ovf-l.ovf-r{-webkit-mask-image:linear-gradient(to right,transparent,#000 48px,#000 calc(100% - 48px),transparent);mask-image:linear-gradient(to right,transparent,#000 48px,#000 calc(100% - 48px),transparent)}
.ext{display:flex;gap:12px;align-items:center;margin-left:6px;white-space:nowrap}
.ext a{color:var(--muted);text-decoration:none;font-size:13.5px;display:inline-flex;gap:5px;align-items:center}.ext a:hover{color:var(--accent)}
.support{max-width:820px;margin:var(--sp4) 0 var(--sp2);padding:var(--sp3);border:1px solid var(--line);border-radius:10px;background:var(--panel)}
.support h2{font-size:18px;margin:0 0 6px}.support>p{margin:0 0 var(--sp2);color:var(--muted)}
.support ul{list-style:none;margin:0;padding:0}.support li{display:grid;grid-template-columns:minmax(220px,auto) minmax(0,1fr);gap:16px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.support li>span:last-child{color:var(--muted);font-size:14px}
.sbtn{display:inline-flex;gap:8px;align-items:center;background:var(--ink);color:var(--bg);border-radius:6px;padding:8px 14px;text-decoration:none;font:500 14px var(--f-sans);justify-self:start}
.sbtn:hover{filter:brightness(1.15)}.sbtns{display:flex;flex-wrap:wrap;gap:6px}
.sbtn2{font-size:13.5px;padding:6px 10px;border:1px solid var(--line)!important}.sbtn3{color:var(--accent);font-weight:500;text-decoration:none}
.cite-txt{font-size:12px;color:var(--muted);margin:var(--sp2) 0 0;overflow-wrap:anywhere}
.foot-site{max-width:1160px;margin:0 auto;padding:var(--sp3) var(--sp3) var(--sp4);border-top:1px solid var(--line);display:flex;flex-wrap:wrap;gap:8px 22px;font-size:13px;color:var(--muted)}
.foot-site a{color:var(--muted);text-decoration:none;display:inline-flex;gap:5px;align-items:center}.foot-site a:hover{color:var(--accent)}
@media(max-width:720px){.ext{display:none}.support li{grid-template-columns:minmax(0,1fr);gap:6px}}
details.help .hn{color:var(--accent)}
details.help .hbody{margin:10px 0 var(--sp2);padding:var(--sp2) var(--sp3);background:var(--panel);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:8px;max-width:820px;color:var(--ink);font-size:14.5px}
details.help .hbody p{margin:0 0 8px}details.help ol{margin:0 0 8px;padding-left:20px}details.help li{margin:4px 0}
details.help a{color:var(--accent)}
/* validation: summary visible, details on demand */
details.problems>summary{list-style:none;cursor:pointer}details.problems>summary::-webkit-details-marker{display:none}
.problems .more-l{margin-left:auto;color:var(--accent);font-size:13.5px;white-space:nowrap}
.problems .more-l::after{content:" ▾"}details.problems[open] .more-l::after{content:" ▴"}
details.problems:not([open]) .ph{border-bottom:0}
/* matrix + focus panel */
.mxwrap{display:grid;grid-template-columns:minmax(0,max-content) minmax(280px,1fr);gap:var(--sp4);align-items:start}
.mxleft{min-width:0}
.mxsum{position:sticky;top:calc(var(--hh,120px) + 16px);border-left:1px solid var(--line);border-right:0;padding:var(--sp1) 0 var(--sp1) var(--sp3);
width:auto;height:auto;background:none;overflow:visible;display:block}
.mxsum .ey{font:500 11px var(--f-mono);letter-spacing:.14em;text-transform:uppercase;color:var(--accent)}
.mxsum h4{font-size:24px;line-height:1.2;font-weight:600;letter-spacing:-.01em;margin:6px 0 4px;color:var(--ink);overflow-wrap:anywhere}
.mxsum .sub{color:var(--muted);font-size:14px;margin-bottom:var(--sp2)}
.mxsum .defn{font-family:var(--f-serif);font-size:15.5px;line-height:1.6;color:var(--ink);margin:0 0 var(--sp3);
display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical;overflow:hidden}
.mxsum .defn.warnl{font-family:var(--f-sans);color:var(--warn)}
.mxsum .dl2{font:600 12px var(--f-sans);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin:0 0 var(--sp1)}
.mxsum .drow{display:grid;grid-template-columns:minmax(0,10em) 1fr 28px;gap:10px;align-items:center;font:13px var(--f-mono);margin:6px 0}
.mxsum .drow>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mxsum .dbar{height:10px;border-radius:2px;background:color-mix(in srgb,var(--line) 55%,transparent);overflow:hidden}
.mxsum .dbar i{display:block;height:100%;background:var(--accent);border-radius:0 3px 3px 0;transition:width var(--t) var(--ease)}
.mxsum .go{margin-top:var(--sp3);display:inline-block;background:var(--accent);color:#fff;border-radius:6px;padding:9px 16px;font:500 14.5px var(--f-sans);text-decoration:none}
[data-theme=dark] .mxsum .go{color:#0d1a1f}
.mxsum .go:hover{filter:brightness(1.08)}.mxsum .ph2{color:var(--muted);font-size:13px;margin-top:var(--sp2)}
.mx tr.pin .mr a{font-weight:600;color:var(--accent)}.mx .mr a[data-pick]{cursor:pointer}
.scroll-hint{display:none}
/* matrix on phones: names pinned on the left, scroll hint and edge shadow */
@media(max-width:900px){.mxwrap{grid-template-columns:minmax(0,1fr)}.mxsum{position:static;border-left:0;border-top:1px solid var(--line);padding:var(--sp3) 0 0}}
@media(max-width:720px){
.mxsum{display:block!important}
.mxs{position:relative;box-shadow:inset -14px 0 12px -12px color-mix(in srgb,var(--ink) 30%,transparent)}
.mx .mr{position:sticky;left:0;z-index:1;background:var(--bg);min-width:120px;max-width:132px;white-space:normal;font-size:13px;line-height:1.3}
.scroll-hint{display:block;font-size:12.5px;color:var(--muted);margin:6px 0 0}
.kv{font-size:28px}}
"""

EXTRA_JS = r"""
(function(){var d=document,b=d.body,pop=d.createElement('div'),toast=d.createElement('div');pop.id='pop';toast.id='toast';b.appendChild(pop);b.appendChild(toast);
function esc(t){return String(t).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
/* VS Code: the absolute path comes from the page URL (nothing absolute is written in the HTML) */
if(location.protocol!=='file:'){b.classList.add('novs')}
function vsUrl(rel,line){var u=new URL((b.dataset.base||'..')+'/'+rel,location.href),p=decodeURIComponent(u.pathname);if(/^\/[A-Za-z]:/.test(p))p=p.slice(1);return 'vscode://file/'+p+':'+line}
d.querySelectorAll('.act.vs').forEach(function(a){a.href=vsUrl(a.dataset.file,a.dataset.line)});
/* Ask Claude: copy the ready request */
function copy(t){if(navigator.clipboard&&window.isSecureContext){return navigator.clipboard.writeText(t)}var x=d.createElement('textarea');x.value=t;b.appendChild(x);x.select();d.execCommand('copy');x.remove();return Promise.resolve()}
var tt;d.addEventListener('click',function(e){var a=e.target.closest('.ask');if(!a)return;e.preventDefault();e.stopPropagation();copy(a.dataset.ask).then(function(){toast.textContent=a.dataset.msg||T.s.copied;toast.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('on')},2600)})});
/* tabs: #id links switch to the tab of the target; search looks in every tab */
var tabs=[].slice.call(d.querySelectorAll('.tab')),hd=d.querySelector('header.top');
function hh(){d.documentElement.style.setProperty('--hh',hd.offsetHeight+'px')}
var tbar=d.querySelector('.tabs');function ovf(){var o=tbar.scrollWidth>tbar.clientWidth+2;tbar.classList.toggle('ovf-r',o&&tbar.scrollLeft+tbar.clientWidth<tbar.scrollWidth-2);tbar.classList.toggle('ovf-l',o&&tbar.scrollLeft>2)}
tbar.addEventListener('scroll',ovf);addEventListener('resize',ovf);
function act(k){tabs.forEach(function(t){t.setAttribute('aria-selected',t.dataset.tab===k);if(t.dataset.tab===k&&t.scrollIntoView&&tbar.scrollWidth>tbar.clientWidth)t.scrollIntoView({block:'nearest',inline:'nearest'})});d.querySelectorAll('.tabpane,.navpane').forEach(function(p){p.classList.toggle('on',p.dataset.tab===k)});hh();ovf()}
addEventListener('resize',hh);
tabs.forEach(function(t){t.onclick=function(){act(t.dataset.tab);scrollTo(0,0)}});
act(b.dataset.start||'overview');
function go(id){var el=d.getElementById(id);if(!el)return;if(!el.hasAttribute('tabindex'))el.setAttribute('tabindex','-1');setTimeout(function(){el.focus({preventScroll:true})},0);var p=el.closest('.tabpane');if(p)act(p.dataset.tab);var f=el.closest('details');if(f)f.open=true;scrollTo({top:el.getBoundingClientRect().top+scrollY-hd.offsetHeight-10,behavior:'instant'});el.classList.add('flash');setTimeout(function(){el.classList.remove('flash')},1400)}
d.addEventListener('click',function(e){var a=e.target.closest('a[href^="#"]');if(!a||a.classList.contains('vs'))return;var id=a.getAttribute('href').slice(1);if(!id)return;e.preventDefault();pop.style.display='none';go(id);history.replaceState(null,'','#'+id)});
if(location.hash.length>1){var h0=location.hash.slice(1);go(h0);addEventListener('load',function(){setTimeout(function(){go(h0)},0)})}
var q=d.getElementById('q'),fd=d.createElement('p');fd.id='found';d.querySelector('main').insertBefore(fd,d.querySelector('main').children[1]);
function unmark(){d.querySelectorAll('mark.hit').forEach(function(m){var p=m.parentNode;p.replaceChild(d.createTextNode(m.textContent),m);p.normalize()})}
function markIn(el,term){var w=d.createTreeWalker(el,NodeFilter.SHOW_TEXT,null),nodes=[],n;while(n=w.nextNode())nodes.push(n);
nodes.forEach(function(n){var i=n.nodeValue.toLowerCase().indexOf(term);if(i<0||n.parentNode.closest('pre,summary'))return;var r=d.createRange();r.setStart(n,i);r.setEnd(n,i+term.length);var m=d.createElement('mark');m.className='hit';r.surroundContents(m)})}
var st;q.addEventListener('input',function(){clearTimeout(st);st=setTimeout(function(){var term=q.value.trim().toLowerCase();b.classList.toggle('searching',!!term);unmark();var total=0;
d.querySelectorAll('details.file').forEach(function(f){var vis=[].slice.call(f.querySelectorAll('.card:not(.nested)')).filter(function(c){return c.style.display!=='none'});f.style.display=(term&&!vis.length)?'none':'';if(term){f.open=true;vis.forEach(function(c){markIn(c,term)})}total+=vis.length});
d.querySelectorAll('.tabpane').forEach(function(p){if(p.dataset.tab==='overview')return;var any=[].some.call(p.querySelectorAll('details.file'),function(f){return f.style.display!=='none'});p.style.display=term?(any?'block':'none'):''});
fd.textContent=term?(total==1?T.found_n[0]:T.found_n[1]).replace('{n}',total):''},120)});
/* matrix: sort and filter by group */
var mx=d.querySelector('table.mx');if(mx){var tb=mx.tBodies[0],mrows=[].slice.call(tb.rows),so=d.getElementById('mxs'),gf=d.getElementById('mxg');
var mxu=function(){var k=so.value,g=gf?gf.value:'';mrows.sort(function(a,b){if(k==='name')return a.dataset.name.localeCompare(b.dataset.name);return(+b.dataset[k]-+a.dataset[k])||a.dataset.name.localeCompare(b.dataset.name)});
mrows.forEach(function(r){r.style.display=(!g||r.dataset.g===g)?'':'none';tb.appendChild(r)})};so.onchange=mxu;if(gf)gf.onchange=mxu}
/* matrix: focus panel (hover shows; click pins) */
(function(){var mt=d.querySelector('table.mx'),box=d.getElementById('mxsum');if(!mt||!box)return;
var srcs=[].map.call(mt.querySelectorAll('thead th[data-ci]'),function(th){return th.textContent.replace(/^@/,'')}),pinned=null;
function render(name){var list=T.o[name]||[],c=T.c[name],per={},mx=1;srcs.forEach(function(s){per[s]=0});list.forEach(function(o){per[o.s]=(per[o.s]||0)+1});
srcs.forEach(function(s){mx=Math.max(mx,per[s])});var seen={};list.forEach(function(o){seen[o.s]=1});var k=Object.keys(seen).length;
var h='<div class="ey">'+esc(T.s.focus)+'</div><h4>'+esc(name)+'</h4><div class="sub">'+esc(T.s.in_k.replace('{n}',list.length).replace('{k}',k).replace('{s}',mt.dataset.ns||srcs.length))+'</div>';
h+=c&&c.f.length?'<p class="defn">'+esc(c.f[0][1])+'</p>':(T.u.indexOf(name)>-1?'<p class="defn warnl">'+esc(T.s.no_def)+'</p>':'<p class="defn muted">'+esc(T.s.no_entry)+'</p>');
h+='<div class="dl2">'+esc(T.s.dist)+'</div>'+srcs.map(function(s){return'<div class="drow"><span>@'+esc(s)+'</span><span class="dbar"><i style="width:'+Math.round(100*per[s]/mx)+'%"></i></span><span>'+per[s]+'</span></div>'}).join('');
h+='<a href="#" class="go" data-occ="'+esc(name)+'">'+esc((list.length==1?T.see_all[0]:T.see_all[1]).replace('{n}',list.length))+' →</a><div class="ph2">'+esc(T.s.pick_hint)+'</div>';
box.innerHTML=h}
function pin(name){pinned=name;mt.querySelectorAll('tr.pin').forEach(function(r){r.classList.remove('pin')});var r=mt.querySelector('tbody tr[data-name="'+name.replace(/"/g,'\\"')+'"]');if(r)r.classList.add('pin');render(name)}
var first=mt.querySelector('tbody tr');if(first)pin(first.dataset.name);
mt.addEventListener('mouseover',function(e){var tr=e.target.closest('tbody tr');if(tr)render(tr.dataset.name)});
mt.addEventListener('mouseleave',function(){if(pinned)render(pinned)});
mt.addEventListener('click',function(e){var a=e.target.closest('[data-pick]');if(!a)return;e.preventDefault();pin(a.dataset.pick)});
mt.addEventListener('focusin',function(e){var a=e.target.closest('[data-pick]');if(a)render(a.dataset.pick)});
var so=d.getElementById('mxs'),gf=d.getElementById('mxg');[so,gf].forEach(function(x){if(x)x.addEventListener('change',function(){var v=[].filter.call(mt.querySelectorAll('tbody tr'),function(r){return r.style.display!=='none'});if(v.length&&(!pinned||v.every(function(r){return r.dataset.name!==pinned})))pin(v[0].dataset.name)})})})();
/* technical details: explicit state */
var cb=d.getElementById('code');cb.onclick=function(){var on=!b.classList.contains('tech');b.classList.toggle('tech',on);b.classList.remove('nocode');cb.setAttribute('aria-pressed',on);cb.textContent=on?T.s.tech_on:T.s.tech_off};
/* occurrences of a concept: excerpt, memo and source */
var oc=d.createElement('div');oc.id='occ';oc.innerHTML='<div class="panel" role="dialog" aria-modal="true" aria-labelledby="occ-t" tabindex="-1"></div>';var opener=null;b.appendChild(oc);
function closeOcc(restore){if(!oc.classList.contains('on'))return;oc.classList.remove('on');d.querySelectorAll('.cell.sel').forEach(function(c){c.classList.remove('sel')});if(restore!==false&&opener&&opener.isConnected&&opener.focus)opener.focus();opener=null}
function openOcc(c,src,from){opener=from||d.activeElement;var list=(T.o[c]||[]).filter(function(o){return!src||o.s===src}),def=T.c[c],h='<button class="hb x" type="button">'+T.s.close+'</button><h2 id="occ-t">'+esc(c)+'</h2>';
h+='<div class="meta muted small">'+esc((list.length==1?T.occ_n[0]:T.occ_n[1]).replace('{n}',list.length))+(src?' · '+esc(T.s.in_src.replace('{s}',src)):'')+'</div>';
if(def&&def.f.length)h+='<div class="def">'+esc(def.f[0][1])+'</div>';else h+=(T.u.indexOf(c)>-1?'<div class="def warnl">'+T.s.undef+'</div>':'<div class="def">'+esc(T.s.no_entry)+'</div>');
list.forEach(function(o){var cd=d.getElementById(o.id),qe=cd&&cd.querySelector('.quote'),fe=cd&&T.mf&&cd.querySelector('.fname[data-f="'+T.mf+'"]'),fv=fe&&fe.parentNode.nextElementSibling,qt=qe?qe.textContent:'',mt2=fv?fv.textContent:'',fl='';if(o.e||o.w)fl+='<span class="chip-s '+(o.e?'error':'warning')+'">'+esc(T.s.oc_diag.replace('{e}',o.e).replace('{w}',o.w))+'</span>';
if(o.nf)fl+='<span class="chip-s warning" title="'+esc(T.s.q_note)+'">✕ '+esc(T.s.q_notfound)+'</span>';if(o.ed)fl+='<span class="chip-s edit">✎ '+esc(T.s.hand_edit)+'</span>';
var cs=(o.cs||[]).map(function(x){return'<span class="pill'+(T.u.indexOf(x)>-1?' undef':'')+'" data-c="'+esc(x)+'" tabindex="0">'+esc(x)+'</span>'}).join('');
h+='<article class="oc'+(o.e?' has-error':(o.w||o.nf)?' has-warn':'')+'"><div class="src"><span>@'+esc(o.s)+' · '+esc(o.f)+':'+o.l+'</span><a href="#'+o.id+'">'+T.s.go_block+' →</a></div>'
+(qt?'<q>'+esc(qt)+'</q>':'')+(mt2?'<div class="ml">'+esc(T.mf)+'</div><div class="m">'+esc(mt2)+'</div>':'')
+'<div class="meta2">'+cs+fl+'</div></article>'});
oc.firstChild.innerHTML=h;oc.classList.add('on');oc.firstChild.scrollTop=0;var xb=oc.querySelector('.x');xb.onclick=function(){closeOcc()};xb.focus()}
oc.addEventListener('click',function(e){if(e.target===oc)closeOcc();if(e.target.closest('a[href^="#c-"]'))closeOcc(false)});
oc.addEventListener('keydown',function(e){if(e.key!=='Tab')return;var f=[].slice.call(oc.querySelectorAll('a[href],button'));if(!f.length)return;var a=f[0],z=f[f.length-1];
if(e.shiftKey&&(d.activeElement===a||!oc.contains(d.activeElement))){e.preventDefault();z.focus()}else if(!e.shiftKey&&(d.activeElement===z||!oc.contains(d.activeElement))){e.preventDefault();a.focus()}});
d.addEventListener('click',function(e){var a=e.target.closest('[data-occ]');if(!a)return;e.preventDefault();var from=a.closest('#pop')?cur:a;pop.style.display='none';d.querySelectorAll('.cell.sel').forEach(function(c){c.classList.remove('sel')});if(a.classList.contains('cell'))a.classList.add('sel');openOcc(a.dataset.occ,a.dataset.src,from)});
(function(){var mt=d.querySelector('table.mx');if(!mt)return;function clr(){mt.querySelectorAll('.hl,.hlc').forEach(function(x){x.classList.remove('hl','hlc')})}
mt.addEventListener('mouseover',function(e){var td=e.target.closest('td.mc[data-ci]');clr();if(!td)return;td.parentNode.classList.add('hl');mt.querySelectorAll('[data-ci="'+td.dataset.ci+'"]').forEach(function(x){x.classList.add('hlc')})});
mt.addEventListener('mouseleave',clr)})();
d.addEventListener('keydown',function(e){if(e.key==='Escape')closeOcc()});
/* hover tips */
function fieldHtml(n){var f=T.f[n];if(!f)return'';var h='<h4>'+esc(n)+'</h4><div class="meta">'+esc(f.t)+' · '+T.s.scope+' '+esc(f.s)+'</div>';if(f.d)h+='<div>'+esc(f.d)+'</div>';
var rk=Object.keys(f.r||{});if(rk.length){h+='<div class="sec">'+T.s.declared_rel+'</div><dl>'+rk.map(function(k){return'<dt>'+esc(k)+'</dt><dd>'+esc(f.r[k])+'</dd>'}).join('')+'</dl>'}
if(f.v&&f.v.length){h+='<div class="sec">'+T.s.values+'</div><dl>'+f.v.map(function(v){return'<dt>'+esc(v[0])+'</dt><dd>'+esc(v[1])+'</dd>'}).join('')+'</dl>'}
if(f.g&&f.g.length){h+='<div class="sec">'+T.s.guidelines+'</div>'+f.g.map(function(g){var c=/^(Correct|Correto)\s*:/i.test(g)?' good':/^(Wrong|Errado|Incorrect|Incorreto)\s*:/i.test(g)?' bad':'';return'<div class="g'+c+'">'+esc(g)+'</div>'}).join('')}return h}
function conceptHtml(n){var c=T.c[n],k0=(T.o[n]||[]).length;if(!c)return'<h4>'+esc(n)+'</h4>'+(T.u.indexOf(n)>-1?'<div class="warnl">'+T.s.undef+'</div><div>'+T.s.undef_hint+'</div>':'<div class="meta">'+esc(T.s.no_entry)+'</div>')+(k0?'<div style="margin-top:6px"><a href="#" data-occ="'+esc(n)+'">'+T.s.see_occ+' ('+k0+') →</a></div>':'');
var h='<h4>'+esc(n)+'</h4><div class="meta">'+esc((c.n==1?T.uses[0]:T.uses[1]).replace('{n}',c.n))+'</div>';
h+='<dl>'+c.f.map(function(p){return'<dt>'+esc(p[0])+'</dt><dd>'+esc(p[1])+'</dd>'}).join('')+'</dl>';
var k=(T.o[n]||[]).length;h+='<div style="margin-top:6px;display:flex;gap:14px">';if(k)h+='<a href="#" data-occ="'+esc(n)+'">'+T.s.see_occ+' ('+k+') →</a>';
if(c.file){var id='c-'+c.file.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-'+c.line;if(d.getElementById(id))h+='<a href="#'+id+'">'+T.s.goto_def+' →</a>'}return h+'</div>'}
function relHtml(n,f){var r=(T.r[f]||{});if(r[n]!==undefined)return'<h4>'+esc(n)+'</h4><div class="meta">'+esc(f)+'</div><div>'+esc(r[n])+'</div>';
return'<h4>'+esc(n)+'</h4><div class="warnl">'+T.s.rel_undef+'</div><div class="sec">'+T.s.declared_rel+'</div><dl>'+Object.keys(r).map(function(k){return'<dt>'+esc(k)+'</dt><dd>'+esc(r[k])+'</dd>'}).join('')+'</dl>'}
function kwHtml(el){var k=el.dataset.k,v=el.dataset.kv||'',f=el.dataset.kf||'',m=T.k[k+(v&&T.k[k+':'+v]?':'+v:'')]||T.k[k];if(!m)return'';
var title=k.indexOf('T:')===0?k.slice(2):(k==='INC:ONTOLOGY'?'ONTOLOGY':k.replace('@P',''))+(v&&k!=='END'?' '+v:'');if(k==='END')title='END '+v;
return'<h4>'+esc(title)+'</h4><div>'+esc(m.replace(/\{f\}/g,f).replace(/\{v\}/g,v))+'</div>'}
var hide,cur;function show(el){var h=el.dataset.k?kwHtml(el):el.dataset.f?fieldHtml(el.dataset.f):el.dataset.c?conceptHtml(el.dataset.c):relHtml(el.dataset.r,el.dataset.rf);if(!h)return;
clearTimeout(hide);cur=el;pop.innerHTML=h;pop.style.display='block';var r=el.getBoundingClientRect(),w=pop.offsetWidth,x=Math.min(r.left+scrollX,scrollX+d.documentElement.clientWidth-w-12),y=r.bottom+scrollY+6;
if(r.bottom+pop.offsetHeight+12>innerHeight&&r.top>pop.offsetHeight+12)y=r.top+scrollY-pop.offsetHeight-6;pop.style.left=Math.max(8,x)+'px';pop.style.top=y+'px'}
function later(){clearTimeout(hide);hide=setTimeout(function(){pop.style.display='none';cur=null},220)}
d.addEventListener('mouseover',function(e){var el=e.target.closest('[data-k],[data-f],[data-c],[data-r]');if(el&&el!==cur)show(el);else if(e.target.closest('#pop'))clearTimeout(hide)});
d.addEventListener('mouseout',function(e){if(e.target.closest('[data-k],[data-f],[data-c],[data-r],#pop'))later()});
d.addEventListener('focusin',function(e){var el=e.target.closest('[data-k],[data-f],[data-c],[data-r]');if(el)show(el)});
d.addEventListener('focusout',later);d.addEventListener('keydown',function(e){if(e.key==='Escape'){pop.style.display='none';cur=null}});
})();
"""

PAGE = """<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="generator" content="Synesis Skill - project view">
<title>{title} · {s_title}</title>
<style>{css}</style></head><body data-base="{base}" data-start="{start}">
<header class="top"><div class="hrow"><div class="brand"><b>{title}</b><span>{s_title}</span></div>
<input id="q" type="search" placeholder="{s_search}" aria-label="{s_search}">
<button id="code" class="hb" type="button" aria-pressed="false">{s_code}</button><button id="theme" class="hb" type="button">{s_theme}</button>
<nav class="ext" aria-label="Synesis"><a href="{docs_url}" target="_blank" rel="noopener">{l_docs} ↗</a><a class="gh" href="{gh_url}" target="_blank" rel="noopener" title="GitHub">{gh_svg}<span>GitHub</span></a></nav></div>
<nav class="tabs" role="tablist">{tabs}</nav><div class="files">{navs}</div></header>
<main>{body}<p class="nomatch" id="nomatch">{s_nomatch}</p></main>
<footer class="foot-site"><span>{l_made}</span><a href="{docs_url}" target="_blank" rel="noopener">synesis-lang.org</a>
<a href="{gh_url}" target="_blank" rel="noopener">{gh_svg} GitHub</a><a href="#support">{l_cite}</a></footer>
<script>{js}</script></body></html>
"""
