# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Offline audit dashboard: one HTML file, data embedded, no server, no CDN.

Four inputs, computed together from the same project state:
analytic JSON (compiler library), validation report, anchoring report, run
records (manifests + decisions). Imported audit marks are embedded too.
The output depends only on the project files, so two copies of the same
project produce byte-identical dashboards (no clock, no absolute paths).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from . import anchor as anchor_mod
from . import runs as runs_mod
from .common import dumps, read_json, sha256_bytes, sha256_file, write_json
from .project import check_template, compile_project, find_continuation_lines

ASSET = Path(__file__).resolve().parents[2] / "assets" / "dashboard.html"
PLACEHOLDER = "/*__SYNESIS_DATA__*/null"

_RUN_KEYS = ("id", "mode", "target", "backend", "model", "versions", "status", "passes",
             "created_on", "accepted_on", "project_state_before", "inputs", "outputs",
             "accepted_files", "requests_answered", "unused_responses", "pending", "error")


def normalize_marks(data: Dict[str, Any]) -> Dict[str, Any]:
    marks = []
    for m in data.get("marks", []):
        marks.append({k: m.get(k) for k in ("target", "kind", "verdict", "note", "state")})
    marks.sort(key=lambda m: (str(m.get("kind")), str(m.get("target"))))
    return {"kind": "synesis-skill/marks", "project": data.get("project"), "marks": marks}


def gather(synp: Path) -> Dict[str, Any]:
    synp = Path(synp).resolve()
    base = synp.parent
    compiled = compile_project(synp)
    state = compiled["state"]["state"]
    analytic = compiled["analytic"] or {}
    anchoring = anchor_mod.check(base, analytic, state)
    manifests = runs_mod.list_runs(synp)
    stale: List[Dict[str, str]] = []
    for m in manifests:
        for f, sha in (m.get("accepted_files") or {}).items():
            p = base / f
            if not p.exists():
                stale.append({"what": f, "why": f"accepted from run {m['id']} but no longer in the project"})
            elif sha256_file(p) != sha:
                stale.append({"what": f, "why": f"edited after acceptance of run {m['id']} (not recorded as a run)"})
        if m.get("status") in ("started", "pending", "stale", "failed"):
            stale.append({"what": f"run {m['id']}", "why": f"run is {m['status']}"})
    marks_path = runs_mod.runs_dir(synp) / "audit" / "marks.json"
    marks = read_json(marks_path) if marks_path.exists() else {"marks": []}
    for mk in marks.get("marks", []):
        if mk.get("state") and mk["state"] != state:
            stale.append({"what": f"mark on {mk.get('target')}", "why": "made on an earlier project state"})
            break
    template_check = check_template(synp)
    continuation = find_continuation_lines(synp)
    return {
        "kind": "synesis-skill/dashboard",
        "project": {"name": synp.stem, "state": state},
        "validation": compiled["validation"],
        "analytic": analytic,
        "anchoring": anchoring,
        "runs": [{k: m.get(k) for k in _RUN_KEYS if m.get(k) is not None} for m in manifests],
        "decisions": runs_mod.decisions(synp),
        "marks": marks.get("marks", []),
        "template_check": template_check,
        "continuation_lines": continuation,
        "stale": stale,
    }


def render(data: Dict[str, Any]) -> str:
    template = ASSET.read_text(encoding="utf-8")
    payload = dumps(data).strip().replace("</", "<\\/")
    if PLACEHOLDER not in template:
        raise RuntimeError("dashboard asset has no data placeholder")
    return template.replace(PLACEHOLDER, payload)


def build(synp: Path, out: Path) -> Dict[str, Any]:
    data = gather(synp)
    html = render(data)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(html)
    ready = data["validation"]["ready"] and data["anchoring"]["verified"] and not data["stale"]
    return {"bytes": len(html.encode("utf-8")), "ready": ready, "stale": len(data["stale"])}


def rebuild(synp: Path, out_dir: Path) -> Dict[str, str]:
    """Regenerate every derived artefact into `out_dir`; return their hashes."""
    data = gather(synp)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "analytic.json", data["analytic"])
    write_json(out_dir / "validation.json", data["validation"])
    write_json(out_dir / "anchoring.json", data["anchoring"])
    html = render(data)
    with open(out_dir / "dashboard.html", "w", encoding="utf-8", newline="\n") as fh:
        fh.write(html)
    return {name: sha256_bytes((out_dir / name).read_bytes())
            for name in ("analytic.json", "validation.json", "anchoring.json", "dashboard.html")}
