# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Shared helpers: hashing, deterministic JSON, project state, paths."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List

PROTOCOL_VERSION = "synesis-skill/1"

# Files that make up the state of a Synesis project. Generated folders are
# excluded so that a rebuild never changes the state it is measured against.
STATE_SUFFIXES = {".synp", ".synt", ".syn", ".syno", ".bib", ".toml"}
# A folder with this file holds raw material waiting to be prepared (sk.py intake): not project state yet.
INBOX_MARKER = ".synesis-inbox.json"
EXCLUDED_DIRS = {"runs", "saida", "output", "dashboard", ".git", "__pycache__", "_skill", "view", "review"}


def synesis_version() -> tuple:
    """Installed compiler version as a tuple of ints, (0, 0, 0) when it cannot be read."""
    try:
        from importlib.metadata import version

        return tuple(int(x) for x in re.findall(r"\d+", version("synesis"))[:3])
    except Exception:  # noqa: BLE001
        return (0, 0, 0)


def compiler_has_fixes() -> bool:
    """True from synesis 0.16.0: continuation lines are kept (C-1) and an empty file is not an error (C-2)."""
    return synesis_version() >= (0, 16, 0)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(Path(path).read_bytes())


def dumps(obj: Any) -> str:
    """Deterministic JSON: sorted keys, UTF-8, LF, trailing newline."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def write_json(path: Path, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(dumps(obj))


def read_json(path: Path) -> Any:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def append_jsonl(path: Path, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(obj, ensure_ascii=False, sort_keys=True) + "\n")


def read_jsonl(path: Path) -> List[Any]:
    path = Path(path)
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


def rel(path: Any, base: Path) -> str:
    """Path relative to `base`, POSIX style. Paths outside `base` keep only the name."""
    p = Path(str(path))
    try:
        return p.resolve().relative_to(Path(base).resolve()).as_posix()
    except (ValueError, OSError):
        return p.name


SOURCE_DIRS = {"fontes", "sources"}       # top-level folders of the source texts (as sklib/anchor.py reads them)
SOURCE_SUFFIXES = {".txt", ".md"}


def iter_state_files(project_dir: Path) -> Iterable[Path]:
    """Synesis files of the project folder, plus the source texts in fontes/ or sources/: the coder
    and the anchoring read them, so a change in a source text changes the state of the project."""
    project_dir = Path(project_dir)
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith(".")
                         and not (Path(root) / d / INBOX_MARKER).exists())
        in_sources = Path(root).relative_to(project_dir).parts[:1] in [(d,) for d in SOURCE_DIRS]
        for name in sorted(files):
            p = Path(root) / name
            if name.endswith(".bak"):
                continue
            suffix = p.suffix.lower()
            if suffix in STATE_SUFFIXES or (in_sources and suffix in SOURCE_SUFFIXES):
                yield p


def project_state(synp: Path) -> Dict[str, Any]:
    """Hash of every project file, plus one hash over all of them."""
    project_dir = Path(synp).resolve().parent
    files = {rel(p, project_dir): sha256_file(p) for p in iter_state_files(project_dir)}
    combined = sha256_bytes(dumps(files).encode("utf-8"))
    return {"files": files, "state": combined}


_WIN_ABS = re.compile(r"^[A-Za-z]:[\\/]")


def relativize(obj: Any, base: Path) -> Any:
    """Replace absolute paths inside a JSON-like structure by project-relative ones.

    The compiler writes absolute paths in `template.field_specs.*.location.file`.
    A dashboard or report shared with others must not expose the author's folders,
    and two copies of the same project must produce the same bytes.
    """
    if isinstance(obj, dict):
        return {k: relativize(v, base) for k, v in obj.items()}
    if isinstance(obj, list):
        return [relativize(v, base) for v in obj]
    if isinstance(obj, str) and (_WIN_ABS.match(obj) or (obj.startswith("/") and len(obj) > 1)):
        if Path(obj).suffix:  # only file-like strings
            return rel(obj, base)
    return obj


def die(message: str, code: int = 2) -> "NoReturn":  # type: ignore[name-defined]
    print(f"error: {message}", file=sys.stderr)
    raise SystemExit(code)
