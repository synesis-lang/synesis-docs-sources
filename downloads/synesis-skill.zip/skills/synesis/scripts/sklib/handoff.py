"""LLM clients injected into synesis-coder modes without modifying the package.

The coder builds `LLMClient(...)` by name inside each mode module. The runner
replaces that name, for the duration of one run, with one of these classes:

- `make_recording_client(...)`: the real client (API). Every request and
  response is written to the run record.
- `make_handoff_client(...)`: no model call. A request whose response is not in
  the queue is written as `requests/<id>.md` + `.json` and raises
  `PendingRequest`. The Claude Code session (the subscriber's own session)
  writes `responses/<id>.txt`; the next pass returns it and the coder's own
  parser, validator and assembler run unchanged.

The request id hashes everything that determines the answer, so a response
can never be applied to a different request (stale responses are unused).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .common import PROTOCOL_VERSION, append_jsonl, dumps, sha256_bytes, write_json


class PendingRequest(RuntimeError):
    """Raised when a handoff request has no response yet."""


def _task_key() -> Optional[int]:
    import asyncio

    try:
        task = asyncio.current_task()
    except RuntimeError:
        return None
    return id(task) if task is not None else None


def request_id(kind: str, messages: List[dict], schema: Optional[dict], correction: bool) -> str:
    payload = {"protocol": PROTOCOL_VERSION, "kind": kind, "messages": messages,
               "schema": schema, "correction": bool(correction)}
    return sha256_bytes(dumps(payload).encode("utf-8"))[:24]


def _render_markdown(rid: str, kind: str, messages: List[dict], schema: Optional[dict],
                     response_path: Path) -> str:
    parts = [f"# Synesis coder request `{rid}`", ""]
    parts.append("You are the language model inside a synesis-coder run. Answer this request "
                 "exactly as an API model would: follow the SYSTEM text and the messages, "
                 "use only the source text they contain, and add no commentary.")
    if schema is not None:
        parts.append("Your answer must be ONE JSON object that conforms to the JSON SCHEMA "
                     "below. No markdown fences, no text before or after it.")
    else:
        parts.append("Your answer is plain text in the format the messages ask for.")
    # Relative to the run folder: the record is shared, absolute paths are not.
    parts.append(f"Write the raw answer to `responses/{response_path.name}` inside this run folder.")
    parts.append("")
    for m in messages:
        parts.append(f"## {str(m.get('role', 'user')).upper()}")
        parts.append("")
        parts.append(str(m.get("content", "")))
        parts.append("")
    if schema is not None:
        parts.append("## JSON SCHEMA")
        parts.append("")
        parts.append("```json")
        parts.append(json.dumps(schema, ensure_ascii=False, indent=2))
        parts.append("```")
    return "\n".join(parts) + "\n"


class _Queue:
    def __init__(self, run_dir: Path):
        self.run_dir = run_dir
        self.req = run_dir / "requests"
        self.resp = run_dir / "responses"
        self.req.mkdir(parents=True, exist_ok=True)
        self.resp.mkdir(parents=True, exist_ok=True)
        self.used: set[str] = set()
        self.pending: set[str] = set()
        self.json_pending: set[str] = set()

    def lookup(self, kind: str, messages: List[dict], schema: Optional[dict],
               correction: bool) -> tuple[str, Optional[str]]:
        rid = request_id(kind, messages, schema, correction)
        path = self.resp / f"{rid}.txt"
        if path.exists():
            self.used.add(rid)
            return rid, path.read_text(encoding="utf-8")
        return rid, None

    def write_request(self, rid: str, kind: str, messages: List[dict], schema: Optional[dict],
                      correction: bool) -> None:
        self.pending.add(rid)
        jpath = self.req / f"{rid}.json"
        if not jpath.exists():
            write_json(jpath, {"id": rid, "kind": kind, "messages": messages,
                               "schema": schema, "correction": correction})
            response_path = self.resp / f"{rid}.txt"
            (self.req / f"{rid}.md").write_text(
                _render_markdown(rid, kind, messages, schema, response_path),
                encoding="utf-8", newline="\n")

    def record(self, rid: str, kind: str, messages: List[dict], schema: Optional[dict],
               correction: bool, response: Optional[str]) -> None:
        jpath = self.req / f"{rid}.json"
        if not jpath.exists():
            write_json(jpath, {"id": rid, "kind": kind, "messages": messages,
                               "schema": schema, "correction": correction})
        if response is not None:
            (self.resp / f"{rid}.txt").write_text(response, encoding="utf-8", newline="\n")
        self.used.add(rid)
        append_jsonl(self.run_dir / "calls.jsonl", {"id": rid, "kind": kind,
                                                     "correction": correction,
                                                     "answered": response is not None})


def _fix_messages(previous_output: str, errors: str, system: Optional[str]) -> List[dict]:
    from synesis_coder.llm_client import LLMClient

    # A @staticmethod in synesis-coder 0.15.0: the same messages the API path sends.
    return LLMClient._build_fix_messages(previous_output, errors, system)


def make_handoff_client(run_dir: Path, declared_model: str):
    from synesis_coder.llm_client import _parse_json_response
    from synesis_coder.token_usage import TokenUsage

    queue = _Queue(run_dir)

    class HandoffClient:
        backend = "handoff"
        _api_url = ""

        def __init__(self, model: Optional[str] = None, recorder: Any = None, **_: Any):
            self.model = declared_model
            self.recorder = recorder
            self.usage = TokenUsage()
            self.queue = queue

        def supports_json_schema(self) -> bool:
            return True

        def thinking_label(self, want_thinking: bool = False) -> str:
            return ""

        def _answer(self, kind: str, messages: List[dict], schema: Optional[dict],
                    correction: bool) -> str:
            rid, text = queue.lookup(kind, messages, schema, correction)
            if text is None:
                task = _task_key()
                if kind == "text" and task is not None and task in queue.json_pending:
                    # The coder falls back to free text, in the same task, when the
                    # JSON call fails. A JSON request that is merely unanswered is
                    # not a failure: do not ask the question a second time.
                    raise PendingRequest(rid)
                if kind == "json" and task is not None:
                    queue.json_pending.add(task)
                queue.write_request(rid, kind, messages, schema, correction)
                raise PendingRequest(rid)
            return text

        # --- JSON path -------------------------------------------------
        def call_json(self, messages, schema, temperature=None, max_tokens=0, correction=False):
            text = self._answer("json", messages, schema, correction)
            return _parse_json_response(text)

        async def call_json_async(self, messages, schema, temperature=None, max_tokens=0,
                                  context=None, correction=False):
            return self.call_json(messages, schema, correction=correction)

        # --- text path -------------------------------------------------
        def call(self, messages, temperature=None, max_tokens=0, thinking=True, thinking_budget=None):
            return self._answer("text", messages, None, False)

        async def call_async(self, messages, temperature=None, max_tokens=0, thinking=True,
                             thinking_budget=None, context=None):
            return self.call(messages)

        # --- correction ------------------------------------------------
        def fix(self, previous_output, errors, temperature=0.2, max_tokens=0, system=None, schema=None):
            return self._answer("fix", _fix_messages(previous_output, errors, system), schema, True)

        async def fix_async(self, previous_output, errors, temperature=0.2, max_tokens=0,
                            context=None, system=None, schema=None):
            return self.fix(previous_output, errors, system=system, schema=schema)

    return HandoffClient, queue


def make_recording_client(run_dir: Path):
    """Real LLMClient subclass that records every request/response in the run."""
    from synesis_coder.llm_client import LLMClient

    queue = _Queue(run_dir)

    class RecordingClient(LLMClient):  # type: ignore[misc]
        def __init__(self, *args: Any, **kwargs: Any):
            super().__init__(*args, **kwargs)
            queue.model = f"{self.backend}:{self.model}"  # type: ignore[attr-defined]

        def call_json(self, messages, schema, temperature=None, max_tokens=16000, correction=False):
            data = super().call_json(messages, schema, temperature=temperature,
                                     max_tokens=max_tokens, correction=correction)
            rid = request_id("json", messages, schema, correction)
            queue.record(rid, "json", messages, schema, correction,
                         None if data is None else json.dumps(data, ensure_ascii=False))
            return data

        async def call_json_async(self, messages, schema, temperature=None, max_tokens=16000,
                                  context=None, correction=False):
            data = await super().call_json_async(messages, schema, temperature=temperature,
                                                 max_tokens=max_tokens, context=context,
                                                 correction=correction)
            rid = request_id("json", messages, schema, correction)
            queue.record(rid, "json", messages, schema, correction,
                         None if data is None else json.dumps(data, ensure_ascii=False))
            return data

        def call(self, messages, temperature=None, max_tokens=16000, thinking=True, thinking_budget=None):
            text = super().call(messages, temperature=temperature, max_tokens=max_tokens,
                                thinking=thinking, thinking_budget=thinking_budget)
            queue.record(request_id("text", messages, None, False), "text", messages, None, False, text)
            return text

        async def call_async(self, messages, temperature=None, max_tokens=16000, thinking=True,
                             thinking_budget=None, context=None):
            text = await super().call_async(messages, temperature=temperature, max_tokens=max_tokens,
                                            thinking=thinking, thinking_budget=thinking_budget,
                                            context=context)
            queue.record(request_id("text", messages, None, False), "text", messages, None, False, text)
            return text

        def fix(self, previous_output, errors, temperature=0.2, max_tokens=16000, system=None, schema=None):
            text = super().fix(previous_output, errors, temperature=temperature,
                               max_tokens=max_tokens, system=system, schema=schema)
            msgs = _fix_messages(previous_output, errors, system)
            queue.record(request_id("fix", msgs, schema, True), "fix", msgs, schema, True, text)
            return text

        async def fix_async(self, previous_output, errors, temperature=0.2, max_tokens=16000,
                            context=None, system=None, schema=None):
            text = await super().fix_async(previous_output, errors, temperature=temperature,
                                           max_tokens=max_tokens, context=context,
                                           system=system, schema=schema)
            msgs = _fix_messages(previous_output, errors, system)
            queue.record(request_id("fix", msgs, schema, True), "fix", msgs, schema, True, text)
            return text

    return RecordingClient, queue
