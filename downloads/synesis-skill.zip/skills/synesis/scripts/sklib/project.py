"""Compile a project through the synesis library: diagnostics, analytic JSON, template check."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from .common import project_state, rel, relativize

# Fixed instant written into `export_metadata`: the analytic JSON must not change
# between two builds of the same project state.
FIXED_GENERATED_AT = "1970-01-01T00:00:00+00:00"


def _enum_name(value: Any) -> str:
    return getattr(value, "name", None) or str(value)


def _diag(err: Any, severity: str, base: Path) -> Dict[str, Any]:
    loc = getattr(err, "location", None)
    entry: Dict[str, Any] = {
        "severity": severity,
        "code": type(err).__name__,
        "file": rel(loc.file, base) if loc and getattr(loc, "file", None) else None,
        "line": getattr(loc, "line", None) if loc else None,
        "column": getattr(loc, "column", None) if loc else None,
    }
    try:
        entry["message"] = err.to_diagnostic()
    except Exception:  # pragma: no cover - defensive, message is informative only
        entry["message"] = str(err)
    return entry


def compile_project(synp: Path, check_codes: bool = True) -> Dict[str, Any]:
    """Compile `synp` and return {validation, analytic, template, state}.

    Never raises on project errors: the dashboard has to show them.
    """
    from synesis.compiler import SynesisCompiler
    from synesis.exporters.json_export import build_json_payload

    synp = Path(synp).resolve()
    base = synp.parent
    state = project_state(synp)
    result = SynesisCompiler(synp, check_codes=check_codes).compile()
    vr = result.validation_result
    diagnostics: List[Dict[str, Any]] = []
    for severity, items in (("error", vr.errors), ("warning", vr.warnings), ("info", vr.info)):
        diagnostics.extend(_diag(e, severity, base) for e in items)
    diagnostics.sort(key=lambda d: (d["file"] or "", d["line"] or 0, d["column"] or 0, d["code"]))

    analytic: Optional[Dict[str, Any]] = None
    if result.linked_project is not None:
        payload = build_json_payload(
            result.linked_project,
            result.template,
            result.bibliography,
            result.dataset,
            generated_at=FIXED_GENERATED_AT,
        )
        analytic = relativize(payload, base)

    errors = sum(1 for d in diagnostics if d["severity"] == "error")
    warnings = sum(1 for d in diagnostics if d["severity"] == "warning")
    validation = {
        "kind": "synesis-skill/validation",
        "project": synp.name,
        "state": state["state"],
        "errors": errors,
        "warnings": warnings,
        # "ready" is the strict criterion: no errors and no warnings.
        "ready": errors == 0 and warnings == 0,
        "diagnostics": diagnostics,
    }
    return {
        "validation": validation,
        "analytic": analytic,
        "template": result.template,
        "state": state,
        "result": result,
    }


def check_template(synp: Path) -> Dict[str, Any]:
    """Fields without GUIDELINES and GUIDELINES lines altered by the parser."""
    synp = Path(synp).resolve()
    compiled = compile_project(synp, check_codes=False)
    template = compiled["template"]
    if template is None:
        return {"ok": False, "error": "template could not be loaded", "missing": [], "altered": []}
    missing = []
    for name in sorted(template.field_specs):
        spec = template.field_specs[name]
        if not (getattr(spec, "guidelines", None) or "").strip():
            missing.append({
                "field": name,
                "type": _enum_name(getattr(spec, "type", "")),
                "scope": _enum_name(getattr(spec, "scope", "")),
            })
    altered: List[Dict[str, str]] = []
    try:
        from synesis_coder.template_lint import altered_guideline_lines

        template_file = _template_path(synp)
        if template_file is not None:
            content = template_file.read_text(encoding="utf-8")
            altered = [{"field": f, "line": line}
                       for f, line in altered_guideline_lines(content, template.field_specs)]
    except Exception as exc:  # the lint is advisory
        altered = [{"field": "?", "line": f"lint unavailable: {exc}"}]
    return {"ok": not missing and not altered, "missing": missing, "altered": altered,
            "fields": len(template.field_specs)}


def find_continuation_lines(synp: Path) -> List[Dict[str, Any]]:
    """Field values whose continuation lines the compiler drops.

    synesis 0.13.4-0.15.0 parse `field: value` followed by an indented line as a
    `continuation_block`, but the transformer has no rule for that node and the
    continuation is DROPPED without error (reproduced 2026-11-20). The block form
    (`field:` alone, value on the following lines) is not affected. Detection uses
    the compiler's own parser, so it reports exactly the nodes that are lost.
    """
    from synesis.parser.lexer import parse_string

    from .common import iter_state_files

    found: List[Dict[str, Any]] = []
    base = Path(synp).resolve().parent
    for path in iter_state_files(base):
        if path.suffix.lower() not in {".syn", ".syno"}:
            continue
        try:
            tree = parse_string(path.read_text(encoding="utf-8"), str(path))
        except Exception:
            continue  # syntax errors are reported by `validate`
        for node in tree.iter_subtrees():
            if getattr(node, "data", None) != "continuation_block":
                continue
            tokens = [t for t in node.scan_values(lambda v: getattr(v, "type", "") == "TEXT_LINE")]
            for tok in tokens:
                found.append({"file": rel(path, base), "line": getattr(tok, "line", None),
                              "text": str(tok).strip()[:80]})
    found.sort(key=lambda x: (x["file"], x["line"] or 0))
    return found


def _template_path(synp: Path) -> Optional[Path]:
    import re

    text = synp.read_text(encoding="utf-8")
    m = re.search(r'^\s*TEMPLATE\s+"([^"]+)"', text, re.MULTILINE | re.IGNORECASE)
    return (synp.parent / m.group(1)) if m else None


def include_target(synp: Path, kind: str) -> Optional[Path]:
    """Path declared by `INCLUDE <KIND> "..."` in the .synp (first match)."""
    import re

    text = Path(synp).read_text(encoding="utf-8")
    m = re.search(rf'^\s*INCLUDE\s+(?:SHARED\s+)?{kind}\s+"([^"]+)"', text, re.MULTILINE | re.IGNORECASE)
    return (Path(synp).parent / m.group(1)) if m else None
