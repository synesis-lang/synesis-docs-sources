# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Which parts of a large project a page shows, and which annotations a review looks at.

The approach follows breadth-and-depth analysis (Weller, Davidson, Edwards and Jamieson, *Big Qual:
A Guide to Breadth-and-Depth Analysis*, Palgrave Macmillan, 2023), which moves through a large
qualitative collection the way an archaeologist moves through a site:

- aerial survey and geophysical survey: what can be counted is counted over the whole project
  (corpus size, concepts by source, problems). The page always does this, at every depth;
- test pits: several small samples, spread over the parts of the collection, read closely
  (depth "sample", and the review sample);
- deep excavation: one place read whole, chosen from what the survey and the pits showed
  (`--focus` on a group, a source or a concept, with depth "full").

The parts are the strata of the project. By default they are the folders the annotations are kept
in, when there are two or more (the researcher made them); otherwise the first SOURCE field with
closed values (ENUMERATED or ORDERED) in the template. Nothing here names a field: the field comes
from the template, by type and scope. Draws are random with a recorded seed, one draw per stratum,
so the same project and seed give the same selection.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

DEPTHS = ("overview", "sample", "full")
OVERVIEW_STRATA = 8          # one source from each of the largest strata
OVERVIEW_PLAIN = 5           # sources when the project has no strata
SAMPLE_SOURCES = 30
SAMPLE_MIN = 2               # per stratum, when the stratum has them
CONCEPTS = {"overview": (8, 4, 0), "sample": (20, 10, 10)}   # most used, used once, others at random
PROBLEM_CAP = 40             # blocks with a problem shown outside the selection
DEFAULT_SEED = 1


def key_of(text: str) -> str:
    """`@Silva2024 extra` -> `silva2024`. Reference keys ignore case (see anchor._ref_key)."""
    first = (text or "").split()
    return first[0].lstrip("@").casefold() if first else ""


@dataclass
class Unit:
    """One source of the project with everything annotated about it."""
    key: str
    name: str
    stratum: str = ""
    files: Set[str] = field(default_factory=set)
    items: List[Tuple[str, int]] = field(default_factory=list)     # (file, line) of each ITEM
    concepts: Set[str] = field(default_factory=set)


def strata_field(fields: Dict[str, Dict[str, Any]]) -> Optional[str]:
    """First SOURCE field with closed values, in template order."""
    for name, f in fields.items():
        if f.get("s") == "SOURCE" and f.get("t") in ("ENUMERATED", "ORDERED"):
            return name
    return None


def _folder_labels(files: Iterable[str]) -> Dict[str, str]:
    """File -> its folder, without the part every folder shares."""
    parents = {f: PurePosixPath(f).parent.parts for f in files}
    distinct = list(set(parents.values()))
    common = 0
    if len(distinct) > 1:
        while all(len(p) > common for p in distinct) and len({p[common] for p in distinct}) == 1:
            common += 1
    # files right in the shared folder keep its name
    return {f: "/".join(p[common:]) or "/".join(p) or "." for f, p in parents.items()}


def item_concepts(node: Any, types: Dict[str, str]) -> List[str]:
    found: List[str] = []
    for f in getattr(node, "children", []):
        if f.kind != "field":
            continue
        val = " ".join([f.text, *f.extra]).strip()
        t = types.get(f.kw)
        if t == "CODE":
            found += [x.strip() for x in val.split(",") if x.strip()]
        elif t == "CHAIN":
            found += [x.strip() for x in val.split("->")][0::2]
    return [c for c in dict.fromkeys(found) if c]


def units(parsed: Dict[str, List[Any]], types: Dict[str, str], fields: Dict[str, Dict[str, Any]],
          strata: Optional[str] = None) -> Tuple[Dict[str, Unit], str]:
    """Sources of the annotation files and the stratum of each one.

    `strata`: "folder", a SOURCE field name, "none", or None (folders when there are two or more,
    otherwise the first SOURCE field with closed values). Returns the units and the rule used."""
    out: Dict[str, Unit] = {}
    values: Dict[str, str] = {}
    sfield = strata if strata not in (None, "folder", "none") else strata_field(fields) if strata is None else None
    for rel, nodes in parsed.items():
        for n in nodes:
            if n.kind != "block" or n.kw not in ("SOURCE", "ITEM"):
                continue
            k = key_of(n.text)
            if not k:
                continue
            u = out.setdefault(k, Unit(k, n.text.split()[0].lstrip("@")))
            u.files.add(rel)
            if n.kw == "ITEM":
                u.items.append((rel, n.line))
                u.concepts.update(item_concepts(n, types))
            elif sfield:
                for f in n.children:
                    if f.kind == "field" and f.kw == sfield and f.text.strip():
                        values[k] = f.text.strip()
    folders = _folder_labels(parsed)
    use_folders = strata == "folder" or (strata is None and len(set(folders.values())) > 1)
    rule = "folder" if use_folders else (sfield if sfield and values else "")
    for k, u in out.items():
        if rule == "folder":
            u.stratum = folders[min(u.files)]
        elif rule:
            u.stratum = values.get(k, "")
    return out, rule


def allocate(sizes: Dict[str, int], total: int, minimum: int) -> Dict[str, int]:
    """How many to draw from each stratum: at least `minimum` (or all it has), the rest in
    proportion to its size (largest remainder). Strata are ordered by size, then name."""
    order = sorted(sizes, key=lambda s: (-sizes[s], s))
    if total >= sum(sizes.values()):
        return dict(sizes)
    take = {s: 0 for s in order}
    floor = {s: min(minimum, sizes[s]) for s in order}
    if sum(floor.values()) >= total:       # more strata than the budget: one each, largest first
        left = total
        while left > 0:
            for s in order:
                if left and take[s] < sizes[s]:
                    take[s] += 1
                    left -= 1
        return take
    take.update(floor)
    left = total - sum(take.values())
    room = {s: sizes[s] - take[s] for s in order}
    whole = sum(room.values())
    shares = {s: left * room[s] / whole for s in order} if whole else {}
    for s in order:
        add = min(room[s], int(shares.get(s, 0)))
        take[s] += add
    left = total - sum(take.values())
    for s in sorted(order, key=lambda s: (-(shares.get(s, 0) % 1), order.index(s))):
        if left <= 0:
            break
        if take[s] < sizes[s]:
            take[s] += 1
            left -= 1
    return take


def _draw(keys: List[str], k: int, seed: Any, stratum: str) -> List[str]:
    keys = sorted(keys)
    if k >= len(keys):
        return keys
    return sorted(random.Random(f"{seed}|{stratum}").sample(keys, k))


def focus_filter(focus: Optional[str], us: Dict[str, Unit]) -> Tuple[Dict[str, Unit], str]:
    """A group, a source or a concept, compared without case. Returns the units and what matched."""
    if not focus:
        return us, ""
    f = focus.strip().lstrip("@").casefold()
    by_stratum = {k: u for k, u in us.items() if u.stratum and
                  (u.stratum.casefold() == f or PurePosixPath(u.stratum).name.casefold() == f)}
    if by_stratum:
        return by_stratum, "stratum"
    if f in us:
        return {f: us[f]}, "source"
    by_concept = {k: u for k, u in us.items() if any(c.casefold() == f for c in u.concepts)}
    if by_concept:
        return by_concept, "concept"
    return {}, "none"


def choose(us: Dict[str, Unit], depth: str, seed: Any = DEFAULT_SEED, focus: Optional[str] = None,
           n_sources: Optional[int] = None) -> Dict[str, Any]:
    """The sources a page shows. Every stratum and its counts are reported, shown or not."""
    pop, matched = focus_filter(focus, us)
    by: Dict[str, List[str]] = {}
    for k, u in pop.items():
        by.setdefault(u.stratum, []).append(k)
    sizes = {s: len(v) for s, v in by.items()}
    has_strata = len([s for s in by if s]) >= 2
    if depth == "full":
        take = dict(sizes)
    elif depth == "overview":
        if has_strata:
            top = sorted(sizes, key=lambda s: (-sizes[s], s))[:OVERVIEW_STRATA]
            take = {s: (1 if s in top else 0) for s in sizes}
        else:
            take = allocate(sizes, n_sources or OVERVIEW_PLAIN, 1)
    else:
        take = allocate(sizes, n_sources or SAMPLE_SOURCES, SAMPLE_MIN if has_strata else 0)
    keys: Set[str] = set()
    for s, n in take.items():
        keys.update(_draw(by[s], n, seed, s))
    return {
        "keys": keys,
        "strata": {s: [len([k for k in by[s] if k in keys]), sizes[s]] for s in sorted(sizes, key=lambda s: (-sizes[s], s))},
        "population": len(pop),
        "total": len(us),
        "matched": matched,
    }


def choose_concepts(uses: Dict[str, int], depth: str, seed: Any = DEFAULT_SEED,
                    focus_concepts: Iterable[str] = ()) -> Optional[Set[str]]:
    """Ontology blocks a page shows; None means all of them."""
    if depth == "full" or depth not in CONCEPTS:
        return None
    most, once, other = CONCEPTS[depth]
    names = sorted(uses)
    ranked = sorted(names, key=lambda c: (-uses[c], c))
    chosen = set(ranked[:most])
    ones = [c for c in names if uses[c] == 1 and c not in chosen]
    chosen.update(_draw(ones, once, seed, "once"))
    rest = [c for c in names if c not in chosen]
    chosen.update(_draw(rest, other, seed, "other"))
    chosen.update(c for c in focus_concepts if c in uses)
    return chosen
