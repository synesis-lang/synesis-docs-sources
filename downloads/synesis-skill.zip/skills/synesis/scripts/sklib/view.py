# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Researcher-friendly view of a Synesis project: one offline HTML page.

Each block of a file (SOURCE, ITEM, ONTOLOGY, FIELD, PROJECT...) is shown as a card.
The block lines (`ITEM @key` ... `END ITEM`) stay visible, in a subtle style, and the
fields and values are colored in the spirit of the VS Code extension (Light+ / Dark+).
Values are set in a readable proportional font; the structure is monospaced and muted.

The parser is line based and tolerant: a file with errors (or one the coder just wrote and
the researcher has not accepted yet) is still shown. It never reads the source texts, only
the Synesis files, and it writes no timestamp, so the same project gives the same page.

Python 3.10+, standard library only. No network: the page has inline CSS and JS only.
"""

from __future__ import annotations

import hashlib
import html
import json
import os
import re
import webbrowser
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import intake
from . import sample as sampling
from . import size as sizing
from . import view_guide as guide
from .common import iter_state_files, read_json
from .intake_text import EXAMPLES, SOURCES
from .view_assets import COMP_CSS, EXTRA_CSS, EXTRA_JS, GH_SVG, PAGE, THEME_CSS
from .view_text import DOCS_URL, GITHUB_URL, GUIDE, HELP, KW, LANGS, LINKS, RUN_STATUS, STRINGS, TAB_SHORT, S, lang_of
from .view_text_depth import DEPTH_TEXT

for _code, _strings in DEPTH_TEXT.items():
    if _code in S:
        S[_code].update(_strings)

# --------------------------------------------------------------------------- parsing

_OPEN = re.compile(
    r"^\s*(SOURCE FIELDS|ITEM FIELDS|ONTOLOGY FIELDS|PROJECT|FIELD|SOURCE|ITEM|ONTOLOGY|METADATA|"
    r"DESCRIPTION|QUESTIONS|EXPORT|PHASE|RELATIONS|VALUES|GUIDELINES)\b(.*)$"
)
_END = re.compile(r"^\s*END\s+(.+?)\s*$")
_FIELD = re.compile(r"^(\s*)([A-Za-z_][\w.-]*)\s*:\s?(.*)$")
_PROP = re.compile(r"^\s*((?:[A-Z][A-Z_]+)(?: (?:[A-Z][A-Z_]+)){0,2})(?:\s+(.*))?$")
_ENTRY = re.compile(r"^\s*(\[\d+\]\s*)?([^:#][^:]*?)\s*:\s*(.*)$")
_TEXTUAL = {"GUIDELINES", "DESCRIPTION"}
_DATA = {"SOURCE", "ITEM", "ONTOLOGY"}
_STATEMENT = re.compile(r"^\s*(TEMPLATE|INCLUDE)\b\s*(.*)$")


@dataclass
class Node:
    kind: str                       # block | field | prop | entry | text | comment | note
    kw: str = ""                    # block keyword, property keyword, or field/entry name
    text: str = ""                  # header rest, value or text
    extra: List[str] = field(default_factory=list)   # continuation lines of a field value
    children: List["Node"] = field(default_factory=list)
    closed: bool = False
    end: str = ""
    line: int = 0                   # line where the node starts (1-based)
    end_line: int = 0               # line of END ... for blocks


def parse(text: str) -> List[Node]:
    """Line-based, tolerant parser. Each node keeps its line; each block also its closing line."""
    root = Node("block", "ROOT")
    stack = [root]
    base_indent = {}

    def add(top, node, i):
        node.line = i
        top.children.append(node)
        return node

    for i, raw in enumerate(text.replace("\r\n", "\n").split("\n"), 1):
        line = raw.rstrip()
        top = stack[-1]
        if not line.strip():
            continue
        end = _END.match(line)
        if end and any(n.kw == end.group(1) for n in stack[1:]):
            while stack[-1].kw != end.group(1):
                stack.pop()
            closing = stack.pop()
            closing.closed, closing.end, closing.end_line = True, line.strip(), i
            continue
        if top.kw in _TEXTUAL:
            add(top, Node("text", text=line.strip()), i)
            continue
        if line.lstrip().startswith("#"):
            add(top, Node("comment", text=line.strip()), i)
            continue
        opened = _OPEN.match(line)
        if opened:
            kw, rest = opened.group(1), opened.group(2).strip()
            is_block = True
            if kw in ("DESCRIPTION", "RELATIONS", "VALUES", "GUIDELINES"):
                is_block = rest == "" and (kw == "DESCRIPTION" or top.kw == "FIELD")
            if kw in _DATA and top.kw in _DATA:
                is_block = False
            if is_block:
                stack.append(add(top, Node("block", kw, rest), i))
                continue
        if top.kw in _DATA:
            m = _FIELD.match(line)
            key, indent = id(top), len(line) - len(line.lstrip())
            if m and (key not in base_indent or indent <= base_indent[key]):
                base_indent.setdefault(key, indent)
                add(top, Node("field", m.group(2), m.group(3)), i)
                continue
            if top.children and top.children[-1].kind == "field":
                top.children[-1].extra.append(line.strip())
                continue
            add(top, Node("text", text=line.strip()), i)
            continue
        stmt = _STATEMENT.match(line)
        if stmt:
            add(top, Node("prop", stmt.group(1), stmt.group(2).strip()), i)
            continue
        if top.kw in ("RELATIONS", "VALUES", "QUESTIONS", "METADATA"):
            m = _ENTRY.match(line)
            if m:
                label = ((m.group(1) or "").strip() + " " + m.group(2).strip()).strip()
                add(top, Node("entry", label, m.group(3)), i)
                continue
        if top.kw in ("ROOT", "PROJECT", "EXPORT", "PHASE", "FIELD", "SOURCE FIELDS", "ITEM FIELDS", "ONTOLOGY FIELDS"):
            m = _PROP.match(line)
            if m:
                add(top, Node("prop", m.group(1), (m.group(2) or "").strip()), i)
                continue
        add(top, Node("text", text=line.strip()), i)
    return root.children


def parse_bib(text: str) -> List[Node]:
    out: List[Node] = []
    for m in re.finditer(r"@(\w+)\s*\{\s*([^,\s]+)\s*,(.*?)\n\}", text, re.S):
        node = Node("block", "@" + m.group(1), m.group(2), closed=True, end="}")
        for f in re.finditer(r"^\s*([\w-]+)\s*=\s*(.+?),?\s*$", m.group(3), re.M):
            node.children.append(Node("field", f.group(1), f.group(2).strip().strip("{}\"")))
        out.append(node)
    return out


def parse_toml(text: str) -> List[Node]:
    out: List[Node] = []
    cur: Optional[Node] = None
    for line in text.replace("\r\n", "\n").split("\n"):
        s = line.strip()
        if not s:
            continue
        if s.startswith("#"):
            (cur.children if cur else out).append(Node("comment", text=s))
        elif s.startswith("["):
            cur = Node("block", "[[table]]" if s.startswith("[[") else "[table]", s.strip("[]"), closed=True)
            out.append(cur)
        elif "=" in s:
            k, v = s.split("=", 1)
            (cur.children if cur else out).append(Node("field", k.strip(), v.strip().strip('"')))
        else:
            (cur.children if cur else out).append(Node("text", text=s))
    return out


# --------------------------------------------------------------------------- rendering

_E = lambda s: html.escape(s, quote=True)  # noqa: E731
_REL = re.compile(r"^[A-Z][A-Z0-9_]*$")
_MARK = re.compile(r"^(Correct|Correto|Right|Wrong|Errado|Incorrect|Incorreto)\s*:\s*(.*)$", re.I)


def _plain(node: Node) -> str:
    parts = [node.kw, node.text, *node.extra]
    for c in node.children:
        parts.append(_plain(c))
    return " ".join(p for p in parts if p)


def _value(text: str, ftype: str) -> str:
    t = text.strip()
    if not t:
        return '<span class="empty">—</span>'
    if ftype == "CHAIN" or "->" in t:
        pieces = [p.strip() for p in t.split("->")]
        out = []
        for i, p in enumerate(pieces):
            cls = "rel" if _REL.match(p) and 0 < i < len(pieces) - 1 else "concept"
            out.append(f'<span class="{cls}">{_E(p)}</span>')
            if i < len(pieces) - 1:
                out.append('<span class="arrow">→</span>')
        return '<span class="chain">' + "".join(out) + "</span>"
    # length first, and one way only to split on each comma: `,\s*[\w .-]+` backtracked
    # exponentially on long untyped values such as the abstracts of a .bib
    if ftype in ("CODE", "TOPIC") or (not ftype and len(t) < 160
                                      and re.fullmatch(r"[\w .-]+(?:,\s*[\w.-][\w .-]*)+", t)):
        return "".join(f'<span class="pill">{_E(p.strip())}</span>' for p in t.split(",") if p.strip())
    if ftype in ("ENUMERATED", "ORDERED"):
        return f'<span class="chip">{_E(t)}</span>'
    if ftype in ("SCALE", "DATE") or re.fullmatch(r"-?\d+(\.\d+)?", t):
        return f'<span class="num">{_E(t)}</span>'
    if ftype == "QUOTATION":
        return f'<q class="quote">{_E(t.strip(chr(34)))}</q>'
    return _E(t)


def _prop_value(text: str) -> str:
    """Property value: quoted strings get the string color, a leading UPPERCASE word the keyword color."""
    t = text.strip()
    m = re.match(r"^([A-Z][A-Z_]+(?: SHARED| [A-Z]+)?)\s+(\".*)$", t)
    head = ""
    if m:
        head, t = f'<span class="kw">{_E(m.group(1))}</span> ', m.group(2)
    parts = re.split(r'("[^"]*")', t)
    return head + "".join(f'<span class="str">{_E(p)}</span>' if p.startswith('"') else _E(p) for p in parts)


def _field_row(n: Node, types: Dict[str, str]) -> str:
    ftype = types.get(n.kw, "")
    value = " ".join([n.text, *n.extra]).strip()
    cont = ""
    if n.extra:
        cont = ' <span class="cont" title="continuation lines">↵</span>'
    return (f'<span class="k"><span class="fname">{_E(n.kw)}</span><span class="colon">:</span></span>'
            f'<span class="fval t-{ftype.lower() or "plain"}">{_value(value, ftype)}{cont}</span>')


def _head(n: Node, t: Dict[str, str]) -> str:
    kw = f'<span class="kw">{_E(n.kw)}</span>'
    rest = n.text
    if n.kw == "FIELD":
        m = re.match(r"(\S+)\s+TYPE\s+(\S+)", rest)
        if m:
            return (f'{kw} <span class="name">{_E(m.group(1))}</span> '
                    f'<span class="kw">TYPE</span> <span class="ftype">{_E(m.group(2))}</span>')
    if rest.startswith("@"):
        return f'{kw} <span class="ref">{_E(rest)}</span>'
    if rest:
        return f'{kw} <span class="name">{_E(rest)}</span>'
    return kw


def _children(n: Node, types: Dict[str, str], s: Dict[str, str]) -> str:
    out: List[str] = []
    for c in n.children:
        if c.kind == "field":
            out.append(_field_row(c, types))
        elif c.kind == "prop":
            val = _prop_value(c.text) if c.text else ""
            if c.kw in ("REQUIRED", "OPTIONAL", "FORBIDDEN") or c.text.startswith("BUNDLE") or "BUNDLE" in c.text.split()[:1]:
                names = re.sub(r"^BUNDLE\s+", "", c.text)
                bundle = '<span class="chip">BUNDLE</span>' if c.text.startswith("BUNDLE") else ""
                val = bundle + "".join(f'<span class="pill">{_E(p.strip())}</span>' for p in names.split(",") if p.strip())
            out.append(f'<span class="k"><span class="kw pk">{_E(c.kw)}</span></span><span class="fval">{val}</span>')
        elif c.kind == "entry":
            out.append(f'<span class="k"><span class="fname">{_E(c.kw)}</span><span class="colon">:</span></span>'
                       f'<span class="fval">{_E(c.text)}</span>')
        elif c.kind == "comment":
            txt = c.text.lstrip("# ").strip()
            if txt and not set(txt) <= set("=-_*# "):
                out.append(f'<div class="note"># {_E(txt)}</div>')
        elif c.kind == "text":
            m = _MARK.match(c.text) if n.kw == "GUIDELINES" else None
            if m:
                good = m.group(1).lower() in ("correct", "correto", "right")
                label = s["correct"] if good else s["wrong"]
                out.append(f'<div class="mark {"good" if good else "bad"}"><b>{_E(label)}</b> {_E(m.group(2))}</div>')
            else:
                out.append(f'<div class="text">{_E(c.text)}</div>')
        elif c.kind == "block":
            out.append(_block(c, types, s, nested=True))
    return "".join(out)


def _block(n: Node, types: Dict[str, str], s: Dict[str, str], nested: bool = False, ident: str = "",
           badge: str = "") -> str:
    kind = re.sub(r"[^a-z]+", "-", n.kw.lower()).strip("-")
    foot = f'<div class="foot"><span class="kw">{_E(n.end or "END " + n.kw)}</span></div>' if n.closed else ""
    search = _E(_plain(n).lower()[:2000])
    cls = "card nested" if nested else "card"
    attr = f' id="{ident}"' if ident else ""
    return (f'<div class="{cls} k-{kind}"{attr} data-s="{search}">'
            f'<div class="head">{_head(n, types)}{badge}</div>'
            f'<div class="body">{_children(n, types, s)}</div>{foot}</div>')


def _loose(nodes: List[Node], types: Dict[str, str], s: Dict[str, str]) -> str:
    holder = Node("block", "ROOT", children=[c for c in nodes if c.kind != "block"])
    body = _children(holder, types, s)
    return f'<div class="loose">{body}</div>' if body else ""


@dataclass
class Entry:
    path: Path
    label: str
    group: str                      # project | template | ontology | annotations | records | references | pending
    run: str = ""


def _group(path: Path) -> Optional[str]:
    return {".synp": "project", ".synt": "template", ".syno": "ontology", ".syn": "annotations",
            ".toml": "records", ".bib": "references"}.get(path.suffix.lower())


_PARSED: Dict[str, List[Node]] = {}


def parse_cached(text: str) -> List[Node]:
    """parse(), once per text while a page is built (the page reads each file in several places)."""
    nodes = _PARSED.get(text)
    if nodes is None:
        nodes = _PARSED[text] = parse(text)
    return nodes


def collect(synp: Path) -> Tuple[List[Entry], List[Entry]]:
    """The files the project includes (the .synp, its template and its INCLUDE lines) and the
    proposals awaiting acceptance. Copies kept in the folder (bkp/, tests) are not shown; a folder
    whose .synp includes nothing readable is shown whole."""
    base = Path(synp).resolve().parent
    included = sizing.project_files(synp)
    paths = included if included is not None else list(iter_state_files(base))
    entries = []
    for p in paths:
        try:
            label = p.relative_to(base).as_posix()
        except ValueError:          # a SHARED ontology outside the project folder
            continue
        if (g := _group(p)) and "view" not in p.relative_to(base).parts:
            entries.append(Entry(p, label, g))
    pending: List[Entry] = []
    runs = base / "runs"
    if runs.is_dir():
        for run in sorted(runs.iterdir()):
            mf = run / "manifest.json"
            if not (mf.exists() and (run / "output").is_dir()):
                continue
            try:
                status = read_json(mf).get("status", "")
            except Exception:  # noqa: BLE001
                continue
            if status in ("accepted", "stale"):
                continue
            for out in sorted((run / "output").iterdir()):
                if out.suffix.lower() in (".syn", ".syno"):
                    pending.append(Entry(out, f"{run.name}/{out.name}", "pending", run.name))
    order = ["project", "template", "ontology", "annotations", "records", "references"]
    entries.sort(key=lambda e: (order.index(e.group), e.label))
    return entries, pending


def _types(entries: List[Entry]) -> Dict[str, str]:
    types: Dict[str, str] = {}
    for e in entries:
        if e.group == "template":
            for m in re.finditer(r"^\s*FIELD\s+(\S+)\s+TYPE\s+(\S+)", e.path.read_text(encoding="utf-8", errors="replace"), re.M):
                types[m.group(1)] = m.group(2).upper()
    return types


def _counts(nodes: List[Node], s: Dict[str, str]) -> str:
    c: Dict[str, int] = {}
    for n in nodes:
        if n.kind == "block":
            c[n.kw] = c.get(n.kw, 0) + 1
    names = {"SOURCE": s["sources"], "ITEM": s["items"], "ONTOLOGY": s["concepts"], "FIELD": s["fields"]}
    names = {k: v for k, v in names.items()}
    def label(k: str, v: int) -> str:
        one, many = names[k]
        return f"{v} {one if v == 1 else many}"

    shown = [label(k, v) for k, v in c.items() if k in names]
    total = sum(c.values())
    return " · ".join(shown) or (f"{total} {s['blocks'][0 if total == 1 else 1]}" if c else "")


def default_language() -> str:
    try:
        from . import locale as loc

        tag = loc.report(None).get("system_locale") or "en"
    except Exception:  # noqa: BLE001
        tag = "en"
    return lang_of(tag) or "en"


# The page is written in the language of the project, which is the researcher's language (SKILL.md
# section 0b). The languages of the page are those of view_text.LANGS; any other falls back to English.


def _ui_lang(name: Optional[str]) -> Optional[str]:
    """'Brazilian Portuguese', 'pt-BR', 'español', '中文' -> a page language; unknown or empty -> None."""
    return lang_of(name)


def _prose_language(synp: Path) -> Optional[str]:
    """Portuguese or English from the project's own prose.

    Read: the .synp (description, questions) with weight 3, the template (descriptions, guidelines)
    with weight 2, annotations and ontology with weight 1. Never read: the sources, the keywords
    (always English) and the values of QUOTATION fields, which are in the language of the source,
    not of the researcher. QUOTATION fields are found by their TYPE in the template."""
    files = [p for p in iter_state_files(synp.parent) if p.suffix.lower() in (".synt", ".syn", ".syno")]
    quotation = set()
    for path in files:
        if path.suffix.lower() == ".synt":
            quotation |= set(re.findall(r"^\s*FIELD\s+(\S+)\s+TYPE\s+QUOTATION",
                                        path.read_text(encoding="utf-8", errors="replace"), re.M))
    score = {code: 0 for code in LANGS}
    stop = {code: set(meta["stop"]) for code, meta in LANGS.items()}
    seen = 0
    for path in [synp] + files[:200]:
        weight = 3 if path.suffix.lower() == ".synp" else 2 if path.suffix.lower() == ".synt" else 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for line in text.splitlines():
            s = line.strip()
            if not s or s.startswith("#") or re.match(r"^(END\s|[A-Z][A-Z_ ]+$)", s):
                continue
            field_name = re.match(r"^([\w.-]+)\s*:", s)
            if field_name and field_name.group(1) in quotation:
                continue
            s = re.sub(r"^[A-Z][A-Z_]+(\s+[A-Z][A-Z_]+)*\s+", "", s)      # a keyword before the text
            s = re.sub(r"^[\w.-]+\s*:\s*", "", s)                          # a field name before the value
            words = re.findall(r"[a-zà-ÿß]+", s.lower())
            seen += len(words)
            for code, sw in stop.items():
                if sw:
                    score[code] += weight * sum(w in sw for w in words)
            han = len(re.findall(r"[一-鿿]", s))          # Chinese: about two characters a word
            score["zh"] += weight * han // 2
            seen += han // 2
        if seen > 8000:
            break
    ranked = sorted(score.items(), key=lambda kv: -kv[1])
    (best, top), (_, second) = ranked[0], ranked[1]
    if top < 12 or top < second * 1.5:
        return None
    return best


def page_language(synp: Path) -> Tuple[str, str]:
    """Language of the page and where it came from, in this order:
    the project_language decision, SYNESIS_CODER_LANGUAGE in the project .env, the language of the
    latest coder run, the project's own prose, and only then the operating system."""
    synp = Path(synp).resolve()
    decisions = synp.parent / "runs" / "decisions.jsonl"
    if decisions.exists():
        chosen = None
        for line in decisions.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if d.get("type") == "project_language":
                chosen = _ui_lang(str(d.get("language") or d.get("note") or "").split(";")[0]) or chosen
        if chosen:
            return chosen, "project_language decision"
    try:
        from . import locale as loc

        env = _ui_lang(loc.project_language(synp))
    except Exception:  # noqa: BLE001
        env = None
    if env:
        return env, "SYNESIS_CODER_LANGUAGE in the project .env"
    runs = synp.parent / "runs"
    if runs.is_dir():
        for mf in sorted(runs.glob("*/manifest.json"), reverse=True):
            lang = _ui_lang(_manifest(mf).get("output_language"))
            if lang:
                return lang, f"language of run {mf.parent.name}"
    prose = _prose_language(synp)
    if prose:
        return prose, "the project's own text"
    return default_language(), "the operating system"


def open_in_browser(path: Path) -> bool:
    return webbrowser.open(Path(path).resolve().as_uri())


# --------------------------------------------------------------------------- project data and page
# The page is built from the project itself: field names, types, scopes, relations and values come
# from the compiled template; concepts from the ontology; problems from the compiler; anchoring from
# sk.py anchor's own check; provenance from the run manifests. No field name is written in this code.

E = _E
OCC: Dict[str, List[Dict[str, Any]]] = {}          # concept -> occurrences (filled while rendering)
CONCEPTS_SEEN: Dict[str, Any] = {}
UNDEF: set = set()          # codes the compiler reports as undefined (UndefinedCode); the page never decides alone
_CUR = {"field": ""}
_base_value, _base_row = _value, _field_row

# Very large projects: the matrix shows the most frequent concepts and the sources with most items.
MATRIX_MAX_ROWS = 40
MATRIX_MAX_COLS = 16

CITATION = {   # Synesis itself; the version comes from the installed compiler
    "family": "De Britto", "given": "Christian Maciel", "year": "2026",
    "title": "Synesis: A DSL compiler for knowledge engineering", "repo": GITHUB_URL,
}


def _compile(synp: Path) -> Dict[str, Any]:
    """Compile for diagnostics and analytic data. Without a working compiler the page still renders."""
    try:
        from .project import compile_project

        return compile_project(synp)
    except Exception as exc:  # noqa: BLE001
        return {"validation": {"diagnostics": []}, "analytic": None, "template": None, "state": "",
                "error": f"{type(exc).__name__}: {exc}"}


def _anchor(base: Path, analytic: Any, state: str) -> Dict[str, Any]:
    try:
        from . import anchor

        return anchor.check(base, analytic or {}, state)
    except Exception:  # noqa: BLE001
        return {"results": [], "summary": {}}


def _manifest(path: Path) -> Dict[str, Any]:
    try:
        data = read_json(path)
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def citation(lang: str) -> Tuple[str, str]:
    """Citation of Synesis (ABNT for Portuguese, APA for English) and a BibTeX entry."""
    try:
        from importlib.metadata import version

        ver = version("synesis")
    except Exception:  # noqa: BLE001
        ver = ""
    c = CITATION
    initials = " ".join(w[0] + "." for w in c["given"].split())
    v_pt = f" Versão {ver}." if ver else ""
    v_en = f" (Version {ver})" if ver else ""
    if lang == "pt":
        text = (f"{c['family'].upper()}, {c['given']}. {c['title']}.{v_pt} [S. l.], {c['year']}. Software. "
                f"Disponível em: {c['repo']}. Acesso em: [data de acesso].")
    else:
        text = f"{c['family']}, {initials} ({c['year']}). {c['title']}{v_en} [Computer software]. {c['repo']}"
    key = re.sub(r"[^a-z]", "", c["family"].lower()) + "_synesis_" + c["year"]
    version_line = f"  version = {{{ver}}},\n" if ver else ""
    bib = (f"@software{{{key},\n  author  = {{{c['family']}, {c['given']}}},\n  title   = {{{c['title']}}},\n"
           f"{version_line}  year    = {{{c['year']}}},\n  url     = {{{c['repo']}}}\n}}")
    return text, bib


def kwize(h, fld, where, block_kw="", block_val=""):
    """Mark the words of the language with data-k, for the hover help."""
    fa = f' data-kf="{E(fld)}"' if fld else ""

    def key(k):
        if k == "DESCRIPTION" and not fld:
            return "DESCRIPTION@P"
        if k == "ONTOLOGY" and where == "body":
            return "INC:ONTOLOGY"
        return k

    h = re.sub(r'<span class="kw">END ([^<]+)</span>',
               lambda m: f'<span class="kw" data-k="END" data-kv="{m.group(1)}" tabindex="0">END {m.group(1)}</span>', h)
    def prop(m):
        k, v = m.group(1), m.group(2).strip()
        if " " in k and k not in KW["pt"]:      # the parser gives "SCOPE ITEM" whole: word + value
            k, v = k.split(" ", 1)[0], (k.split(" ", 1)[1] + " " + v).strip()
        return (f'<span class="k"><span class="kw pk" data-k="{key(k)}" data-kv="{v}"{fa} tabindex="0">'
                f'{m.group(1)}</span></span><span class="fval">{m.group(2)}</span>')
    h = re.sub(r'<span class="k"><span class="kw pk">([^<]+)</span></span><span class="fval">([^<]*)</span>', prop, h)
    h = re.sub(r'<span class="kw pk">([^<]+)</span>',
               lambda m: f'<span class="kw pk" data-k="{key(m.group(1))}"{fa} tabindex="0">{m.group(1)}</span>', h)
    h = re.sub(r'<span class="ftype">([^<]+)</span>',
               lambda m: f'<span class="ftype" data-k="T:{m.group(1)}"{fa} tabindex="0">{m.group(1)}</span>', h)
    h = re.sub(r'<span class="chip">BUNDLE</span>', '<span class="chip" data-k="BUNDLE" tabindex="0">BUNDLE</span>', h)

    def plain_kw(m):
        k = m.group(1)
        kv = E(block_val) if (where == "head" and k == block_kw) else (m.group(3) or "")
        return f'<span class="kw" data-k="{key(k)}" data-kv="{kv}"{fa} tabindex="0">{k}</span>' + (m.group(2) or "")
    return re.sub(r'<span class="kw">([^<]+)</span>( <span class="name"[^>]*>([^<]+)</span>)?', plain_kw, h)


def help_html(lang, s, name, n_src, n_items, n_conc, problems, has_pending, pending_label, poss_label, anc, top, hint, no_source=""):
    """The "Where to start" tab: what this project needs now, and where to do it."""
    h = HELP[lang]

    def pl(pair, n):
        return (pair[0] if n == 1 else pair[1]).replace("{n}", str(n))

    def link(target, label):
        return f'<a href="#{target}">{E(label)}</a>'
    e = sum(p[0] == "error" for p in problems)
    w = sum(p[0] == "warning" for p in problems)
    nf = sum(p[0] == "anchor" for p in problems)
    ed = sum(p[0] == "edit" for p in problems)
    tips = [no_source] if no_source else []
    if e:
        tips.append(h["start_err"].replace("{e}", E(pl(h["err"], e))).replace("{link}", link("review", h["review_link"])))
    if w:
        tips.append(h["start_warn"].replace("{w}", E(pl(h["warn"], w))).replace("{link}", link("review", h["review_link"])))
    if nf:
        tips.append(E(h["nf"].replace("{n}", pl(h["q"], nf))))
    if has_pending:
        tips.append(h["pending"].replace("{link}", link("tab-pending", pending_label)))
    if ed:
        tips.append(E(h["edits"].replace("{n}", pl(h["files"], ed))))
    undef = sorted(UNDEF)
    if undef:
        tips.append(E(h["undef"][0 if len(undef) == 1 else 1].replace("{codes}", ", ".join(f"«{c}»" for c in undef))))
    if not tips:
        tips.append(E(h["clear"]))
    if top:
        tips.append(h["explore"].replace("{link}", link("matrix", h["matrix_link"])).replace("{top}", E(top[0])).replace("{n}", str(top[1])))
    tips.append(h["learn"].replace("{link}", link("tab-poss", poss_label)))
    about = E(h["about"].format(name=name, src=n_src, items=n_items, conc=n_conc))
    items = "".join(f"<li><span>{x}</span></li>" for x in tips)
    return len(tips), (f'<section class="start"><div class="eyebrow">{E(h["tab"])}</div><h1>{E(name)}</h1><p class="about">{about}</p>'
                       f'<ol class="steps">{items}</ol><p class="muted small">{E(hint)}</p></section>')


def support_html(lang):
    L = LINKS[lang]
    text, bib = citation(lang)
    return (f'<section class="support" id="support"><h2>{E(L["support_t"])}</h2><p>{E(L["support"])}</p><ul>'
            f'<li><a class="sbtn" href="{GITHUB_URL}" target="_blank" rel="noopener">{GH_SVG}<span>★ {E(L["star"])}</span></a>'
            f'<span>{E(L["star_why"])}</span></li>'
            f'<li><span class="sbtns"><button class="act ask sbtn2" type="button" data-ask="{E(text)}" data-msg="{E(L["copied_cite"])}">{E(L["copy_cite"])}</button>'
            f'<button class="act ask sbtn2" type="button" data-ask="{E(bib)}" data-msg="{E(L["copied_bib"])}">{E(L["copy_bib"])}</button></span>'
            f'<span>{E(L["cite_why"])}</span></li>'
            f'<li><a class="sbtn3" href="{GITHUB_URL}/issues" target="_blank" rel="noopener">{E(L["issue"])} ↗</a>'
            f'<span>{E(L["issue_why"])}</span></li></ul><p class="cite-txt mono">{E(text)}</p></section>')


def short_msg(d, lang):
    """Short message in the page language; the full compiler text stays under technical details."""
    s = S[lang]
    names = re.findall(r"`([^`]+)`", d["message"])
    tpl = s["short"].get(d["code"])
    if tpl and names:
        return re.sub(r"`([^`]+)`", lambda m: "«" + m.group(1) + "»", tpl.format(*names))
    first = re.split(r"(?<=[.])\s", one_line(d["message"]))[0]
    return s["short_fallback"].format(code=d["code"]) if s["short_fallback"] else first


def plural(pair, n):
    return pair[0] if n == 1 else pair[1]


def plain(n):
    return re.sub(r"\s+", " ", _plain(n)).strip()


def gather(synp):
    comp = _compile(synp)
    base = synp.parent
    analytic = comp["analytic"] or {}
    tpl = comp["template"]

    fields, relations, types = {}, {}, {}
    for name, sp in (tpl.field_specs if tpl else {}).items():
        rels = {k: str(v).strip() for k, v in (sp.relations or {}).items()}
        fields[name] = {
            "t": sp.type.value, "s": sp.scope.value, "d": (sp.description or "").strip(),
            "g": [ln.strip() for ln in (sp.guidelines or "").splitlines() if ln.strip()],
            "r": rels, "v": [[getattr(v, "label", str(v)), getattr(v, "description", "")] for v in (sp.values or [])],
        }
        relations[name] = rels
        types[name] = sp.type.value

    code_fields = [f for f, t in types.items() if t in ("CODE", "CHAIN")]
    uses = {}
    for item in analytic.get("corpus") or []:
        seen = set()
        for f in code_fields:
            raw = (item.get("data") or {}).get(f)
            for v in (raw if isinstance(raw, list) else [raw]):
                if isinstance(v, dict):
                    v = " ".join(str(x) for x in v.values())
                for tok in re.findall(r"[\w.-]+", str(v or "")):
                    seen.add(tok)
        for tok in seen:
            uses[tok] = uses.get(tok, 0) + 1
    concepts = {}
    for code, data in (analytic.get("ontology") or {}).items():
        loc = data.get("location") or {}
        concepts[code] = {
            "f": [[k, v if isinstance(v, str) else ", ".join(map(str, v)) if isinstance(v, list) else str(v)]
                  for k, v in data.items() if k not in ("concept", "location") and v not in (None, "", [])],
            "n": uses.get(code, 0), "file": loc.get("file"), "line": loc.get("line"),
        }

    anc = _anchor(base, analytic, comp.get("state", ""))
    anchors = {}
    for r in anc["results"]:
        anchors.setdefault((r["file"], r["line"]), []).append(r)

    prov = {}
    for mf in sorted((base / "runs").glob("*/manifest.json")):
        m = _manifest(mf)
        if m.get("status") != "accepted":
            continue
        out_by_sha = {sha: rel for rel, sha in (m.get("outputs") or {}).items()}
        for rel, sha in (m.get("accepted_files") or {}).items():
            cur = base / rel
            if not cur.exists():
                continue
            out = out_by_sha.get(sha)
            accepted_blocks = set()
            if out and (mf.parent / out).exists():
                accepted_blocks = {plain(n) for n in parse((mf.parent / out).read_text(encoding="utf-8")) if n.kind == "block"}
            prov[rel] = {"run": m["id"], "date": m.get("accepted_on", ""), "blocks": accepted_blocks,
                         "changed": hashlib.sha256(cur.read_bytes()).hexdigest() != sha}
    return comp, fields, relations, types, concepts, anchors, anc, prov


def _row(n, types):
    _CUR["field"] = n.kw
    return _base_row(n, types)


def make_value(concepts, relations, fields):
    def concept(name, cls):
        extra = " undef" if name in UNDEF else ""
        return f'<span class="{cls}{extra}" data-c="{E(name)}" tabindex="0">{E(name)}</span>'

    def value(text, ftype):
        out = _base_value(text, ftype)
        fld = _CUR["field"]
        if ftype == "CODE":
            out = re.sub(r'<span class="pill">([^<]+)</span>', lambda m: concept(html.unescape(m.group(1)), "pill"), out)
        elif ftype == "CHAIN":
            out = re.sub(r'<span class="concept">([^<]+)</span>', lambda m: concept(html.unescape(m.group(1)), "concept"), out)
            rels = relations.get(fld, {})

            def rel(m):
                name = html.unescape(m.group(1))
                bad = " undef" if rels and name not in rels else ""
                return f'<span class="rel{bad}" data-r="{E(name)}" data-rf="{E(fld)}" tabindex="0">{E(name)}</span>'
            out = re.sub(r'<span class="rel">([^<]+)</span>', rel, out)
        return out
    return value


def hoverize(body, fields):
    body = re.sub(r'<span class="fname">([^<]+)</span>',
                  lambda m: f'<span class="fname" data-f="{m.group(1)}" tabindex="0">{m.group(1)}</span>'
                  if html.unescape(m.group(1)) in fields else m.group(0), body)
    body = re.sub(r'<span class="pill">([^<]+)</span>',
                  lambda m: f'<span class="pill" data-f="{m.group(1)}" tabindex="0">{m.group(1)}</span>'
                  if html.unescape(m.group(1)) in fields else m.group(0), body)
    return body


def head_hover(h, fields):
    return re.sub(r'<span class="name">([^<]+)</span>',
                  lambda m: f'<span class="name" data-f="{m.group(1)}" tabindex="0">{m.group(1)}</span>'
                  if html.unescape(m.group(1)) in fields else m.group(0), h, count=1)


def one_line(msg):
    return re.sub(r"\s+", " ", msg).strip()


def diag_html(sev, code, msg, line, s, short=None):
    lines = msg.split("\n")
    text = lines[0] + ("\n" + "\n".join(ln[2:] if ln.startswith("  ") else ln for ln in lines[1:]) if len(lines) > 1 else "")
    if short and short != one_line(msg):
        body = (f'<span class="msg">{E(short)}<details class="techd"><summary>{E(s["tech"])}</summary>'
                f'<pre>{E(code)}\n{E(text)}</pre></details></span>')
    else:
        body = f'<span class="msg">{E(text)}</span>'
    return (f'<div class="dg {sev}"><span class="sev">{E(s["sev"][sev])}</span>{body}'
            f'<span class="dl">{E(s["line"])} {line}</span></div>')


SEL: Dict[str, Any] = {}      # what this page shows (see select); empty = everything


def select(synp: Path, entries: List[Entry], types, fields, concepts, depth: str,
           focus: Optional[str], seed: Any, strata: Optional[str], n_sources: Optional[int]) -> Dict[str, Any]:
    """Sources and ontology blocks the page shows (sklib/sample.py). Counts, the matrix and the
    problems are always computed over the whole project; only the cards are selected."""
    ann = {e.label: parse_cached(e.path.read_text(encoding="utf-8", errors="replace"))
           for e in entries if e.group == "annotations"}
    us, rule = sampling.units(ann, types, fields, strata)
    group_of = {k: u.stratum for k, u in us.items()}
    # a large project is read by group in the matrix: concepts x groups instead of x a few sources
    by_group = bool(rule) and len({g for g in group_of.values() if g}) >= 2 and len(us) > MATRIX_MAX_COLS
    if depth == "full" and not focus:
        return {"depth": "full", "keys": None, "concepts": None, "rule": rule, "total": len(us),
                "group_of": group_of, "by_group": by_group}
    ch = sampling.choose(us, depth, seed, focus, n_sources)
    focus_c = [c for c in concepts if focus and c.casefold() == focus.strip().casefold()]
    if ch["matched"] == "concept" and focus_c:     # the concept and those that appear with it
        near: Dict[str, int] = {}
        for k in ch["keys"]:
            for c in us[k].concepts:
                near[c] = near.get(c, 0) + 1
        focus_c += sorted(near, key=lambda c: (-near[c], c))[:10]
    conc = sampling.choose_concepts({c: d["n"] for c, d in concepts.items()}, depth, seed, focus_c)
    if depth == "full":
        conc = None if ch["matched"] != "concept" else set(focus_c)
    return {"depth": depth, "keys": ch["keys"], "concepts": conc, "rule": rule, "strata": ch["strata"],
            "population": ch["population"], "total": ch["total"], "matched": ch["matched"], "focus": focus or "",
            "seed": seed, "n_concepts": len(concepts), "budget": [sampling.PROBLEM_CAP], "extra": 0,
            "group_of": group_of, "by_group": by_group}


def render(synp: Path, lang: str = "en", base: str = "..", depth: str = "full", focus: Optional[str] = None,
           seed: Any = sampling.DEFAULT_SEED, strata: Optional[str] = None, n_sources: Optional[int] = None,
           measured: Optional[Dict[str, Any]] = None) -> str:
    """The whole page. `base` is the project folder relative to the folder of the page.

    `depth` (overview | sample | full), `focus`, `seed`, `strata` and `n_sources` choose which cards
    of a large project the page shows (sklib/sample.py)."""
    global _value, _field_row
    synp = Path(synp).resolve()
    s, vs = S[lang], STRINGS[lang]
    _PARSED.clear()
    measured = measured or sizing.measure(synp)
    comp, fields, relations, types, concepts, anchors, anc, prov = gather(synp)
    SEL.clear()
    SEL.update(select(synp, collect(synp)[0], types, fields, concepts, depth, focus, seed, strata, n_sources))
    SEL.update(outside=measured.get("outside", 0), est=measured.get("estimate"))
    OCC.clear()
    UNDEF.clear()
    for d in (comp.get("validation") or {}).get("diagnostics") or []:
        if d.get("code") == "UndefinedCode":
            UNDEF.update(re.findall(r"`([^`]+)`", d.get("message", ""))[:1])
    _value, _field_row = make_value(concepts, relations, fields), _row
    try:
        return _render(synp, lang, base, s, vs, comp, fields, relations, types, concepts, anchors, anc, prov)
    finally:
        _value, _field_row = _base_value, _base_row
        _PARSED.clear()


def _render(synp, lang, base, s, vs, comp, fields, relations, types, concepts, anchors, anc, prov):
    entries, pending = collect(synp)
    diags = comp["validation"]["diagnostics"]
    proj = synp.stem
    problems = []          # (severity, text, file, line, card id, code, full message)
    used_diag = set()
    rendered = set()       # ids of the cards on the page
    diags_in: Dict[str, List[Dict[str, Any]]] = {}
    for d in diags:
        diags_in.setdefault(d["file"], []).append(d)

    def card(n, rel, run=None, show=True):
        """HTML of one block, or None when the selection leaves it out. Problems and occurrences
        are recorded either way, so the counts and the matrix cover the whole project."""
        cid = f"c-{re.sub(r'[^a-z0-9]+', '-', rel.lower())}-{n.line}"
        p0 = len(problems)
        last = getattr(n, "end_line", n.line)
        mine = [d for d in diags_in.get(rel, ()) if d["line"] and n.line <= d["line"] <= last]
        for d in mine:
            used_diag.add(id(d))
        blk = f"{n.kw} {n.text}".strip()
        rows, ask_lines, chips = [], [], []
        for d in mine:
            rows.append(diag_html(d["severity"], d["code"], d["message"], d["line"], s, short_msg(d, lang)))
            ask_lines.append(f"- [{s['sev'][d['severity']]}] {d['code']} ({s['line']} {d['line']}): {one_line(d['message'])}")
            problems.append((d["severity"], short_msg(d, lang), rel, d["line"], cid, d["code"], one_line(d["message"])))
        n_err = sum(d["severity"] == "error" for d in mine)
        n_warn = sum(d["severity"] == "warning" for d in mine)
        if n_err:
            chips.append(f'<span class="chip-s error">✕ {n_err} {E(plural(s["error"], n_err))}</span>')
        if n_warn:
            chips.append(f'<span class="chip-s warning">⚠ {n_warn} {E(plural(s["warning"], n_warn))}</span>')
        for r in anchors.get((rel, n.line), []) if not run else []:
            if r["status"] == "found":
                chips.append(f'<span class="chip-s ok" title="{E(s["q_note"])}">✓ {E(s["q_found"])}</span>')
            elif r["status"] == "not_found":
                chips.append(f'<span class="chip-s warning" title="{E(s["q_note"])}">✕ {E(s["q_notfound"])}</span>')
                msg = s["notfound_msg"].format(ref=r["source_ref"])
                rows.append(diag_html("anchor", "", msg, n.line, s))
                ask_lines.append(f"- [{s['sev']['anchor']}] ({s['line']} {n.line}): {msg}")
                problems.append(("anchor", msg, rel, n.line, cid, "", msg))
            else:
                chips.append(f'<span class="chip-s muted">? {E(s["q_unver"])}</span>')
        p = prov.get(rel)
        if run:
            foot_prov = s["proposal"].format(run=run)
        elif p:
            if p["blocks"] and plain(n) not in p["blocks"]:
                foot_prov = s["hand_edit"]
                chips.append(f'<span class="chip-s edit">✎ {E(s["hand_edit"])}</span>')
                ask_lines.append(f"- [{s['sev']['edit']}] {s['hand_edit']} ({p['run']})")
            else:
                foot_prov = s["accepted"].format(run=p["run"], date=fmt_date(p["date"], lang))
        else:
            foot_prov = s["by_hand"]
        if run:
            ask = s["ask_pending"].format(run=run, blk=blk, line=n.line)
        elif ask_lines:
            ask = s["ask_fix"].format(proj=proj, blk=blk, file=rel, line=n.line, lines="\n".join(ask_lines))
        else:
            ask = s["ask_review"].format(proj=proj, blk=blk, file=rel, line=n.line)
        nf = any(r["status"] == "not_found" for r in anchors.get((rel, n.line), [])) if not run else False
        if not show and (n_err or n_warn or nf or foot_prov == s["hand_edit"]) and SEL.get("budget", [0])[0] > 0:
            SEL["budget"][0] -= 1         # a block with a problem is shown even outside the selection
            SEL["extra"] += 1
            show = True
            chips.insert(0, f'<span class="chip-s muted" title="{E(s["out_hint"])}">{E(s["out_chip"])}</span>')
        if n.kw == "ITEM" and not run:
            found = sampling.item_concepts(n, types)    # CODE values and the concepts of CHAIN values
            grp = SEL["group_of"].get(sampling.key_of(n.text), "") if SEL.get("by_group") else None
            for c in found:
                if show:
                    o = {"id": cid, "s": n.text.lstrip("@"), "f": rel, "l": n.line, "cs": found,
                         "nf": nf, "ed": foot_prov == s["hand_edit"], "e": n_err, "w": n_warn}
                else:                     # counted, not on the page: where it is, and its problems
                    o = {"s": n.text.lstrip("@"), "f": rel, "l": n.line, "x": 1}
                    if n_err or n_warn:
                        o.update(e=n_err, w=n_warn)
                if grp is not None:
                    o["g"] = grp
                OCC.setdefault(c, []).append(o)
        if not show:
            for i in range(p0, len(problems)):        # the problem stays listed, without a card to open
                problems[i] = problems[i][:4] + (None,) + problems[i][5:]
            return None, n_err, n_warn
        rendered.add(cid)
        kind = re.sub(r"[^a-z]+", "-", n.kw.lower()).strip("-")
        fld_ctx = n.text.split()[0] if n.kw == "FIELD" and n.text else ""
        body = kwize(hoverize(_children(n, types, vs), fields), fld_ctx, "body")
        state = " has-error" if n_err else " has-warn" if (n_warn or any("✕" in c for c in chips)) else ""
        endtag = kwize('<span class="kw">' + E(n.end or "END " + n.kw) + '</span>', "", "foot")
        foot = (f'<div class="foot">{endtag}'
                f'<span class="prov">{E(foot_prov)}</span></div>')
        acts = (f'<span class="acts"><span class="ln">{E(s["line"])} {n.line}</span>'
                f'<a class="act vs" data-file="{E(rel)}" data-line="{n.line}" href="#">{E(s["open_vs"])}</a>'
                f'<button class="act ask" type="button" data-ask="{E(ask)}">{E(s["ask"])}</button></span>')
        return (f'<div class="card k-{kind}{state}" id="{cid}">'
                f'<div class="head"><span class="ht">{kwize(head_hover(_head(n, types), fields), fld_ctx, "head", n.kw, n.text.split()[0] if n.text else "")}</span>{acts}</div>'
                + (f'<div class="chips">{"".join(chips)}</div>' if chips else "")
                + (f'<div class="dgs">{"".join(rows)}</div>' if rows else "")
                + f'<div class="body">{body}</div>{foot}</div>'), n_err, n_warn

    def section(e, anchor_id, run=None):
        path = e.path
        rel = path.relative_to(synp.parent).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        suf = path.suffix.lower()
        if suf == ".bib":
            nodes = parse_bib(text)
            for nd in nodes:
                nd.line = 1 + text[:max(text.find("{" + nd.text), 0)].count("\n")
        elif suf == ".toml":
            nodes = parse_toml(text)
        else:
            nodes = parse_cached(text)
        cards, ne, nw = [], 0, 0
        for nd in nodes:
            if nd.kind == "block":
                if not nd.line:
                    nd.line = 1
                html_card, a, b = card(nd, rel, run, wanted(nd, e.group, rel, run))
                if html_card:
                    cards.append(html_card)
                ne, nw = ne + a, nw + b
        tab = tabs[cur[0]]
        tab["err"] += ne
        tab["warn"] += nw
        n_blocks = sum(1 for nd in nodes if nd.kind == "block")
        tab["blocks"] += n_blocks
        tab["shown"] += len(cards)
        if not cards and n_blocks:          # nothing of this file in the selection
            tab["hidden"] += 1
            p = prov.get(rel)
            if p and p["changed"]:
                emsg = s["edited_msg"].format(n=sum(1 for nd in nodes if nd.kind == "block" and p["blocks"]
                                                    and plain(nd) not in p["blocks"]), run=p["run"])
                problems.append(("edit", emsg, rel, 1, None, "", emsg))
            return
        counts = _counts(nodes, vs)
        if len(cards) < n_blocks:
            counts = s["shown_of"].format(k=len(cards), n=n_blocks) + " · " + counts
        p = prov.get(rel)
        pchip = ""
        if run:
            pchip = f'<span class="fchip pend">{E(s["proposal"].format(run=run))}</span>'
        elif p and p["changed"]:
            changed = [nd for nd in nodes if nd.kind == "block" and p["blocks"] and plain(nd) not in p["blocks"]]
            pchip = f'<span class="fchip edit">✎ {E(s["hand_edit_file"].format(run=p["run"]))}</span>'
            emsg = s["edited_msg"].format(n=len(changed), run=p["run"])
            target = None
            if changed:
                target = f"c-{re.sub(r'[^a-z0-9]+', '-', rel.lower())}-{changed[0].line}"
                target = target if target in rendered else None
            problems.append(("edit", emsg, rel, changed[0].line if changed else 1, target, "", emsg))
        elif p:
            pchip = f'<span class="fchip ok">{E(s["accepted"].format(run=p["run"], date=fmt_date(p["date"], lang)))}</span>'
        bad = ""
        if ne:
            bad += f'<span class="nb error">{ne}</span>'
        if nw:
            bad += f'<span class="nb warning">{nw}</span>'
        file_anchor[rel] = anchor_id
        tab["nav"].append(f'<a href="#{anchor_id}" title="{E(e.label)}"><span>{E(e.label)}</span>{bad}<small>{E(counts)}</small></a>')
        loose = _loose([nd for nd in nodes if nd.kind != "block"], types, vs)
        tab["body"].append(f'<details class="file" id="{anchor_id}" open><summary><span class="fn">{E(e.label)}</span>'
                        f'<span class="cnt">{E(counts)}</span>{pchip}</summary>{loose}{"".join(cards)}</details>')

    tabs, file_anchor, cur = {}, {}, [""]

    def wanted(nd, group, rel, run):
        """Is this block in the selection? Project, template and proposals are always shown."""
        keys, conc = SEL.get("keys"), SEL.get("concepts")
        if run or (keys is None and conc is None):
            return True
        if group == "annotations":
            return keys is None or nd.kw not in ("SOURCE", "ITEM") or sampling.key_of(nd.text) in keys
        if group == "ontology":
            return conc is None or nd.kw != "ONTOLOGY" or (nd.text.split()[0] if nd.text else "") in conc
        if group == "references":
            return keys is None or sampling.key_of(nd.text) in keys
        if group == "records":
            return keys is None or Path(rel).stem.casefold() in keys
        return True

    def open_tab(key, label, files_n):
        tabs[key] = {"label": label, "nav": [], "body": [], "err": 0, "warn": 0, "n": files_n,
                     "blocks": 0, "shown": 0, "hidden": 0}
        cur[0] = key

    if pending:
        open_tab("pending", vs["awaiting"], len(pending))
        tabs["pending"]["body"].append(f'<div class="banner"><b>{E(vs["awaiting"])}.</b> {E(vs["awaiting_hint"])}</div>')
        for i, e in enumerate(pending):
            section(e, f"p{i}", run=e.run)
    for g in ["project", "template", "ontology", "annotations", "records", "references"]:
        files = [e for e in entries if e.group == g]
        if not files:
            continue
        open_tab(g, vs[g], len(files))
        for i, e in enumerate(files):
            section(e, f"{g}-{i}")
    if comp.get("error"):                 # the page still shows the files, but says why nothing was checked
        msg = s["compile_fail"].format(err=comp["error"])
        problems.append(("info", msg, synp.name, 1, None, "", msg))
    for d in diags:                       # diagnostics outside any card
        if id(d) not in used_diag:
            problems.append((d["severity"], short_msg(d, lang), d["file"] or "", d["line"] or 1, None, d["code"], one_line(d["message"])))
    problems[:] = [(a, b, c, d, cid or file_anchor.get(c), f, g) for a, b, c, d, cid, f, g in problems]
    props = {}
    for e in pending:
        rel_p = e.path.relative_to(synp.parent).as_posix()
        props.setdefault(e.run, []).append((e.path.name, file_anchor.get(rel_p)))
    panel = problems_panel(problems, anc, props, s, proj)
    overview = depth_banner(s, proj) + dashboard(synp, lang, comp, entries, fields, types, concepts, anc, panel)
    for tb in tabs.values():
        if tb["hidden"]:
            tb["body"].insert(0, f'<p class="muted small depth-tab">{E(s["tab_partial"].format(k=tb["n"] - tb["hidden"], n=tb["n"]))}</p>')

    def chain_html(fld, text):
        _CUR["field"] = fld
        return _value(text, "CHAIN")
    pf = guide.facts(entries, types, concepts, fields, anc, OCC, parse_cached, synp.read_text(encoding="utf-8", errors="replace"), UNDEF)
    pname = ((comp["analytic"] or {}).get("project") or {}).get("name") or proj
    pnav, pbody, pn = guide.build(lang, pf, pname, chain_html)
    open_tab("poss", GUIDE[lang]["tab"], pn)
    tabs["poss"]["nav"], tabs["poss"]["body"] = pnav, [pbody]

    n_err = sum(tb["err"] for tb in tabs.values())
    n_warn = sum(tb["warn"] for tb in tabs.values())
    marks0 = (f'<span class="nb error">{n_err}</span>' if n_err else "") + (f'<span class="nb warning">{n_warn}</span>' if n_warn else "")
    tabbar = [f'<button class="tab" type="button" role="tab" data-tab="overview">{E(s["overview"])}{marks0}</button>']
    navs = ['<div class="navpane" data-tab="overview"></div>']
    panes = [f'<div class="tabpane" role="tabpanel" data-tab="overview" id="tab-overview">{overview}</div>']
    for key, tb in tabs.items():
        marks = ""
        if tb["err"]:
            marks += f'<span class="nb error">{tb["err"]}</span>'
        if tb["warn"]:
            marks += f'<span class="nb warning">{tb["warn"]}</span>'
        cls = " pend" if key == "pending" else ""
        short = TAB_SHORT[lang].get(key, tb["label"])
        count = f'{tb["n"] - tb["hidden"]}/{tb["n"]}' if tb["hidden"] else str(tb["n"])
        tabbar.append(f'<button class="tab{cls}" type="button" role="tab" data-tab="{key}" title="{E(tb["label"])}">{E(short)}'
                      f'<small>{count}</small>{marks}</button>')
        navs.append(f'<div class="navpane" data-tab="{key}">{"".join(tb["nav"])}</div>')
        panes.append(f'<div class="tabpane" role="tabpanel" data-tab="{key}" id="tab-{key}">{"".join(tb["body"])}</div>')

    data = {"f": fields, "c": concepts, "r": relations, "o": OCC, "s": {k: s[k] for k in (
        "undef", "undef_hint", "goto_def", "rel_undef", "declared_rel", "values", "guidelines", "scope", "copied",
        "see_occ", "in_src", "go_block", "close", "tech_on", "tech_off", "q_notfound", "q_note", "hand_edit", "oc_diag", "no_def",
        "focus", "dist", "in_k", "pick_hint", "no_entry", "occ_hidden", "not_shown", "open_vs", "dist_g")}, "see_all": s["see_all"],
        "uses": s["uses"], "occ_n": s["occ_n"], "found_n": s["found_n"], "k": KW[lang], "u": sorted(UNDEF),
        "mf": next((k for k, v in fields.items() if v["t"] == "MEMO"), ""),
        "mk": "g" if SEL.get("by_group") else "s"}
    js = _JS + "var T=" + json.dumps(data, ensure_ascii=False).replace("<", "\\u003c") + ";" + EXTRA_JS
    hint = f'{vs["hint"]} {s["legend"]}'
    CONCEPTS_SEEN.clear()
    CONCEPTS_SEEN.update(concepts)
    top = max(((c, len(lst)) for c, lst in OCC.items()), key=lambda x: (x[1], [-ord(ch) for ch in x[0]]), default=None)
    n_src = sum(1 for e in entries if e.group == "annotations" for b in parse_cached(e.path.read_text(encoding="utf-8")) if b.kind == "block" and b.kw == "SOURCE")
    n_items = len((comp["analytic"] or {}).get("corpus") or [])
    no_source = "" if (n_src or pending) else E(SOURCES[lang]["tip"]).replace(
        "{link}", f'<a href="#tab-sources">{E(SOURCES[lang]["tab"])}</a>')
    n_tips, start_html = help_html(lang, s, pname, n_src, n_items, len(concepts), problems, bool(pending),
                                   vs["awaiting"], GUIDE[lang]["tab"], anc, top, hint, no_source)
    tabbar.insert(1, f'<button class="tab" type="button" role="tab" data-tab="start">{E(HELP[lang]["tab"])}<small>{n_tips}</small></button>')
    navs.insert(1, '<div class="navpane" data-tab="start"></div>')
    panes.insert(1, f'<div class="tabpane" role="tabpanel" data-tab="start" id="tab-start">{start_html}{support_html(lang)}</div>')
    n_files, src_html = sources_html(lang, synp.parent, synp)
    tabbar.insert(2, f'<button class="tab" type="button" role="tab" data-tab="sources">{E(SOURCES[lang]["tab"])}'
                     + (f"<small>{n_files}</small>" if n_files else "") + "</button>")
    navs.insert(2, '<div class="navpane" data-tab="sources"></div>')
    panes.insert(2, f'<div class="tabpane" role="tabpanel" data-tab="sources" id="tab-sources">{src_html}</div>')
    first = "overview" if (n_src or pending) else "sources"      # nothing coded yet: how to add sources comes first
    return PAGE.format(lang=(LANGS.get(lang) or LANGS["en"])["html"], base=E(base), start=first, title=E(proj), s_title=E(vs["title"]), s_search=E(vs["search"]), s_help=E(s["help"]),
                       s_code=E(s["tech_off"]), s_theme=E(vs["theme"]), s_hint=E(hint), s_nomatch=E(vs["no_match"]),
                       tabs="".join(tabbar), navs="".join(navs), body="".join(panes),
                       docs_url=DOCS_URL, gh_url=GITHUB_URL, gh_svg=GH_SVG, l_docs=E(LINKS[lang]["docs"]),
                       l_made=E(LINKS[lang]["made"]), l_cite=E(LINKS[lang]["cite"]),
                       css=_CSS + EXTRA_CSS + guide.CSS + THEME_CSS + COMP_CSS + DEPTH_CSS, js=js)


DEPTH_CSS = """
.depth{margin:0 0 14px}.depth p{margin:4px 0}.depth .strata{display:flex;flex-wrap:wrap;gap:4px;margin:6px 0}
.depth .asks{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:8px}
.oc.x{padding:6px 10px}.oc.x .src{margin:0}.occ-more{margin:8px 0 0}
"""


def depth_banner(s: Dict[str, Any], proj: str) -> str:
    """What this page shows of a large project, and how to ask for more."""
    out = SEL.get("outside", 0)
    note = f'<p class="muted small">{E(s["outside"].format(n=out))}</p>' if out else ""
    if SEL.get("keys") is None and SEL.get("concepts") is None:
        return f'<div class="banner depth">{note}</div>' if note else ""
    d = SEL["depth"]
    est = (SEL.get("est") or {}).get("full") or {}
    keys = SEL.get("keys")
    conc = SEL.get("concepts")
    n_c = SEL.get("n_concepts", 0)
    parts = [s["depth_text"].format(k=len(keys) if keys is not None else SEL.get("total", 0), n=SEL.get("total", 0),
                                    c=len(conc) if conc is not None else n_c, ct=n_c)]
    if SEL.get("focus"):
        parts.append(s["focus_on"].format(f=SEL["focus"], kind=s["focus_kind"].get(SEL.get("matched"), "?")))
    parts.append(s["depth_how"][d])
    rule = SEL.get("rule", "")
    parts.append(s["rule"]["folder"] if rule == "folder" else s["rule"]["field"].format(f=rule) if rule else "")
    if d != "full":
        parts.append(s["seed_note"].format(seed=SEL.get("seed")))
    strata = SEL.get("strata") or {}
    chips = "".join(f'<span class="chip-s muted">{E(name or "—")} {k}/{n}</span>'
                    for name, (k, n) in list(strata.items())[:16] if name or len(strata) > 1)
    extra = f'<p class="muted small">{E(s["depth_extra"].format(n=SEL["extra"]))}</p>' if SEL.get("extra") else ""
    asks = []
    if d != "sample":
        asks.append((s["b_sample"], s["ask_sample"].format(proj=proj)))
    if d != "full" or SEL.get("focus"):
        sec, mb = est.get("seconds", "?"), est.get("page_mb", "?")
        asks.append((s["b_full"].format(sec=sec, mb=mb), s["ask_full"].format(proj=proj, sec=sec, mb=mb)))
    asks.append((s["b_focus"], s["ask_focus"].format(proj=proj)))
    buttons = "".join(f'<button class="act ask" type="button" data-ask="{E(t)}">{E(b)}</button>' for b, t in asks)
    return (f'<div class="banner depth" id="depth"><p><b>{E(s["depth_t"][d])}.</b> {E(" ".join(p for p in parts if p))}</p>'
            f'<p class="muted small">{E(s["depth_whole"])}</p>'
            + (f'<div class="strata">{chips}</div>' if chips else "") + extra + note
            + f'<div class="asks"><span class="muted small">{E(s["more"])}</span>{buttons}</div></div>')


def sources_html(lang: str, folder: Path, synp: Optional[Path]) -> Tuple[int, str]:
    """The "Your sources" tab: formats, what to do with PDF, and the inventory of the inbox."""
    t = SOURCES.get(lang) or SOURCES["en"]
    inv = intake.scan(folder)
    name = inv["inbox"] or t["inbox"]

    def fill(text: str) -> str:                          # the folder name in code style
        return E(text).replace("{folder}", f"<code>{E(name)}/</code>")
    steps = "".join(f"<li><span>{fill(x)}</span></li>" for x in t["steps"])
    request = t["request"].replace("{folder}", name + "/")
    fmts = "".join(
        f'<article class="fmt"><h3>{E(t[k + "_t"])}</h3><dl><dt>{E(t["when"])}</dt><dd>{E(t[k + "_when"])}</dd>'
        f'<dt>{E(t["reads"])}</dt><dd>{E(t[k + "_reads"])}</dd><dt>{E(t["needs"])}</dt><dd>{E(t[k + "_needs"])}</dd>'
        f'<dt>{E(t["example"])}</dt><dd><pre>{E(EXAMPLES[k])}</pre></dd></dl></article>' for k in ("bib", "text", "toml"))
    rows = []
    for f in inv["files"]:
        say = t["kinds"][f["kind"]].format(**{k: f.get(k, "") for k in ("n", "a", "m")})
        more = []
        if f.get("words"):
            more.append(t["words"].format(n=f["words"]))
        if f.get("of"):
            more.append(t["dup"].format(of=f["of"]))
        done = ""
        if f.get("keys") is not None:
            shown = ", ".join(f["keys"][:6]) + ("…" if len(f["keys"]) > 6 else "")
            done = f'<span class="chip-s ok">✓ {E(t["done"].format(keys=shown))}</span> ' if shown else '<span class="chip-s ok">✓</span> '
        cls = "" if f["kind"] in ("text_ok", "docx_ok", "bib_ok", "toml_ok", "duplicate") or done else ' class="warnl"'
        label = f["name"]                                # with neutral keys, a prepared file shows its key, not its name
        if inv["neutral"] and f.get("keys"):
            label, done = f["keys"][0], '<span class="chip-s ok">✓</span> '
        elif inv["neutral"] and f.get("of"):
            label, more = "—", []
        rows.append(f'<tr><td class="mono">{E(label)}</td><td>{done}<span{cls}>{E(say)}</span>'
                    + (f' <span class="muted small">{E(" · ".join(more))}</span>' if more else "") + "</td></tr>")
    if rows:
        table = (f'<div class="tw"><table class="invt"><thead><tr><th>{E(t["th_file"])}</th><th>{E(t["th_what"])}</th></tr></thead>'
                 f'<tbody>{"".join(rows)}</tbody></table></div>')
    else:
        table = f'<p class="muted">{fill(t["inv_empty"] if inv["inbox"] else t["inv_none"])}</p>'
    state = ""
    if synp is not None:
        st = intake.project_sources(synp)
        if any(st.values()):
            state = f'<p>{E(t["state"].format(**st))}</p>'
    pdf = "".join(f"<li>{E(x)}</li>" for x in t["pdf"])
    return len(inv["files"]), (
        f'<section class="start srcs"><div class="eyebrow">{E(t["tab"])}</div><h1>{E(t["title"])}</h1>'
        f'<p class="about">{E(t["intro"])}</p><ol class="steps">{steps}</ol>'
        f'<button class="act ask" type="button" data-ask="{E(request)}">{E(t["ask"])}</button>'
        f'<p class="privacy">{E(t["priv"])}</p>{state}'
        f'<h2>{E(t["inv"])}</h2>{table}<h2>{E(t["what"])}</h2><div class="fmts">{fmts}</div>'
        f'<div class="pdfbox"><h2>{E(t["pdf_t"])}</h2><p>{E(t["pdf_intro"])}</p><ol>{pdf}</ol><p>{E(t["pdf_conn"])}</p><p class="muted">{E(t["pdf_alt"])}</p></div>'
        '</section>')


def render_intake(folder: Path, lang: str, base: str) -> str:
    """Page of a folder that has no .synp yet: how to add sources, and how to support Synesis."""
    s, vs, t = S[lang], STRINGS[lang], SOURCES[lang]
    _, src_html = sources_html(lang, folder, None)
    data = {"f": {}, "c": {}, "r": {}, "o": {}, "u": [], "k": {}, "mf": "", "uses": s["uses"], "occ_n": s["occ_n"],
            "found_n": s["found_n"], "see_all": s["see_all"], "s": {k: v for k, v in s.items() if isinstance(v, str)}}
    js = _JS + "var T=" + json.dumps(data, ensure_ascii=False).replace("<", "\\u003c") + ";" + EXTRA_JS
    return PAGE.format(
        lang=LANGS[lang]["html"], base=E(base), start="sources", title=E(folder.name), s_title=E(vs["title"]),
        s_search=E(vs["search"]), s_code=E(s["tech_off"]), s_theme=E(vs["theme"]), s_nomatch=E(vs["no_match"]),
        tabs=f'<button class="tab" type="button" role="tab" data-tab="sources">{E(t["tab"])}</button>',
        navs='<div class="navpane" data-tab="sources"></div>',
        body=f'<div class="tabpane" role="tabpanel" data-tab="sources" id="tab-sources">{src_html}{support_html(lang)}</div>',
        docs_url=DOCS_URL, gh_url=GITHUB_URL, gh_svg=GH_SVG, l_docs=E(LINKS[lang]["docs"]), l_made=E(LINKS[lang]["made"]),
        l_cite=E(LINKS[lang]["cite"]), css=_CSS + EXTRA_CSS + guide.CSS + THEME_CSS + COMP_CSS, js=js)


def build_intake(folder: Path, lang: Optional[str] = None) -> Path:
    """Write <folder>/view/index.html for a folder with no project file yet."""
    folder = Path(folder).resolve()
    out = folder / "view"
    out.mkdir(parents=True, exist_ok=True)
    target = out / "index.html"
    target.write_text(render_intake(folder, _ui_lang(lang) or default_language(), ".."), encoding="utf-8", newline="\n")
    return target


def bars(rows, link=None, bad=None, occ=False, s=None):
    """Horizontal bars of a single series (no legend); the value is written next to each bar."""
    if not rows:
        return ""
    top = max(v for _, v in rows) or 1
    out = []
    for name, v in rows:
        target = link(name) if link else None
        lab = f'<a href="#{target}">{E(name)}</a>' if target else E(name)
        if occ:
            lab = f'<a href="#" data-occ="{E(name)}">{E(name)}</a>'
        cls = ""
        if bad is not None and name not in bad:
            cls = " bad-row"
            lab = (f'<span class="rel undef" data-r="{E(name)}" data-rf="" tabindex="0">{E(name)}</span>'
                   f'<small class="badl">{E(s["rel_invalid"]) if s else ""}</small>')

        out.append(f'<div class="bar-row{cls}" title="{E(name)}: {v}"><span class="bl">{lab}</span>'
                   f'<span class="bt"><span class="bf" style="width:{max(2, round(100 * v / top))}%"></span></span>'
                   f'<span class="bv">{v}</span></div>')
    return '<div class="bars">' + "".join(out) + "</div>"


def dashboard(synp, lang, comp, entries, fields, types, concepts, anc, panel):
    s = S[lang]
    base = synp.parent
    analytic = comp["analytic"] or {}
    proj = analytic.get("project") or {}
    questions, desc = [], proj.get("description") or ""
    for n in parse(synp.read_text(encoding="utf-8", errors="replace")):
        for c in (n.children if n.kind == "block" else []):
            if c.kind == "block" and c.kw == "QUESTIONS":
                questions = [(q.kw, q.text) for q in c.children if q.kind == "entry"]
    n_src = n_item = n_codes = n_chain = 0
    rel_count = {}
    for e in entries:
        if e.group != "annotations":
            continue
        for b in parse_cached(e.path.read_text(encoding="utf-8")):
            if b.kind != "block":
                continue
            n_src += b.kw == "SOURCE"
            n_item += b.kw == "ITEM"
            for f in b.children:
                if f.kind != "field":
                    continue
                val = " ".join([f.text, *f.extra])
                if types.get(f.kw) == "CODE":
                    n_codes += len([x for x in val.split(",") if x.strip()])
                elif types.get(f.kw) == "CHAIN" and val.strip():
                    n_chain += 1
                    parts = [x.strip() for x in val.split("->")]
                    for r in parts[1:-1:2]:
                        rel_count[r] = rel_count.get(r, 0) + 1
    has = set(types.values())             # show an indicator only for what this template has
    tiles = [(s["t_sources"], n_src), (s["t_items"], n_item)]
    if concepts:
        tiles.append((s["t_concepts"], len(concepts)))
    if "CODE" in has:
        tiles.append((s["t_codes"], n_codes))
    if "CHAIN" in has:
        tiles.append((s["t_chains"], n_chain))
    tiles_html = "".join(f'<div class="kpi"><span class="kv">{v}</span><span class="kl">{E(k)}</span></div>' for k, v in tiles)

    def concept_link(name):
        c = concepts.get(name) or {}
        if not c.get("file"):
            return None
        return f'c-{re.sub(r"[^a-z0-9]+", "-", c["file"].lower())}-{c.get("line")}'

    used = sorted(((k, c["n"]) for k, c in concepts.items() if c["n"]), key=lambda x: (-x[1], x[0]))
    unused = sorted(k for k, c in concepts.items() if not c["n"])
    rels = sorted(rel_count.items(), key=lambda x: (-x[1], x[0]))

    runs = []
    for mf in sorted((base / "runs").glob("*/manifest.json")):
        m = _manifest(mf)
        st = m.get("status", "")
        label = RUN_STATUS[lang].get(st, s["awaiting_short"])
        cls = "ok" if st == "accepted" else "muted" if st in ("stale", "rejected") else "pend"
        date = fmt_date(m.get("accepted_on") or m.get("created_on", ""), lang)
        runs.append(f'<tr><td class="mono">{E(m.get("id", mf.parent.name))}</td><td>{E(m.get("mode", ""))}</td>'
                    f'<td>{E(m.get("target", ""))}</td><td><span class="chip-s {cls}">{E(label)}</span></td>'
                    f'<td>{E(date)}</td><td class="muted">{E(m.get("model", ""))}</td></tr>')
    flds = "".join(f'<tr><td><span class="fname" data-f="{E(k)}" tabindex="0">{E(k)}</span></td><td class="mono">{E(v["t"])}</td>'
                   f'<td class="mono">{E(v["s"])}</td><td>{E(v["d"])}</td></tr>' for k, v in fields.items())
    qs = "".join(f'<li><b>{E(k)}</b><span>{E(v)}</span></li>' for k, v in questions)
    qhtml = f'<h3>{E(s["questions"])}</h3><ol class="qs">{qs}</ol>' if qs else ""
    unused_html = (f'<p class="muted small">{E(s["unused"])}: ' + ", ".join(E(u) for u in unused) + "</p>") if unused else ""
    declared = {r for f in fields.values() for r in f["r"]}
    rel_html = bars(rels, bad=declared, s=s) or '<p class="muted">—</p>'
    return (f'<section class="dash-head"><div class="eyebrow">{E(s["eyebrow"])}</div><h1>{E(proj.get("name") or synp.stem)}</h1>'
            f'<p class="desc">{E(desc)}</p>{qhtml}</section>'
            f'<div class="kpis" aria-label="{E(s["corpus"])}">{tiles_html}</div>{panel}'
            + matrix(s, concepts, fields) +
            f'<div class="grid2"><section class="box"><h3>{E(s["top_concepts"])}</h3>{bars(used[:12], occ=True)}{unused_html}</section>'
            f'<section class="box"><h3>{E(s["relations_used"])}</h3>{rel_html}</section></div>'
            f'<details class="box fold"><summary><h3>{E(s["runs"])}</h3><span class="muted small">{len(runs)}</span></summary><div class="tw"><table class="runs"><thead><tr><th>{E(s["th_run"])}</th>'
            f'<th>{E(s["th_mode"])}</th><th>{E(s["th_target"])}</th><th>{E(s["th_status"])}</th><th>{E(s["th_date"])}</th>'
            f'<th>{E(s["th_model"])}</th></tr></thead><tbody>{"".join(runs)}</tbody></table></div></details>'
            f'<details class="box fold"><summary><h3>{E(s["tpl_fields"])}</h3><span class="muted small">{len(fields)}</span></summary><div class="tw"><table class="tflds"><thead><tr><th>{E(s["th_field"])}</th>'
            f'<th>{E(s["th_type"])}</th><th>{E(s["th_scope"])}</th><th>{E(s["th_desc"])}</th></tr></thead><tbody>{flds}</tbody></table></div></details>')


def legend(top, s):
    vals = list(range(1, top + 1)) if top <= 6 else sorted({1, (top + 1) // 2, top})
    sw = "".join(f'<span class="sw" style="--p:{18 + round(62 * v / top)}%">{v}</span>' for v in vals)
    return f'<div class="mxlegend">{sw}<span>{E(s["legend_n"])}</span></div>'


def matrix(s, concepts=None, fields=None):
    """Concepts (rows) x sources (columns); cell = number of items. One sequential scale, value as text."""
    if not OCC:
        return ""
    col = "g" if SEL.get("by_group") else "s"       # columns: groups of a large project, or sources
    at = "" if col == "g" else "@"
    per_src: Dict[str, int] = {}
    for lst in OCC.values():
        for o in lst:
            per_src[o[col]] = per_src.get(o[col], 0) + 1
    all_sources = sorted(per_src, key=lambda x: (-per_src[x], x))
    sources = sorted(all_sources[:MATRIX_MAX_COLS], key=all_sources.index)
    all_rows = sorted(OCC.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    rows = all_rows[:MATRIX_MAX_ROWS]
    concepts, fields = concepts or {}, fields or {}
    topic = next((k for k, v in fields.items() if v["t"] == "TOPIC" and v["s"] == "ONTOLOGY"), None)

    def group_of(name):
        for k, v in (concepts.get(name) or {}).get("f", []):
            if k == topic:
                return v
        return ""
    groups = sorted({group_of(n) for n, _ in rows} - {""})
    top = max(sum(1 for o in lst if o[col] == src) for _, lst in rows for src in sources) or 1
    head = "".join(f'<th class="mc" data-ci="{i}">{at}{E(x or "—")}</th>' for i, x in enumerate(sources))
    body = []
    for name, lst in rows:
        cells = []
        for ci, src in enumerate(sources):
            v = sum(1 for o in lst if o[col] == src)
            if v:
                pct = 18 + round(62 * v / top)
                cells.append(f'<td class="mc" data-ci="{ci}"><a href="#" class="cell" data-occ="{E(name)}" data-src="{E(src)}" '
                             f'style="--p:{pct}%" title="{E(name)} · {at}{E(src)}: {v}">{v}</a></td>')
            else:
                cells.append(f'<td class="mc" data-ci="{ci}"><span class="cell zero"></span></td>')
        undef = name in UNDEF
        mark = f' <small class="nodef">{E(s["no_def"])}</small>' if undef else ""
        n_src = len({o["s"] for o in lst})
        body.append(f'<tr data-n="{len(lst)}" data-ns="{n_src}" data-name="{E(name)}" data-g="{E(group_of(name))}">'
                    f'<th class="mr"><a href="#" data-pick="{E(name)}" class="{"undef" if undef else ""}">{E(name).replace("_", "_<wbr>")}</a>{mark}</th>{"".join(cells)}'
                    f'<td class="mc tot">{len(lst)}</td></tr>')
    gsel = ""
    if topic and groups:
        opts = "".join(f'<option value="{E(g)}">{E(g)}</option>' for g in groups)
        gsel = (f'<label>{E(s["group"])} <select id="mxg"><option value="">{E(s["all"])}</option>{opts}</select></label>')
    tools = (f'<div class="mxt"><label>{E(s["sort_by"])} <select id="mxs"><option value="n">{E(s["by_n"])}</option>'
             f'<option value="ns">{E(s["by_ns"])}</option><option value="name">{E(s["by_name"])}</option></select></label>{gsel}</div>')
    title, capped = (s["matrix_g"], s["capped_g"]) if col == "g" else (s["matrix"], s["capped"])
    return (f'<section class="box" id="matrix"><h3>{E(title)}</h3><p class="muted small">{E(s["matrix_hint"])} {E(s["matrix_hint2"])}</p>{tools}'
            + (f'<p class="muted small">{E(capped.format(r=len(rows), rt=len(all_rows), c=len(sources), ct=len(all_sources)))}</p>'
               if len(rows) < len(all_rows) or len(sources) < len(all_sources) else "")
            + f'<div class="mxwrap"><div class="mxleft"><div class="tw mxs"><table class="mx" data-ns="{len({o["s"] for lst in OCC.values() for o in lst}) if col == "g" else len(all_sources)}"><thead><tr><th class="mr"></th>{head}<th class="mc">Σ</th></tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table></div><p class="scroll-hint">{E(s["scroll_hint"])}</p>{legend(top, s)}</div>'
            f'<aside class="mxsum" id="mxsum" aria-live="polite"></aside></div></section>')


def fmt_date(d, lang):
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", d or "")
    if not m:
        return d or ""
    return (LANGS.get(lang) or LANGS["en"])["date"].format(y=m.group(1), m=m.group(2), d=m.group(3))


def problems_panel(problems, anc, props, s, proj):
    order = {"error": 0, "warning": 1, "anchor": 2, "edit": 3, "info": 4}
    problems.sort(key=lambda p: (order.get(p[0], 9), p[2], p[3]))
    cnt = {k: sum(p[0] == k for p in problems) for k in order}
    summ = anc.get("summary", {})
    total = sum(summ.values())
    chips = []
    for key, sev, cls in (("error", "error", "error"), ("warning", "warning", "warning"),
                          ("notfound", "anchor", "warning"), ("edited", "edit", "edit")):
        if cnt[sev]:
            chips.append(f'<span class="chip-s {cls}">{cnt[sev]} {E(plural(s[key], cnt[sev]))}</span>')
    if props:
        chips.append(f'<span class="chip-s pend">{len(props)} {E(plural(s["pending"], len(props)))}</span>')
    chips.append(f'<span class="chip-s ok" title="{E(s["q_note"])}">✓ {E(s["verified"].format(n=summ.get("found", 0), t=total))}</span>')

    def row(sev, msg, rel, line, cid):
        target = f'#{cid}' if cid else "#"
        where = (f'<span class="where"><a href="{target}">{E(rel)}:{line}</a>'
                 f'<a class="act vs" data-file="{E(rel)}" data-line="{line}" href="#">VS Code</a></span>') if rel else ""
        return (f'<li class="{sev}"><span class="sev">{E(s["sev"][sev])}</span>'
                f'<a class="pm" href="{target}">{E(msg)}</a>{where}</li>')

    valid = [p for p in problems if p[0] in ("error", "warning", "anchor", "info")]
    changes = [p for p in problems if p[0] == "edit"]
    ask_all = ""
    if valid:
        text = s["ask_all_text"].format(proj=proj, lines="\n".join(
            f"- [{s['sev'][p[0]]}] {p[2]}:{p[3]} {p[5] + ': ' if p[5] else ''}{p[6]}" for p in valid))
        ask_all = f'<button class="act ask" type="button" data-ask="{E(text)}">{E(s["ask_all"])}</button>'

    def sec(title, hint, items, extra=""):
        body = f'<ul>{"".join(items)}</ul>' if items else f'<p class="none">{E(s["none"])}</p>'
        return (f'<div class="psec"><div class="psh"><h4>{E(title)}</h4><span class="muted small">{E(hint)}</span>{extra}</div>'
                f'{body}</div>')

    prop_rows = []
    for run, files in props.items():
        msg = s["prop_msg"].format(run=run, files=", ".join(f for f, _ in files))
        prop_rows.append(row("prop", msg, "", 0, files[0][1]))
    return (f'<details class="problems" id="review"><summary class="ph"><b>{E(s["problems"])}</b>{"".join(chips)}'
            f'<span class="more-l">{E(s["details"])}</span></summary>'
            + sec(s["sec_valid"], s["sec_valid_hint"], [row(p[0], p[1], p[2], p[3], p[4]) for p in valid], ask_all)
            + sec(s["sec_changes"], s["sec_changes_hint"], [row(p[0], p[1], p[2], p[3], p[4]) for p in changes])
            + sec(s["sec_props"], s["sec_props_hint"], prop_rows)
            + '</details>')



VIEW_SETTINGS = "view-settings.json"
LAST: Dict[str, Any] = {}      # what the last build_view showed, for the command line


def build_view(synp: Path, out_dir: Optional[Path] = None, lang: Optional[str] = None,
               depth: Optional[str] = None, focus: Optional[str] = None, seed: Optional[int] = None,
               strata: Optional[str] = None, sources: Optional[int] = None) -> Path:
    """Write <project>/view/index.html (or <out_dir>/index.html) and return its path.

    Without `lang`, the page follows the language of the project (see page_language).
    Without `depth`, it follows the size of the project (sklib/size.py: small -> full,
    medium -> sample, large -> overview). Depth, focus, seed, strata and sources given once are
    kept in view/view-settings.json, so the refresh after check, code and accept keeps them;
    depth "auto" forgets them."""
    synp = Path(synp).resolve()
    out = Path(out_dir).resolve() if out_dir else synp.parent / "view"
    out.mkdir(parents=True, exist_ok=True)
    lang = (_ui_lang(lang) or "en") if lang else page_language(synp)[0]
    try:                       # the project folder as seen from the page, for the VS Code links
        base = Path(os.path.relpath(synp.parent, out)).as_posix()
    except ValueError:         # another drive (Windows): only then the absolute address is written
        base = synp.parent.as_uri()
    saved_path = out / VIEW_SETTINGS
    given = {"depth": depth, "focus": focus, "seed": seed, "strata": strata, "sources": sources}
    if depth == "auto":
        given = {}
        saved_path.unlink(missing_ok=True)
    elif any(v is not None for v in given.values()):
        given = {k: v for k, v in given.items() if v is not None}
        write_json_plain(saved_path, given)
    else:
        try:
            given = read_json(saved_path) if saved_path.exists() else {}
        except Exception:  # noqa: BLE001
            given = {}
    measured = sizing.measure(synp)
    chosen = given.get("depth") or measured["depth"]
    target = out / "index.html"
    page = render(synp, lang, base, chosen, given.get("focus"), given.get("seed", sampling.DEFAULT_SEED),
                  given.get("strata"), given.get("sources"), measured)
    target.write_text(page, encoding="utf-8", newline="\n")
    LAST.clear()
    LAST.update(depth=chosen, size=measured["class"], focus=given.get("focus") or "",
                shown=len(SEL["keys"]) if SEL.get("keys") is not None else SEL.get("total", 0),
                total=SEL.get("total", 0), groups=SEL.get("rule") or "", matched=SEL.get("matched", ""),
                outside=measured.get("outside", 0), page_mb=round(len(page.encode("utf-8")) / 1e6, 1))
    return target


def write_json_plain(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- page

_CSS = """
:root{--bg:#f6f7f9;--panel:#fff;--ink:#24292f;--muted:#6e7781;--line:#e3e6ea;--accent:#2f6fb2;
--kw:#0000ff;--name:#001080;--ref:#267f99;--rel:#795e26;--arrow:#af00db;--str:#a31515;--num:#098658;--com:#008000;
--ok:#1a7f37;--bad:#b3261e;--pill:#eef2f7;--shadow:0 1px 2px rgba(20,30,50,.06),0 2px 8px rgba(20,30,50,.05);
--s-source:#2e8b74;--s-item:#2f6fb2;--s-ontology:#8250b6;--s-field:#b7791f;--s-project:#57606a}
[data-theme=dark]{--bg:#1b1d21;--panel:#23262b;--ink:#d4d4d4;--muted:#8b949e;--line:#33373d;--accent:#6aa7e6;
--kw:#569cd6;--name:#9cdcfe;--ref:#4ec9b0;--rel:#dcdcaa;--arrow:#c586c0;--str:#ce9178;--num:#b5cea8;--com:#6a9955;
--ok:#56d364;--bad:#ff7b72;--pill:#2c3036;--shadow:0 1px 2px rgba(0,0,0,.3);
--s-source:#4fb59b;--s-item:#6aa7e6;--s-ontology:#b392e0;--s-field:#d6a24a;--s-project:#9aa4af}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 "Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif}
.layout{display:flex;min-height:100vh}
aside{width:270px;flex:none;padding:18px 14px;border-right:1px solid var(--line);background:var(--panel);position:sticky;top:0;height:100vh;overflow:auto}
aside h1{font-size:16px;margin:0 0 2px}aside .sub{color:var(--muted);font-size:12px;margin-bottom:12px}
aside h3{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:16px 0 4px}
aside h3.pend{color:var(--s-field)}
aside a{display:block;padding:5px 8px;border-radius:6px;color:var(--ink);text-decoration:none;font-size:13px}
aside a:hover{background:var(--pill)}aside a small{display:block;color:var(--muted);font-size:11px}
main{flex:1;min-width:0;padding:22px 28px 80px;max-width:1000px}
.bar{display:flex;gap:10px;align-items:center;margin-bottom:6px;flex-wrap:wrap}
.bar input[type=search]{flex:1;min-width:200px;padding:8px 12px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--ink);font:inherit}
.bar button{padding:7px 12px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--ink);cursor:pointer;font:inherit;font-size:13px}
.hint{color:var(--muted);font-size:12.5px;margin:0 0 14px}
h2.grp{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:26px 0 6px}
details.file{margin:10px 0}details.file>summary{cursor:pointer;list-style:none;display:flex;gap:10px;align-items:baseline;padding:6px 2px}
details.file>summary::-webkit-details-marker{display:none}.fn{font-weight:600}.cnt{color:var(--muted);font-size:12.5px}
.banner{border:1px solid var(--s-field);border-left-width:4px;background:var(--panel);border-radius:8px;padding:10px 14px;margin:6px 0 10px}
.card{background:var(--panel);border:1px solid var(--line);border-left:4px solid var(--s-project);border-radius:10px;margin:10px 0;box-shadow:var(--shadow);overflow:hidden}
.card.nested{box-shadow:none;margin:8px 12px;border-radius:8px}
.k-source{border-left-color:var(--s-source)}.k-item{border-left-color:var(--s-item)}.k-ontology{border-left-color:var(--s-ontology)}
.k-field{border-left-color:var(--s-field)}.k-project{border-left-color:var(--s-project)}
.head,.foot{padding:7px 14px;font:12.5px/1.4 ui-monospace,SFMono-Regular,Consolas,Menlo,monospace}
.head{border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--panel) 92%,var(--ink) 8%)}
.foot{border-top:1px solid var(--line);color:var(--muted);opacity:.8}
.kw{color:var(--kw);opacity:.85}.name{color:var(--name);font-weight:600}.ref{color:var(--ref);font-weight:600}.ftype{color:var(--ref)}
.badge{float:right;font:11px "Segoe UI",system-ui,sans-serif;color:var(--s-field);border:1px solid var(--s-field);border-radius:20px;padding:1px 8px}
.body{padding:8px 14px 10px;display:grid;grid-template-columns:max-content minmax(0,1fr);column-gap:12px;row-gap:4px;align-items:baseline}
.body>.text,.body>.mark,.body>.note,.body>.card{grid-column:1/-1}
.k{white-space:nowrap}.fname{color:var(--name);font-weight:600;font-size:13.5px}
.colon{color:var(--muted);opacity:.55;margin-left:1px}.fval{min-width:0;overflow-wrap:anywhere}
.pk{font:12.5px ui-monospace,Consolas,monospace}.str{color:var(--str);opacity:.9}
.pill{display:inline-block;background:var(--pill);color:var(--ref);border-radius:20px;padding:0 9px;margin:1px 4px 1px 0;font-size:13px}
.chip{display:inline-block;border:1px solid var(--line);color:var(--rel);border-radius:6px;padding:0 8px;font-size:13px;margin-right:4px}
.num{color:var(--num);font-variant-numeric:tabular-nums}.empty{color:var(--muted)}.cont{color:var(--muted);font-size:12px}
.quote{display:block;border-left:3px solid var(--s-item);padding:1px 0 1px 10px;color:color-mix(in srgb,var(--str) 72%,var(--ink));quotes:none;font-style:italic}
.chain .concept{color:var(--ref);font-weight:600}.chain .rel{color:var(--rel);font-size:12.5px;letter-spacing:.03em}.arrow{color:var(--arrow);margin:0 6px}
.note{color:var(--com);font-style:italic;font-size:13px;padding:2px 0}.text{padding:2px 0}
.mark{padding:3px 8px;border-left:3px solid var(--line);margin:3px 0;font-size:13.5px}
.mark.good{border-color:var(--ok)}.mark.good b{color:var(--ok)}.mark.bad{border-color:var(--bad)}.mark.bad b{color:var(--bad)}
.loose{padding:2px 4px 6px}.nomatch{display:none;color:var(--muted);padding:20px}
body.nocode .foot,body.nocode .colon{display:none}body.nocode .head{font:inherit;font-size:14px;background:none}
@media(max-width:820px){aside{display:none}main{padding:16px}}
@media print{aside,.bar{display:none}.card{break-inside:avoid;box-shadow:none}}
"""

_JS = """
(function(){var d=document,r=d.documentElement,b=d.body;
var dark=matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches;r.setAttribute('data-theme',dark?'dark':'light');
d.getElementById('theme').onclick=function(){r.setAttribute('data-theme',r.getAttribute('data-theme')==='dark'?'light':'dark')};
d.getElementById('code').onclick=function(){b.classList.toggle('nocode')};
var q=d.getElementById('q'),cards=[].slice.call(d.querySelectorAll('.card:not(.nested)')),nm=d.getElementById('nomatch');
q.oninput=function(){var t=q.value.trim().toLowerCase(),n=0;cards.forEach(function(c){var ok=!t||(c._s||(c._s=c.textContent.toLowerCase())).indexOf(t)>-1;c.style.display=ok?'':'none';if(ok)n++});
nm.style.display=(t&&!n)?'block':'none'};})();
"""
