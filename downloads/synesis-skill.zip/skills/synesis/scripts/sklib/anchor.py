"""Quotation anchoring with three states: found, not_found, unverifiable.

Differences from `synesis-coder anchor` (0.15.0), which this replaces inside the skill:
- every QUOTATION field of every ITEM is checked, not only the first filled one;
- an ITEM whose source text is unavailable is reported as `unverifiable`
  instead of being skipped and counted as "no problems";
- source texts come from the run records (the exact text sent to the model),
  from `fontes/<bibref>.*` files, or from the `abstract` of the .bib entry;
- the normalization is declared in the report, and `literal` mode disables it.
"""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Optional

from .common import read_json, rel

NORMALIZATION = [
    "Unicode NFKC",
    "typographic quotes -> ASCII quotes",
    "en/em dashes and minus -> hyphen",
    "ellipsis character -> three dots",
    "soft hyphen removed; hyphen at line break joined",
    "any whitespace run -> one space",
    "leading/trailing quote marks of the excerpt ignored",
]

_QUOTES = {"“": '"', "”": '"', "„": '"', "«": '"', "»": '"',
           "‘": "'", "’": "'", "‚": "'", "′": "'"}
_DASHES = {"–": "-", "—": "-", "−": "-", "‐": "-", "‑": "-"}


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("­", "")
    text = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", text)
    for a, b in {**_QUOTES, **_DASHES}.items():
        text = text.replace(a, b)
    text = text.replace("…", "...")
    return re.sub(r"\s+", " ", text).strip()


def _strip_outer_quotes(text: str) -> str:
    return text.strip().strip('"').strip("'").strip()


def _bib_abstract(entry: str) -> Optional[str]:
    """`abstract = {...}` (balanced braces) or `abstract = "..."` of one BibTeX entry."""
    m = re.search(r"abstract\s*=\s*([{\"])", entry, re.IGNORECASE)
    if not m:
        return None
    start = m.end()
    if m.group(1) == '"':
        end = entry.find('"', start)
        return entry[start:end] if end > 0 else None
    depth = 1
    for i in range(start, len(entry)):
        if entry[i] == "{":
            depth += 1
        elif entry[i] == "}":
            depth -= 1
            if depth == 0:
                return entry[start:i]
    return None


def run_sources(project_dir: Path) -> Dict[str, Dict[str, Dict[str, str]]]:
    """Accepted annotation file -> {bibref: {"text", "origin"}} from the run that produced it.

    Runs are read in id order and a later acceptance of the same file replaces an
    earlier one, so each file is anchored against the source version that
    generated its current content, never against an older one.
    """
    mapping: Dict[str, Dict[str, Dict[str, str]]] = {}
    runs_dir = project_dir / "runs"
    if not runs_dir.is_dir():
        return mapping
    for manifest in sorted(runs_dir.glob("*/manifest.json")):
        data = read_json(manifest)
        if data.get("status") != "accepted":
            continue
        texts: Dict[str, Dict[str, str]] = {}
        for key, info in (data.get("inputs") or {}).items():
            p = manifest.parent / info["path"]
            if not p.exists():
                continue
            origin = rel(p, project_dir)
            if info.get("kind") == "document_text":
                texts[key] = {"text": p.read_text(encoding="utf-8"), "origin": origin}
            elif info.get("kind") == "bib_entry":
                abstract = _bib_abstract(p.read_text(encoding="utf-8"))
                if abstract:
                    texts[key] = {"text": abstract, "origin": origin + ":abstract"}
        for accepted in (data.get("accepted_files") or {}):
            mapping[accepted] = texts
    return mapping


def source_texts(project_dir: Path, analytic: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
    """Fallback sources for items not produced by a recorded run: bibref -> {"text", "origin"}."""
    texts: Dict[str, Dict[str, str]] = {}
    for folder in ("fontes", "sources"):
        d = project_dir / folder
        if d.is_dir():
            for p in sorted(d.iterdir()):
                if p.suffix.lower() in {".txt", ".md"}:
                    texts.setdefault(p.stem, {"text": p.read_text(encoding="utf-8"),
                                              "origin": rel(p, project_dir)})
    for key, entry in ((analytic or {}).get("bibliography") or {}).items():
        abstract = (entry or {}).get("abstract")
        if abstract:
            texts.setdefault(key, {"text": abstract, "origin": f"bib:{key}:abstract"})
    return texts


def quotation_fields(analytic: Dict[str, Any]) -> List[str]:
    specs = ((analytic or {}).get("template") or {}).get("field_specs") or {}
    return sorted(n for n, s in specs.items()
                  if (s or {}).get("type") == "QUOTATION" and (s or {}).get("scope") == "ITEM")


def check(project_dir: Path, analytic: Dict[str, Any], state: str, literal: bool = False) -> Dict[str, Any]:
    fields = quotation_fields(analytic)
    fallback = source_texts(project_dir, analytic)
    by_file = run_sources(project_dir)
    cache: Dict[str, str] = {}

    def prepared(text: str) -> str:
        if text not in cache:
            cache[text] = text if literal else normalize(text)
        return cache[text]
    results: List[Dict[str, Any]] = []
    for item in (analytic or {}).get("corpus") or []:
        ref = str(item.get("source_ref", "")).lstrip("@")
        for field in fields:
            raw = (item.get("data") or {}).get(field)
            values = raw if isinstance(raw, list) else ([raw] if raw else [])
            for idx, value in enumerate(v for v in values if v):
                excerpt = str(value)
                entry = {
                    "item": item.get("id"),
                    "source_ref": ref,
                    "field": field,
                    "occurrence": idx,
                    "excerpt": excerpt,
                    "file": (item.get("traceability") or {}).get("file"),
                    "line": (item.get("traceability") or {}).get("line"),
                }
                source = (by_file.get(entry["file"] or "") or {}).get(ref) or fallback.get(ref)
                if source is None:
                    entry["status"] = "unverifiable"
                    entry["reason"] = "no source text available for this reference"
                else:
                    needle = excerpt if literal else normalize(_strip_outer_quotes(excerpt))
                    entry["status"] = "found" if needle and needle in prepared(source["text"]) else "not_found"
                    entry["origin"] = source["origin"]
                results.append(entry)
    summary = {s: sum(1 for r in results if r["status"] == s)
               for s in ("found", "not_found", "unverifiable")}
    items_without_quotation = sum(
        1 for item in (analytic or {}).get("corpus") or []
        if not any((item.get("data") or {}).get(f) for f in fields))
    return {
        "kind": "synesis-skill/anchoring",
        "state": state,
        "mode": "literal" if literal else "normalized",
        "normalization": [] if literal else NORMALIZATION,
        "quotation_fields": fields,
        "summary": summary,
        "items_without_quotation": items_without_quotation,
        # Verified only when every quotation was found and none is unverifiable.
        "verified": bool(results) and summary["not_found"] == 0 and summary["unverifiable"] == 0,
        "results": results,
    }
