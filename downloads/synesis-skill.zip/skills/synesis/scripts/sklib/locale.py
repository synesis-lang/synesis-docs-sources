"""Language of the researcher's environment.

Synesis itself stays in English (keywords, tool output, synesis-help). The
conversation and the project's own prose (DESCRIPTION, GUIDELINES, value
descriptions, QUESTIONS, coder output) follow the researcher's language.

The primary signal is the language the researcher writes in; this module gives
the secondary one, from the operating system, plus what the project already
declares. It never reads secrets: from the project `.env` it takes only the
`SYNESIS_CODER_LANGUAGE` line.
"""

from __future__ import annotations

import locale as _locale
import os
import re
import sys
from pathlib import Path
from typing import Dict, Optional

#: Tag -> how the coder is told the language (free text in its prompt).
LANGUAGE_NAMES = {
    "pt-BR": "Brazilian Portuguese",
    "pt-PT": "European Portuguese",
    "pt": "Portuguese",
    "en": "English",
    "es": "Spanish",
    "fr": "French",
    "de": "German",
    "it": "Italian",
}

_TAG = re.compile(r"^([A-Za-z]{2,3})(?:[_-]([A-Za-z]{2}))?")


def normalize(raw: str) -> Optional[str]:
    """`pt_BR.UTF-8`, `pt-br`, `Portuguese_Brazil.1252` -> `pt-BR`; None if unknown."""
    raw = (raw or "").strip()
    if not raw or raw.upper() in ("C", "POSIX"):
        return None
    lowered = raw.lower()
    if lowered.startswith("portuguese"):
        return "pt-BR" if "brazil" in lowered else "pt-PT" if "portugal" in lowered else "pt"
    if lowered.startswith("english"):
        return "en"
    m = _TAG.match(raw)
    if not m:
        return None
    lang = m.group(1).lower()
    region = (m.group(2) or "").upper()
    return f"{lang}-{region}" if region else lang


def _windows_ui_locale() -> Optional[str]:
    if not sys.platform.startswith("win"):
        return None
    try:
        import ctypes

        buf = ctypes.create_unicode_buffer(85)
        if ctypes.windll.kernel32.GetUserDefaultLocaleName(buf, 85):  # type: ignore[attr-defined]
            return buf.value
    except Exception:  # noqa: BLE001
        return None
    return None


def system_locale() -> Dict[str, Optional[str]]:
    """Locale of the operating system, with where it came from."""
    override = os.environ.get("SYNESIS_SKILL_LANG")
    if override:
        return {"tag": normalize(override), "source": "SYNESIS_SKILL_LANG"}
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        value = os.environ.get(var)
        tag = normalize(value.split(":")[0]) if value else None
        if tag:
            return {"tag": tag, "source": var}
    win = normalize(_windows_ui_locale() or "")
    if win:
        return {"tag": win, "source": "windows"}
    try:
        current = _locale.getlocale()[0]
    except (ValueError, TypeError):
        current = None
    tag = normalize(current or "")
    return {"tag": tag, "source": "python locale" if tag else None}


def project_language(synp: Optional[Path]) -> Optional[str]:
    """`SYNESIS_CODER_LANGUAGE` from the project `.env` (nothing else is read)."""
    if synp is None:
        return None
    env = Path(synp).resolve().parent / ".env"
    if not env.exists():
        return None
    for line in env.read_text(encoding="utf-8", errors="replace").splitlines():
        m = re.match(r"\s*SYNESIS_CODER_LANGUAGE\s*=\s*(.*)$", line)
        if m:
            return m.group(1).strip().strip('"').strip("'") or None
    return None


def report(synp: Optional[Path] = None) -> Dict[str, Optional[str]]:
    sysloc = system_locale()
    tag = sysloc["tag"]
    base = tag.split("-")[0] if tag else None
    return {
        "system_locale": tag,
        "system_locale_source": sysloc["source"],
        "suggested_coder_language": LANGUAGE_NAMES.get(tag or "") or LANGUAGE_NAMES.get(base or ""),
        "project_coder_language": project_language(synp),
        "synesis_language": "en",
        "rule": ("Keywords, tool output and synesis-help stay in English. Talk to the "
                 "researcher in the language they write in, and write the project's prose "
                 "(DESCRIPTION, GUIDELINES, value descriptions, QUESTIONS) in that language."),
    }
