# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""How big a project is, measured in about a second, without compiling it.

Claude reads this before any heavy step. In a large project it does not open the annotation,
ontology or bibliography files itself, it chooses the depth of the project view, and it tells the
researcher how long a complete pass will take before starting one.

The limits come from the projects of case-studies (study of 2026-11-27,
synesis-planning/synesis-skill/Limites_Tamanho_Projeto.md). A complete page weighs about 3.3 times
the data files it shows: small projects give pages under ~6 MB, which any browser opens at once;
above the large limit a complete page passes ~25 MB and takes seconds to open.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .common import iter_state_files

PAGE_FACTOR = 3.3          # complete page / bytes of annotations, ontology, references and records
SECONDS_PER_MB = 1.0       # building the complete page (compile, anchoring, page), per MB of project files
SECONDS_BASE = 2

# Units are items + ontology concepts + records (one card each); MB are the data files.
# A project is "medium" from either lower limit and "large" from either upper one.
LIMITS = {
    "medium": {"units": 1500, "mb": 2.0},
    "large": {"units": 5000, "mb": 8.0},
}
DEPTH_FOR = {"small": "full", "medium": "sample", "large": "overview"}

_SOURCE = re.compile(r"^[ \t]*SOURCE\b", re.M)
_ITEM = re.compile(r"^[ \t]*ITEM\b", re.M)
_CONCEPT = re.compile(r"^[ \t]*ONTOLOGY\b", re.M)
_BIB = re.compile(r"^[ \t]*@(?!comment|string|preamble)\w+\s*[{(]", re.M | re.I)
_DECL = re.compile(r'^[ \t]*(?:(TEMPLATE)|INCLUDE[ \t]+(SHARED[ \t]+)?(BIBLIOGRAPHY|ANNOTATIONS|ONTOLOGY|DATASET))'
                   r'[ \t]+"([^"]+)"', re.M | re.I)
_EXT = {"BIBLIOGRAPHY": ".bib", "ANNOTATIONS": ".syn", "ONTOLOGY": ".syno", "DATASET": ".toml"}

GROUP = {".synp": "project", ".synt": "template", ".syno": "ontology", ".syn": "annotations",
         ".toml": "records", ".bib": "references"}


def _expand(base: Path, raw: str, ext: Optional[str], shared: bool) -> List[Path]:
    """A literal of TEMPLATE/INCLUDE as the compiler reads it: file, wildcard or folder (recursive)."""
    try:
        from synesis.parser.paths import expand_include  # the compiler's own rule (synesis >= 0.16)

        return list(expand_include(base, raw, ext, shared=shared).files)
    except Exception:  # noqa: BLE001
        pass
    p = base / raw
    if any(ch in raw for ch in "*?["):
        return sorted(x for x in base.glob(raw) if x.is_file())
    if p.is_dir():
        return sorted(x for x in p.rglob(f"*{ext}") if x.is_file()) if ext else []
    return [p] if p.is_file() else []


def project_files(synp: Path) -> Optional[List[Path]]:
    """The .synp, its template and every file its INCLUDE lines reach, in a stable order.

    Copies kept in the folder (bkp/, tests, older versions) are not part of the project and are left
    out. None when the .synp has no INCLUDE line (a project still being set up, with its files not
    declared yet) or cannot be read: then the whole folder is used."""
    synp = Path(synp).resolve()
    base = synp.parent
    try:
        text = synp.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    text = "\n".join(ln for ln in text.splitlines() if not ln.lstrip().startswith("#"))
    found: List[Path] = [synp]
    includes = 0
    for m in _DECL.finditer(text):
        kind = "TEMPLATE" if m.group(1) else m.group(3).upper()
        includes += kind != "TEMPLATE"
        files = [base / m.group(4)] if kind == "TEMPLATE" else _expand(base, m.group(4), _EXT[kind], bool(m.group(2)))
        found += [f.resolve() for f in files if f.is_file()]
    if not includes:
        return None
    seen, out = set(), []
    for f in found:
        k = os.path.normcase(str(f))
        if k not in seen:
            seen.add(k)
            out.append(f)
    return out


def outside_files(synp: Path, files: Optional[List[Path]]) -> int:
    """Synesis files in the folder that the project does not include (backups, tests, old versions)."""
    if files is None:
        return 0
    synp = Path(synp).resolve()
    inside = {os.path.normcase(str(f)) for f in files}
    n = 0
    for p in iter_state_files(synp.parent):
        if p.suffix.lower() not in GROUP or p.suffix.lower() == ".synp" or "view" in p.relative_to(synp.parent).parts:
            continue
        if os.path.normcase(str(p.resolve())) not in inside:
            n += 1
    return n


def measure(synp: Path) -> Dict[str, Any]:
    """Counts and bytes of what the project includes, its size class, the depth of the view and
    the time and weight of a complete page."""
    synp = Path(synp).resolve()
    included = project_files(synp)
    paths = included if included is not None else [
        p for p in iter_state_files(synp.parent) if "view" not in p.relative_to(synp.parent).parts]
    files: Dict[str, int] = {}
    size: Dict[str, int] = {}
    n = {"sources": 0, "items": 0, "concepts": 0, "references": 0, "records": 0}
    for p in paths:
        g = GROUP.get(p.suffix.lower())
        if not g:
            continue
        b = p.stat().st_size
        files[g] = files.get(g, 0) + 1
        size[g] = size.get(g, 0) + b
        if g in ("annotations", "ontology", "references"):
            text = p.read_text(encoding="utf-8", errors="replace")
            if g == "annotations":
                n["sources"] += len(_SOURCE.findall(text))
                n["items"] += len(_ITEM.findall(text))
            elif g == "ontology":
                n["concepts"] += len(_CONCEPT.findall(text))
            else:
                n["references"] += len(_BIB.findall(text))
        elif g == "records":
            n["records"] += 1
    data_mb = sum(v for k, v in size.items() if k in ("annotations", "ontology", "references", "records")) / 1e6
    units = n["items"] + n["concepts"] + n["records"]
    cls = "small"
    for name in ("medium", "large"):
        if units >= LIMITS[name]["units"] or data_mb >= LIMITS[name]["mb"]:
            cls = name
    total_mb = sum(size.values()) / 1e6
    return {
        "class": cls,
        "depth": DEPTH_FOR[cls],
        "counts": n,
        "units": units,
        "files": files,
        "mb": round(data_mb, 1),
        "outside": outside_files(synp, included),
        "estimate": {
            "full": {"seconds": round(SECONDS_BASE + total_mb * SECONDS_PER_MB), "page_mb": round(data_mb * PAGE_FACTOR, 1)},
        },
    }
