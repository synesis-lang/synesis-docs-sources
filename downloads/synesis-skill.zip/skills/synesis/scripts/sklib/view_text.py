# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""User-facing strings of the project view, in English and Portuguese (Brazil).

Nothing here names a field of a particular template: field names, types and relations come from the
project at build time and are inserted where the strings say {f}, {v} and similar."""

S = {
    "pt": {
        "problems": "Problemas", "all_clear": "Nenhum problema: o projeto compila sem erros nem avisos.",
        "error": ("erro", "erros"), "warning": ("aviso", "avisos"), "notfound": ("trecho não encontrado na fonte", "trechos não encontrados na fonte"),
        "edited": ("arquivo editado depois da aceitação", "arquivos editados depois da aceitação"),
        "pending": ("execução aguardando aceitação", "execuções aguardando aceitação"),
        "verified": "{n} de {t} trechos conferidos na fonte",
        "line": "linha", "open_vs": "Abrir no VS Code", "ask": "Pedir ao Claude", "ask_all": "Pedir ao Claude para resolver tudo",
        "copied": "Pedido copiado. Cole na conversa com o Claude.",
        "q_found": "trecho conferido na fonte", "q_notfound": "trecho não encontrado na fonte", "q_unver": "fonte indisponível para conferir",
        "notfound_msg": "O trecho não aparece na fonte @{ref}, nem depois de normalizar aspas, travessões e espaços. Copie-o literalmente da fonte.",
        "accepted": "aceito na execução {run} · {date}", "hand_edit": "editado à mão depois da aceitação",
        "hand_edit_file": "editado à mão depois da aceitação (execução {run})", "new_block": "bloco novo, escrito à mão",
        "by_hand": "escrito à mão", "proposal": "proposta da execução {run}",
        "edited_msg": "{n} bloco(s) diferem do que foi aceito na execução {run}.",
        "undef": "Conceito sem definição na ontologia.", "undef_hint": "Peça ao Claude para propor uma definição.",
        "uses": ("usado em {n} item", "usado em {n} itens"), "goto_def": "ver definição",
        "rel_undef": "Relação não declarada no template para este campo.",
        "declared_rel": "Relações declaradas", "values": "Valores", "guidelines": "Orientações", "scope": "escopo",
        "legend": "Passe o mouse sobre as palavras em azul, os nomes de campo, os conceitos e as relações: uma explicação curta aparece.",
        "ask_fix": "No projeto {proj}, o bloco {blk} em {file}, linha {line}, tem estes problemas:\n{lines}\nExplique cada problema em linguagem simples e proponha a correção. Não altere nenhum arquivo antes de eu aprovar.",
        "ask_review": "No projeto {proj}, revise o bloco {blk} em {file}, linha {line}: confira se os códigos e a cadeia seguem as orientações do template e se o trecho sustenta a nota. Diga o que você mudaria, sem alterar o arquivo.",
        "ask_pending": "Sobre a proposta da execução {run} (bloco {blk}, linha {line}): explique as escolhas de códigos e de cadeia e diga se algo deve mudar antes de eu aceitar. Não aceite a execução por mim.",
        "ask_all_text": "No projeto {proj}, o painel de problemas mostra:\n{lines}\nResolva um de cada vez: explique o problema, proponha a correção e espere minha aprovação antes de alterar cada arquivo.",
        "sev": {"error": "erro", "warning": "aviso", "info": "info", "anchor": "trecho", "edit": "edição"},
        "overview": "Painel", "questions": "Questões de pesquisa", "t_sources": "fontes anotadas", "t_items": "itens",
        "t_concepts": "conceitos na ontologia", "t_codes": "códigos aplicados", "t_chains": "cadeias", "t_quotes": "trechos conferidos na fonte",
        "top_concepts": "Conceitos mais usados (nº de itens)", "relations_used": "Relações nas cadeias (nº de cadeias)",
        "unused": "Conceitos sem uso", "runs": "Execuções do coder", "awaiting_short": "aguardando aceitação",
        "th_run": "Execução", "th_mode": "Modo", "th_target": "Alvo", "th_status": "Situação", "th_date": "Data", "th_model": "Modelo",
        "tpl_fields": "Campos do template", "th_field": "Campo", "th_scope": "Escopo", "th_type": "Tipo", "th_desc": "Descrição",
    },
    "en": {
        "problems": "Problems", "all_clear": "No problems: the project compiles with no errors or warnings.",
        "error": ("error", "errors"), "warning": ("warning", "warnings"), "notfound": ("excerpt not found in the source", "excerpts not found in the source"),
        "edited": ("file edited after acceptance", "files edited after acceptance"),
        "pending": ("run awaiting acceptance", "runs awaiting acceptance"),
        "verified": "{n} of {t} excerpts checked against the source",
        "line": "line", "open_vs": "Open in VS Code", "ask": "Ask Claude", "ask_all": "Ask Claude to fix everything",
        "copied": "Request copied. Paste it in the conversation with Claude.",
        "q_found": "excerpt found in the source", "q_notfound": "excerpt not found in the source", "q_unver": "source not available to check",
        "notfound_msg": "The excerpt does not appear in source @{ref}, even after normalizing quotes, dashes and spaces. Copy it literally from the source.",
        "accepted": "accepted in run {run} · {date}", "hand_edit": "edited by hand after acceptance",
        "hand_edit_file": "edited by hand after acceptance (run {run})", "new_block": "new block, written by hand",
        "by_hand": "written by hand", "proposal": "proposed by run {run}",
        "edited_msg": "{n} block(s) differ from what was accepted in run {run}.",
        "undef": "Concept not defined in the ontology.", "undef_hint": "Ask Claude to propose a definition.",
        "uses": ("used in {n} item", "used in {n} items"), "goto_def": "see definition",
        "rel_undef": "Relation not declared in the template for this field.",
        "declared_rel": "Declared relations", "values": "Values", "guidelines": "Guidelines", "scope": "scope",
        "legend": "Hover over the words in blue, field names, concepts and relations: a short explanation appears.",
        "ask_fix": "In project {proj}, the block {blk} in {file}, line {line}, has these problems:\n{lines}\nExplain each problem in plain language and propose the fix. Do not change any file before I approve.",
        "ask_review": "In project {proj}, review the block {blk} in {file}, line {line}: check that the codes and the chain follow the template guidelines and that the excerpt supports the memo. Say what you would change, without editing the file.",
        "ask_pending": "About the proposal of run {run} (block {blk}, line {line}): explain the choice of codes and chain and say whether anything should change before I accept it. Do not accept the run for me.",
        "ask_all_text": "In project {proj}, the problems panel shows:\n{lines}\nFix them one at a time: explain the problem, propose the fix and wait for my approval before changing each file.",
        "sev": {"error": "error", "warning": "warning", "info": "info", "anchor": "excerpt", "edit": "edit"},
        "overview": "Overview", "questions": "Research questions", "t_sources": "annotated sources", "t_items": "items",
        "t_concepts": "concepts in the ontology", "t_codes": "codes applied", "t_chains": "chains", "t_quotes": "excerpts checked against the source",
        "top_concepts": "Most used concepts (number of items)", "relations_used": "Relations in chains (number of chains)",
        "unused": "Unused concepts", "runs": "Coder runs", "awaiting_short": "awaiting acceptance",
        "th_run": "Run", "th_mode": "Mode", "th_target": "Target", "th_status": "Status", "th_date": "Date", "th_model": "Model",
        "tpl_fields": "Template fields", "th_field": "Field", "th_scope": "Scope", "th_type": "Type", "th_desc": "Description",
    },
}

S["pt"].update({
    "q_found": "trecho localizado na fonte", "q_notfound": "trecho não localizado na fonte",
    "q_note": "Comparação textual com a fonte. Não valida a interpretação nem a codificação.",
    "notfound": ("trecho não localizado na fonte", "trechos não localizados na fonte"),
    "verified": "{n} de {t} trechos localizados na fonte", "t_quotes": "trechos localizados na fonte",
    "hand_edit": "alterado desde a aceitação", "hand_edit_file": "alterado desde a aceitação (execução {run})",
    "edited": ("arquivo alterado desde a aceitação", "arquivos alterados desde a aceitação"),
    "edited_msg": "{n} bloco(s) diferem do conteúdo aceito na execução {run}.",
    "relations_used": "Ocorrências de relações nas cadeias", "rel_invalid": "não declarada no template",
    "top_concepts": "Conceitos mais usados (nº de itens)",
    "sec_valid": "Validação", "sec_changes": "Alterações desde a aceitação", "sec_props": "Propostas para revisão",
    "sec_valid_hint": "Erros e avisos do compilador e trechos não localizados: pedem correção.",
    "sec_changes_hint": "Diferenças em relação ao que foi aceito: confira se foram intencionais.",
    "sec_props_hint": "Escrito pelo coder, ainda fora do projeto: aceite ou rejeite.",
    "none": "Nada a registrar.", "prop_msg": "Execução {run}: {files} proposto(s) pelo coder, ainda fora do projeto.",
    "sev": {"error": "erro", "warning": "aviso", "info": "info", "anchor": "trecho", "edit": "alteração", "prop": "proposta"},
    "see_occ": "ver ocorrências", "occ_n": ("{n} ocorrência", "{n} ocorrências"), "in_src": "em @{s}", "go_block": "ir ao bloco",
    "close": "Fechar", "matrix": "Conceitos por fonte (nº de itens)",
    "matrix_hint": "Cor mais forte = mais itens. Clique numa célula para ver as ocorrências.",
    "tech_on": "Detalhes técnicos: ligados", "tech_off": "Detalhes técnicos: desligados", "tech": "detalhes técnicos",
    "found_n": ("{n} bloco encontrado", "{n} blocos encontrados"),
    "short": {"MissingRequiredField": "Falta o campo obrigatório `{0}` neste bloco.",
              "InvalidChainRelation": "A relação `{0}` não está declarada no template para este campo.",
              "UndefinedCode": "O código `{0}` não tem definição na ontologia."},
    "short_fallback": "Problema de validação ({code}). Veja os detalhes técnicos.",
})

S["en"].update({
    "q_found": "excerpt located in the source", "q_notfound": "excerpt not located in the source",
    "q_note": "Text comparison with the source. It does not validate the interpretation or the coding.",
    "notfound": ("excerpt not located in the source", "excerpts not located in the source"),
    "verified": "{n} of {t} excerpts located in the source", "t_quotes": "excerpts located in the source",
    "hand_edit": "changed since acceptance", "hand_edit_file": "changed since acceptance (run {run})",
    "edited": ("file changed since acceptance", "files changed since acceptance"),
    "edited_msg": "{n} block(s) differ from the content accepted in run {run}.",
    "relations_used": "Relation occurrences in chains", "rel_invalid": "not declared in the template",
    "sec_valid": "Validation", "sec_changes": "Changes since acceptance", "sec_props": "Proposals to review",
    "sec_valid_hint": "Compiler errors and warnings and excerpts not located: they need a fix.",
    "sec_changes_hint": "Differences from what was accepted: check that they were intended.",
    "sec_props_hint": "Written by the coder, not yet in the project: accept or reject.",
    "none": "Nothing to report.", "prop_msg": "Run {run}: {files} proposed by the coder, not yet in the project.",
    "sev": {"error": "error", "warning": "warning", "info": "info", "anchor": "excerpt", "edit": "change", "prop": "proposal"},
    "see_occ": "see occurrences", "occ_n": ("{n} occurrence", "{n} occurrences"), "in_src": "in @{s}", "go_block": "go to block",
    "close": "Close", "matrix": "Concepts by source (number of items)",
    "matrix_hint": "Stronger color = more items. Click a cell to see the occurrences.",
    "tech_on": "Technical details: on", "tech_off": "Technical details: off", "tech": "technical details",
    "found_n": ("{n} block found", "{n} blocks found"),
    "short": {}, "short_fallback": "",
})

S["pt"].update({
    "problems": "Validação e revisão", "oc_diag": "{e} erro(s) e {w} aviso(s) neste bloco",
    "sort_by": "Ordenar por", "by_n": "nº de itens", "by_ns": "nº de fontes", "by_name": "nome",
    "group": "Grupo", "all": "todos", "no_def": "sem definição", "no_group": "(sem grupo)",
    "matrix_hint2": "Inclui todos os códigos usados nas anotações, mesmo os que ainda não têm definição na ontologia.",
})

S["en"].update({
    "problems": "Validation and review", "oc_diag": "{e} error(s) and {w} warning(s) in this block",
    "sort_by": "Sort by", "by_n": "number of items", "by_ns": "number of sources", "by_name": "name",
    "group": "Group", "all": "all", "no_def": "no definition", "no_group": "(no group)",
    "matrix_hint2": "Includes every code used in the annotations, even those not yet defined in the ontology.",
})

S["pt"].update({"no_entry": "Aparece nas anotações; não tem entrada na ontologia, e o template não a exige.", "compile_fail": "Não foi possível compilar o projeto para montar esta página ({err}). Os arquivos aparecem, mas sem validação, conceitos nem ajuda dos campos. Peça ao Claude para rodar sk.py check.", "capped": "Mostrando os {r} conceitos mais frequentes (de {rt}) e as {c} fontes com mais itens (de {ct}).", "eyebrow": "Synesis · projeto de pesquisa", "legend_n": "itens por célula", "corpus": "Corpus"})

S["en"].update({"no_entry": "Used in the annotations; it has no ontology entry, and the template does not require one.", "compile_fail": "The project could not be compiled for this page ({err}). The files are shown, but without validation, concepts or field help. Ask Claude to run sk.py check.", "capped": "Showing the {r} most frequent concepts (of {rt}) and the {c} sources with most items (of {ct}).", "eyebrow": "Synesis · research project", "legend_n": "items per cell", "corpus": "Corpus"})

S["pt"].update({
    "help": "Como ler esta página", "details": "ver detalhes", "focus": "Conceito em foco",
    "dist": "Distribuição por fonte", "see_all": ("Ver a ocorrência", "Ver as {n} ocorrências"),
    "in_k": "{n} ocorrência(s) em {k} de {s} fontes", "pick_hint": "Passe o mouse sobre uma linha; clique num conceito para fixá-lo.",
    "scroll_hint": "deslize para ver todas as fontes →", "more": "Decisão metodológica e pedido ao Claude",
})

S["en"].update({
    "help": "How to read this page", "details": "see details", "focus": "Concept in focus",
    "dist": "Distribution by source", "see_all": ("See the occurrence", "See the {n} occurrences"),
    "in_k": "{n} occurrence(s) in {k} of {s} sources", "pick_hint": "Hover over a row; click a concept to pin it.",
    "scroll_hint": "swipe to see every source →", "more": "Methodological decision and request to Claude",
})

KW = {
    "pt": {
        "FIELD": "Cria um campo: uma das informações que você vai registrar no projeto. Este se chama {f}.",
        "TYPE": "Diz que tipo de informação o campo {f} guarda. Passe o mouse sobre o tipo ao lado para ver o que ele significa.",
        "T:TEXT": "Texto livre, escrito por você, em uma ou mais frases.",
        "T:QUOTATION": "Trecho copiado palavra por palavra da fonte. É a evidência: não se resume nem se corrige.",
        "T:MEMO": "Uma anotação sua, de interpretação: por que o trecho importa para a pesquisa.",
        "T:CODE": "Os conceitos aplicados ao trecho, separados por vírgula. Cada conceito precisa ter uma definição na ontologia.",
        "T:CHAIN": "Liga conceitos por uma relação (conceito → RELAÇÃO → conceito), quando a própria fonte afirma essa ligação.",
        "T:TOPIC": "Um tema amplo, que reúne vários conceitos parecidos.",
        "T:ENUMERATED": "Uma opção escolhida numa lista fechada de valores.",
        "T:ORDERED": "Uma opção escolhida numa lista que tem ordem, como baixo, médio e alto.",
        "T:SCALE": "Um número dentro de uma faixa combinada.",
        "T:DATE": "Uma data.",
        "SCOPE": "Diz em que lugar o campo {f} é preenchido.",
        "SCOPE:SOURCE": "O campo {f} é preenchido uma vez para cada fonte (entrevista, artigo, documento) e descreve a fonte como um todo.",
        "SCOPE:ITEM": "O campo {f} pertence aos itens: é preenchido em cada trecho que você destaca de uma fonte.",
        "SCOPE:ONTOLOGY": "O campo {f} pertence à ontologia, o dicionário de conceitos do projeto: é preenchido em cada conceito.",
        "DESCRIPTION": "Diz em poucas palavras para que serve o campo {f}.",
        "DESCRIPTION@P": "Descreve o projeto em poucas palavras.",
        "GUIDELINES@G": "Orientações escritas no template sobre como preencher um campo, com exemplos certos e errados. É nelas que ficam os critérios de cada nível ou categoria.",
        "GUIDELINES": "Orientações de como preencher o campo {f}, com exemplos do que está certo e do que está errado. Quem codifica, você ou o Claude, segue estas orientações.",
        "RELATIONS": "As relações que podem ligar conceitos neste campo, cada uma com o seu sentido. Só estas podem ser usadas.",
        "VALUES": "As opções permitidas neste campo.",
        "ARITY": "Quantos conceitos a cadeia precisa ligar ({v}).",
        "REQUIRED": "Campos obrigatórios: precisam aparecer em todo bloco deste tipo.",
        "OPTIONAL": "Campos opcionais: podem ficar de fora quando não se aplicam.",
        "BUNDLE": "Campos que andam juntos, formando pares: o primeiro de um com o primeiro do outro, e assim por diante.",
        "SOURCE FIELDS": "Os campos que descrevem cada fonte como um todo.",
        "ITEM FIELDS": "Os campos de cada item, isto é, de cada trecho destacado de uma fonte.",
        "ONTOLOGY FIELDS": "Os campos de cada conceito da ontologia.",
        "SOURCE": "Abre o registro da fonte {v}. O nome depois do @ é o mesmo da bibliografia.",
        "ITEM": "Abre um item: um trecho destacado da fonte {v}, com a sua interpretação e os conceitos aplicados.",
        "ONTOLOGY": "Abre a definição do conceito {v}. Todo conceito usado nos itens precisa de uma definição assim.",
        "END": "Fecha o bloco {v} aberto acima. Tudo o que fica entre a abertura e esta linha pertence a ele.",
        "PROJECT": "Abre o arquivo do projeto: o nome e os arquivos que fazem parte dele.",
        "TEMPLATE": "O template: o arquivo que define quais campos existem e como preenchê-los.",
        "INCLUDE": "Inclui no projeto um arquivo ou uma pasta.",
        "BIBLIOGRAPHY": "As referências das fontes, como numa lista de bibliografia.",
        "ANNOTATIONS": "Onde ficam as anotações: as fontes e os itens destacados delas.",
        "INC:ONTOLOGY": "Onde ficam as definições dos conceitos (a ontologia).",
        "QUESTIONS": "As questões de pesquisa. As notas podem citá-las, por exemplo (Q1).",
        "EXPORT": "Gera uma cópia dos dados do projeto em outro formato ({v}), para analisar em outras ferramentas.",
        "OUTPUT": "Onde a cópia exportada será gravada.",
        "GENERATED_AT": "Uma data fixa gravada na cópia exportada, para que ela saia sempre igual.",
    },
    "en": {
        "FIELD": "Creates a field: one piece of information you will record in the project. This one is called {f}.",
        "TYPE": "Says what kind of information the field {f} holds. Hover over the type next to it to see what it means.",
        "T:TEXT": "Free text, written by you, in one or more sentences.",
        "T:QUOTATION": "An excerpt copied word for word from the source. It is the evidence: never summarized or corrected.",
        "T:MEMO": "Your own interpretive note: why the excerpt matters for the research.",
        "T:CODE": "The concepts applied to the excerpt, separated by commas. Each concept needs a definition in the ontology.",
        "T:CHAIN": "Links concepts through a relation (concept → RELATION → concept), when the source itself states that link.",
        "T:TOPIC": "A broad theme that groups similar concepts.",
        "T:ENUMERATED": "One option chosen from a closed list of values.",
        "T:ORDERED": "One option chosen from an ordered list, such as low, medium and high.",
        "T:SCALE": "A number within an agreed range.",
        "T:DATE": "A date.",
        "SCOPE": "Says where the field {f} is filled in.",
        "SCOPE:SOURCE": "The field {f} is filled in once for each source (interview, article, document) and describes the source as a whole.",
        "SCOPE:ITEM": "The field {f} belongs to the items: it is filled in for each excerpt you highlight in a source.",
        "SCOPE:ONTOLOGY": "The field {f} belongs to the ontology, the project's dictionary of concepts: it is filled in for each concept.",
        "DESCRIPTION": "Says in a few words what the field {f} is for.",
        "DESCRIPTION@P": "Describes the project in a few words.",
        "GUIDELINES@G": "Instructions written in the template on how to fill in a field, with right and wrong examples. This is where the criteria for each level or category live.",
        "GUIDELINES": "Instructions on how to fill in the field {f}, with examples of what is right and what is wrong. Whoever codes, you or Claude, follows them.",
        "RELATIONS": "The relations that may link concepts in this field, each with its meaning. Only these can be used.",
        "VALUES": "The options allowed in this field.",
        "ARITY": "How many concepts the chain must link ({v}).",
        "REQUIRED": "Required fields: they must appear in every block of this kind.",
        "OPTIONAL": "Optional fields: they can be left out when they do not apply.",
        "BUNDLE": "Fields that go together in pairs: the first of one with the first of the other, and so on.",
        "SOURCE FIELDS": "The fields that describe each source as a whole.",
        "ITEM FIELDS": "The fields of each item, that is, of each excerpt highlighted in a source.",
        "ONTOLOGY FIELDS": "The fields of each concept in the ontology.",
        "SOURCE": "Opens the record of source {v}. The name after @ is the same as in the bibliography.",
        "ITEM": "Opens an item: an excerpt highlighted in source {v}, with your interpretation and the concepts applied.",
        "ONTOLOGY": "Opens the definition of the concept {v}. Every concept used in the items needs a definition like this.",
        "END": "Closes the {v} block opened above. Everything between the opening and this line belongs to it.",
        "PROJECT": "Opens the project file: its name and the files that are part of it.",
        "TEMPLATE": "The template: the file that defines which fields exist and how to fill them in.",
        "INCLUDE": "Includes a file or a folder in the project.",
        "BIBLIOGRAPHY": "The references of the sources, like a bibliography list.",
        "ANNOTATIONS": "Where the annotations are: the sources and the excerpts highlighted in them.",
        "INC:ONTOLOGY": "Where the definitions of the concepts are (the ontology).",
        "QUESTIONS": "The research questions. Memos can cite them, for example (Q1).",
        "EXPORT": "Makes a copy of the project data in another format ({v}), to analyze in other tools.",
        "OUTPUT": "Where the exported copy will be saved.",
        "GENERATED_AT": "A fixed date written in the exported copy, so that it always comes out the same.",
    },
}

HELP = {
    "pt": {
        "n_tips": ("1 sugestão para começar", "{n} sugestões para começar"), "tab": "Por onde começar",
        "about": "Este é o projeto {name}: {src} fontes, {items} itens e {conc} conceitos. A página só mostra os arquivos; as mudanças são feitas nos arquivos ou pedindo ao Claude na conversa.",
        "start_err": "Comece pela validação: há {e} e o projeto não compila assim. Abra {link} e use «Pedir ao Claude» em cada problema.",
        "start_warn": "Há {w} para revisar em {link}.",
        "nf": "{n} não foi localizado na fonte: volte à fonte e copie-o literalmente.",
        "pending": "Uma proposta do coder espera a sua decisão na aba {link}. Leia os cartões e diga ao Claude se aceita ou rejeita a execução.",
        "edits": "{n} mudaram desde a aceitação. Confira se as mudanças foram intencionais.",
        "undef": ("O código {codes} ainda não tem definição na ontologia; o Claude pode propor uma.", "Os códigos {codes} ainda não têm definição na ontologia; o Claude pode propor as definições."),
        "clear": "Nada pendente: o projeto compila e todos os trechos foram localizados nas fontes.",
        "explore": "Para explorar, use a matriz {link}: clique num conceito para vê-lo em foco e numa célula para ler os trechos daquela fonte. O conceito mais frequente é «{top}» ({n} itens).",
        "learn": "As palavras em azul nos arquivos (como SCOPE e END ITEM) explicam-se ao passar o mouse. A aba {link} sugere o que mais registrar, com pedidos prontos para o Claude.",
        "review_link": "Validação e revisão", "matrix_link": "Conceitos por fonte",
        "err": ("1 erro", "{n} erros"), "warn": ("1 aviso", "{n} avisos"), "q": ("1 trecho", "{n} trechos"),
        "files": ("1 arquivo", "{n} arquivos"),
    },
    "en": {
        "n_tips": ("1 suggestion to get started", "{n} suggestions to get started"), "tab": "Where to start",
        "about": "This is project {name}: {src} sources, {items} items and {conc} concepts. The page only shows the files; changes are made in the files or by asking Claude in the conversation.",
        "start_err": "Start with validation: there are {e} and the project does not compile like this. Open {link} and use «Ask Claude» on each problem.",
        "start_warn": "There are {w} to review in {link}.",
        "nf": "{n} could not be located in the source: go back to the source and copy it literally.",
        "pending": "A coder proposal awaits your decision in the {link} tab. Read the cards and tell Claude whether to accept or reject the run.",
        "edits": "{n} changed since acceptance. Check that the changes were intended.",
        "undef": ("The code {codes} has no definition in the ontology yet; Claude can propose one.", "The codes {codes} have no definition in the ontology yet; Claude can propose them."),
        "clear": "Nothing pending: the project compiles and every excerpt was located in the sources.",
        "explore": "To explore, use the matrix {link}: click a concept to put it in focus and a cell to read the excerpts of that source. The most frequent concept is «{top}» ({n} items).",
        "learn": "The words in blue in the files (such as SCOPE and END ITEM) explain themselves on hover. The {link} tab suggests what else to record, with requests ready for Claude.",
        "review_link": "Validation and review", "matrix_link": "Concepts by source",
        "err": ("1 error", "{n} errors"), "warn": ("1 warning", "{n} warnings"), "q": ("1 excerpt", "{n} excerpts"),
        "files": ("1 file", "{n} files"),
    },
}

TAB_SHORT = {"pt": {"pending": "Aguardando aceitação", "poss": "Possibilidades"},
             "en": {"pending": "Awaiting acceptance", "poss": "Possibilities"}}

LINKS = {
    "pt": {"docs": "Documentação", "github": "GitHub", "cite": "Como citar", "support_t": "Apoie o Synesis",
           "support": ("O Synesis é software livre, criado por pesquisadores para pesquisadores. Se ele ajuda no seu trabalho, "
                       "há três formas simples de retribuir:"),
           "star": "Dê uma estrela no GitHub", "star_why": "ajuda outros pesquisadores a encontrar o Synesis e mostra que ele é usado.",
           "cite_why": "cite o Synesis nas publicações que o usaram; é o reconhecimento que conta na vida acadêmica.",
           "issue": "Conte o que não funcionou", "issue_why": "relatos de uso real orientam as próximas versões.",
           "copy_cite": "Copiar citação (ABNT)", "copy_bib": "Copiar BibTeX", "copied_cite": "Citação copiada.",
           "copied_bib": "BibTeX copiado. Pode colá-lo no seu arquivo .bib.", "made": "Feito com Synesis"},
    "en": {"docs": "Documentation", "github": "GitHub", "cite": "How to cite", "support_t": "Support Synesis",
           "support": ("Synesis is free software, made by researchers for researchers. If it helps your work, there are three "
                       "simple ways to give back:"),
           "star": "Star it on GitHub", "star_why": "it helps other researchers find Synesis and shows that it is used.",
           "cite_why": "cite Synesis in the publications that used it; that is the recognition that counts in academic life.",
           "issue": "Tell us what did not work", "issue_why": "reports from real use guide the next versions.",
           "copy_cite": "Copy citation (APA)", "copy_bib": "Copy BibTeX", "copied_cite": "Citation copied.",
           "copied_bib": "BibTeX copied. You can paste it into your .bib file.", "made": "Made with Synesis"},
}

RUN_STATUS = {"pt": {"accepted": "aceita", "stale": "desatualizada", "rejected": "rejeitada"},
              "en": {"accepted": "accepted", "stale": "stale", "rejected": "rejected"}}

DOCS_URL = "https://synesis-lang.org"

GITHUB_URL = "https://github.com/synesis-lang/synesis"


# --------------------------------------------------------------------------- languages
# The page can speak these languages. Each one has the same keys in every table below; a test checks it.
LANGS = {
    "en": {"label": "English", "html": "en", "date": "{y}-{m}-{d}",
           "names": ("en", "english", "inglês", "ingles", "inglés", "anglais", "englisch", "inglese", "英语", "英文"),
           "stop": ("the", "and", "of", "to", "is", "that", "for", "with", "are", "this", "on", "be", "as", "by", "it",
                    "from", "or", "an", "in", "not", "when", "which", "their", "its", "was", "were")},
    "pt": {"label": "Português", "html": "pt-BR", "date": "{d}/{m}/{y}",
           "names": ("pt", "portugu", "brazil", "brasil"),
           "stop": ("de", "que", "não", "nao", "para", "uma", "com", "os", "as", "do", "da", "em", "é", "se", "dos",
                    "das", "ao", "pela", "pelo", "como", "mas", "ou", "um", "na", "no", "nas", "nos", "sobre", "quando")},
    "es": {"label": "Español", "html": "es", "date": "{d}/{m}/{y}",
           "names": ("es", "spanish", "español", "espanol", "espanhol", "espagnol", "spanisch", "spagnolo", "castellano", "西班牙"),
           "stop": ("el", "la", "los", "las", "y", "que", "en", "del", "para", "con", "una", "por", "es", "se", "su",
                    "al", "lo", "como", "pero", "sus", "este", "esta", "cuando", "sobre", "también", "muy")},
    "fr": {"label": "Français", "html": "fr", "date": "{d}/{m}/{y}",
           "names": ("fr", "french", "français", "francais", "francês", "francés", "französisch", "francese", "法语", "法文"),
           "stop": ("le", "la", "les", "et", "des", "du", "un", "une", "est", "que", "qui", "pour", "dans", "sur", "pas",
                    "par", "avec", "au", "aux", "ce", "cette", "ses", "leur", "sont", "comme", "mais")},
    "de": {"label": "Deutsch", "html": "de", "date": "{d}.{m}.{y}",
           "names": ("de", "german", "deutsch", "alemão", "alemao", "alemán", "allemand", "tedesco", "德语", "德文"),
           "stop": ("der", "die", "das", "und", "ist", "nicht", "mit", "den", "von", "zu", "auf", "für", "ein", "eine",
                    "dem", "des", "sich", "auch", "wird", "werden", "wenn", "oder", "aber", "nach", "bei", "sind")},
    "it": {"label": "Italiano", "html": "it", "date": "{d}/{m}/{y}",
           "names": ("it", "italian", "italiano", "italien", "italienisch", "意大利"),
           "stop": ("il", "lo", "gli", "le", "di", "che", "per", "con", "una", "sono", "della", "delle", "degli", "nel",
                    "nella", "dei", "del", "non", "come", "anche", "quando", "questo", "questa", "alla", "più", "ma")},
    "zh": {"label": "中文", "html": "zh-Hans", "date": "{y}-{m}-{d}",
           "names": ("zh", "chinese", "mandarin", "chinês", "chines", "chino", "chinois", "chinesisch", "cinese", "中文", "汉语", "普通话"),
           "stop": ()},       # Chinese is recognized by its characters, not by words
}


def lang_of(name):
    """A tag or a language name ('pt-BR', 'Brazilian Portuguese', 'español', '中文') -> a page language, or None."""
    n = (name or "").strip().lower()
    if not n:
        return None
    if n.startswith("zh") or any(ch >= "一" and ch <= "鿿" for ch in n):
        return "zh"
    for code, meta in LANGS.items():
        if n == code or n.startswith(code + "-") or n.startswith(code + "_"):
            return code
    for code, meta in LANGS.items():
        if any(alias in n for alias in meta["names"][1:]):
            return code
    return None


STRINGS = {
    "en": {
        "title": "Project view", "files": "Files", "awaiting": "Awaiting your acceptance",
        "awaiting_hint": "Written by the coder; not part of the project until you accept the run.",
        "project": "Project", "template": "Template", "ontology": "Ontology", "annotations": "Annotations",
        "records": "Records", "references": "References", "search": "Search in all files…",
        "code_lines": "Code lines", "theme": "Light / dark", "empty": "Nothing to show yet.",
        "blocks": ("block", "blocks"), "sources": ("source", "sources"), "items": ("item", "items"),
        "concepts": ("concept", "concepts"), "fields": ("field", "fields"), "run": "run", "no_match": "No block matches the search.",
        "hint": "Read-only view of the Synesis files. Edit the files, not this page.",
        "correct": "Correct", "wrong": "Wrong",
    },
    "pt": {
        "title": "Visão do projeto", "files": "Arquivos", "awaiting": "Aguardando sua aceitação",
        "awaiting_hint": "Escrito pelo coder; só entra no projeto quando você aceitar a execução.",
        "project": "Projeto", "template": "Template", "ontology": "Ontologia", "annotations": "Anotações",
        "records": "Registros", "references": "Referências", "search": "Buscar em todos os arquivos…",
        "code_lines": "Linhas de código", "theme": "Claro / escuro", "empty": "Nada para mostrar ainda.",
        "blocks": ("bloco", "blocos"), "sources": ("fonte", "fontes"), "items": ("item", "itens"),
        "concepts": ("conceito", "conceitos"), "fields": ("campo", "campos"), "run": "execução", "no_match": "Nenhum bloco corresponde à busca.",
        "hint": "Visão somente de leitura dos arquivos Synesis. Edite os arquivos, não esta página.",
        "correct": "Correto", "wrong": "Errado",
    },
}

# The "Possibilities" tab. Placeholders: {proj} project name, {q1}/{q2} the two most frequent concepts (or a
# generic phrase), {qk} the research question keys; in here_fmt, the facts of the project.
GUIDE = {
    "en": {
        "tab": "Research possibilities", "sep": ", ", "some": "a phenomenon of the research",
        "intro": ("Start from what you want to investigate, not from the name of a field. Each possibility shows a "
                  "need, an example, the decision it asks for and the Synesis feature that carries it out. The "
                  "request can be copied and adapted in the conversation with Claude: Claude will clarify your "
                  "intention and present alternatives before proposing a structure."),
        "goal": "Goal: you can say “I want to investigate this; help me record and analyze it”, even without knowing the names of the fields.",
        "example": "Example", "decision": "Decision to make", "resource": "Synesis feature", "here": "In this project",
        "ask_label": "Request to adapt", "copy": "Copy request to adapt",
        "tail": " Do not change any file before I approve.", "more": "Methodological decision and request to Claude",
        "groups": {
            "compare": {"title": "I want to compare", "lead": "Comparing sources, excerpts or groups needs a common criterion, recorded the same way everywhere."},
            "connect": {"title": "I want to connect", "lead": "Links between concepts show mechanisms: what leads to what, what enables or prevents what."},
            "organize": {"title": "I want to understand and organize", "lead": "Well-defined concepts gather passages about the same phenomenon and make the analysis reviewable."},
            "support": {"title": "I want to support my interpretation", "lead": "An interpretation convinces when one can go back to the source and see where it came from."},
        },
        "items": {
            "scale": {"need": "I need to record intensity, degree or an assessment as a number.",
                      "ex": "How much trust a person expresses in an institution, from 1 (none) to 5 (full).",
                      "dec": ("Do you want to record the rating given by the source itself, or rate yourself the intensity described in the "
                              "excerpt? They are different pieces of information and may need separate fields. Either way, each level needs a "
                              "written criterion, so that the same situation always gets the same number."),
                      "ask": ("I want to record an intensity or a degree in the annotations of project {proj}, for example how strongly each "
                              "excerpt shows {q1}. Before proposing anything, ask me up to three questions to understand my intention, "
                              "including whether the number comes from the source or from me. Then present alternatives and propose the levels "
                              "of the scale, a criterion for each level and an example from the project.")},
            "enum": {"need": "I need to sort sources or excerpts into fixed categories, to compare groups.",
                     "ex": "Kind of participant (leader, volunteer, neighbor) or stage of the group (start, consolidation, decline).",
                     "dec": ("Do the categories have an order (low, medium, high) or are they just different? With an order, use ORDERED; "
                             "without, ENUMERATED. And does the category describe the whole source or each excerpt?"),
                     "ask": ("I want to compare groups of sources or excerpts in project {proj}. First ask me which groups I want to compare "
                             "and whether the categories have an order. Then present alternatives and propose a field with the categories, the "
                             "definition of each and the level where it is filled in (the whole source or each excerpt).")},
            "chain": {"need": "I need to represent how the sources connect concepts or other information.",
                      "ex": "infrastructure → ENABLES → change of habit",
                      "dec": ("The chain records the connection; the relations (RELATIONS) define the meaning of each allowed connection. Use "
                              "the chain when the source supports the link. If the connection is your own hypothesis, agree with Claude on a way "
                              "to record it as interpretation, for example in the memo."),
                      "ask": ("I want to represent how the sources of project {proj} connect concepts, for example {q1} and {q2}. First "
                              "ask me which kind of connection interests me and how to tell a connection stated by the source from one that is "
                              "my interpretation. Then present alternatives and propose the field, the relations and guidelines with right and "
                              "wrong examples.")},
            "rel": {"need": "I need to tell apart the different ways things relate.",
                    "ex": "CAUSE (one factor produces another), CONDITION (one factor makes another possible), RESTRICTION (one factor hinders another).",
                    "dec": ("A few well-defined relations compare better than many similar ones. Each relation needs a definition, an "
                            "example and a situation where it does not apply."),
                    "ask": ("Help me review the relations of project {proj}. First ask me which distinctions matter for my research "
                            "questions. Then propose, for each relation, a definition, an example and a situation where it should not be used.")},
            "code": {"need": "I need to gather passages about the same phenomenon.",
                     "ex": "Every excerpt that talks about dropping out gets the same concept, whose definition says when to apply it.",
                     "dec": ("Reuse an existing concept or create a new one? A new concept needs a definition, with a criterion for when to "
                             "apply it and when not to."),
                     "ask": ("Help me propose concepts for the excerpts of project {proj}, telling apart those already in the ontology from "
                             "those that need a new definition. For each new concept, propose the definition, when to apply it and when not to.")},
            "topic": {"need": "I need to group concepts into broader themes.",
                      "ex": "Lack of water, insecure land and lack of funds gathered under the theme «obstacles».",
                      "dec": "A theme gathers concepts but does not replace the definition of each one. Prefer a few themes that help read the whole.",
                      "ask": ("Help me review how the concepts of project {proj} are grouped into themes. First ask me what overall reading I "
                              "want to make. Then propose the themes, the concepts in each and those left out.")},
            "quote": {"need": "I need to keep the words of the source and develop my interpretation.",
                      "ex": "The excerpt copied word for word and, next to it, a memo saying why it matters.",
                      "dec": ("The excerpt is the evidence; the memo is your reading. Mixing them weakens the analysis. An excerpt not located "
                              "in the source has to go back to it."),
                      "ask": ("I want to keep evidence and interpretation apart in the annotations of project {proj}. Check that the excerpts "
                              "are literal copies of the source and that the memos bring interpretation, not paraphrase. Show the cases to fix.")},
            "q": {"need": "I need to link each annotation to my research questions.",
                  "ex": "The memo ends with (Q1) when the excerpt helps answer the first question.",
                  "dec": "Citing the question in the memo shows what each excerpt is for and reveals questions with little evidence.",
                  "ask": ("I want to see how much evidence project {proj} gathers for each research question ({qk}). Count the memos that "
                          "cite each question and point out the questions with little evidence.")},
        },
        "here_fmt": {
            "scale_yes": "This project already has a scale: {names}.",
            "scale_no": "This project has no scale yet. A possibility to consider: grading how strongly each excerpt shows {q1}.",
            "scale_no2": "This project has no scale yet. A possibility to consider: grading how strongly each excerpt shows {q1} or {q2}.",
            "enum_yes": "This project already has: {names}.",
            "enum_no": ("The sources in this project are described by {names}, in free text. To compare sources by category, such as "
                        "the kind of source, a closed-list field at the source level would help."),
            "enum_nosrc": "To compare sources by category, such as the kind of source, a closed-list field at the source level would help.",
            "chain_yes": "This project already has the field {names}, with {n} chains recorded. For example:",
            "chain_no": "This project does not record connections between concepts yet.",
            "rel_yes": "Declared relations and how often they were used: {decl}.",
            "rel_none": "This project declares no relations yet.",
            "rel_undeclared": " The relation {rels} was used without being declared: decide whether it is new or fits one of the existing ones.",
            "code": "{n} concepts defined in the ontology; {single} appear in a single source.",
            "code_undef": " Used without a definition: {names}.",
            "topic_yes": "The concepts are grouped in {n} themes: {groups}.",
            "topic_no": "The concepts are not grouped in themes yet.",
            "quote": "{found} of {total} excerpts were located in the source.",
            "quote_nf": " {n} need(s) to go back to the source to be checked.",
            "q_yes": "{cite} of {memos} memos cite a question ({keys}).",
            "q_no": "The project has no research questions declared yet.",
        },
    },
    "pt": {
        "tab": "Possibilidades de pesquisa", "sep": ", ", "some": "um fenômeno da pesquisa",
        "intro": ("Comece pelo que você quer investigar, não pelo nome do campo. Cada possibilidade traz uma "
                  "necessidade, um exemplo, a decisão que ela pede e o recurso do Synesis que a realiza. O pedido "
                  "pode ser copiado e adaptado na conversa com o Claude: ele vai esclarecer a sua intenção e "
                  "apresentar alternativas antes de propor uma estrutura."),
        "goal": "Objetivo: você consegue dizer «quero investigar isto; ajude-me a registrar e analisar essa informação», mesmo sem conhecer os nomes dos campos.",
        "example": "Exemplo", "decision": "Decisão a tomar", "resource": "Recurso no Synesis", "here": "Neste projeto",
        "ask_label": "Pedido para adaptar", "copy": "Copiar pedido para adaptar",
        "tail": " Não altere nenhum arquivo antes da minha aprovação.", "more": "Decisão metodológica e pedido ao Claude",
        "groups": {
            "compare": {"title": "Quero comparar", "lead": "Comparar fontes, trechos ou grupos exige um critério comum, registrado do mesmo jeito em todo lugar."},
            "connect": {"title": "Quero conectar", "lead": "Ligações entre conceitos mostram mecanismos: o que leva a quê, o que permite ou impede o quê."},
            "organize": {"title": "Quero compreender e organizar", "lead": "Conceitos bem definidos reúnem passagens sobre o mesmo fenômeno e permitem revisar a análise."},
            "support": {"title": "Quero sustentar minha interpretação", "lead": "Uma interpretação convence quando se pode voltar à fonte e ver de onde ela saiu."},
        },
        "items": {
            "scale": {"need": "Preciso registrar intensidade, grau ou avaliação com números.",
                      "ex": "O grau de confiança que uma pessoa expressa numa instituição, de 1 (nenhuma) a 5 (total).",
                      "dec": ("Você quer registrar a nota dada pela própria fonte ou classificar você mesmo a intensidade descrita no trecho? "
                              "São informações diferentes e podem pedir campos separados. Em qualquer caso, cada nível precisa de um "
                              "critério escrito, para que a mesma situação receba sempre o mesmo número."),
                      "ask": ("Quero registrar uma intensidade ou um grau nas anotações do projeto {proj}, por exemplo o quanto cada trecho "
                              "mostra {q1}. Antes de propor algo, faça-me até três perguntas para entender a minha intenção, inclusive "
                              "se o número é dado pela fonte ou atribuído por mim. Depois apresente alternativas e proponha os níveis da "
                              "escala, um critério para cada nível e um exemplo tirado do projeto.")},
            "enum": {"need": "Preciso classificar fontes ou trechos em categorias fixas, para comparar grupos.",
                     "ex": "Tipo de participante (liderança, voluntário, vizinho) ou fase do grupo (início, consolidação, declínio).",
                     "dec": ("As categorias têm uma ordem (baixo, médio, alto) ou são apenas diferentes entre si? Com ordem, use ORDERED; "
                             "sem ordem, ENUMERATED. E a categoria descreve a fonte inteira ou cada trecho?"),
                     "ask": ("Quero comparar grupos de fontes ou de trechos no projeto {proj}. Pergunte-me primeiro que grupos quero comparar "
                             "e se as categorias têm ordem. Depois apresente alternativas e proponha um campo com as categorias, a definição "
                             "de cada uma e o nível em que ele é preenchido (a fonte inteira ou cada trecho).")},
            "chain": {"need": "Preciso representar como as fontes conectam conceitos ou outras informações.",
                      "ex": "infraestrutura → HABILITA → mudança de hábito",
                      "dec": ("A cadeia registra a conexão; as relações (RELATIONS) definem o significado de cada conexão permitida. Use a "
                              "cadeia quando a fonte sustenta a ligação. Se a conexão é uma hipótese sua, combine com o Claude uma forma de "
                              "registrá-la como interpretação, por exemplo na nota."),
                      "ask": ("Quero representar como as fontes do projeto {proj} conectam conceitos, por exemplo {q1} e {q2}. "
                              "Pergunte-me primeiro que tipo de conexão me interessa e como distinguir a conexão afirmada pela fonte da que é "
                              "interpretação minha. Depois apresente alternativas e proponha o campo, as relações e orientações com exemplos "
                              "certos e errados.")},
            "rel": {"need": "Preciso distinguir maneiras diferentes como as coisas se relacionam.",
                    "ex": "CAUSA (um fator produz outro), CONDIÇÃO (um fator torna outro possível), RESTRIÇÃO (um fator dificulta outro).",
                    "dec": ("Poucas relações bem definidas comparam melhor do que muitas parecidas. Cada relação precisa de uma definição, "
                            "de um exemplo e de uma situação em que não se aplica."),
                    "ask": ("Ajude-me a revisar as relações do projeto {proj}. Pergunte-me primeiro que distinções importam para as minhas "
                            "questões de pesquisa. Depois proponha, para cada relação, uma definição, um exemplo e uma situação em que ela "
                            "não deve ser usada.")},
            "code": {"need": "Preciso reunir passagens sobre um mesmo fenômeno.",
                     "ex": "Todos os trechos que falam de abandono recebem o mesmo conceito, que tem uma definição dizendo quando aplicá-lo.",
                     "dec": ("Reutilizar um conceito existente ou criar um novo? Um conceito novo precisa de definição, com critério de "
                             "quando aplicar e de quando não aplicar."),
                     "ask": ("Ajude-me a propor conceitos para os trechos do projeto {proj}, distinguindo os que já existem na ontologia dos "
                             "que precisam de uma definição nova. Para cada conceito novo, proponha a definição, quando aplicar e quando não "
                             "aplicar.")},
            "topic": {"need": "Preciso agrupar conceitos em temas mais amplos.",
                      "ex": "Falta de água, insegurança do terreno e falta de verba reunidos no tema «obstáculos».",
                      "dec": "O tema reúne conceitos, mas não substitui a definição de cada um. Prefira poucos temas, que ajudem a ler o conjunto.",
                      "ask": ("Ajude-me a revisar como os conceitos do projeto {proj} estão reunidos em temas. Pergunte-me primeiro que leitura "
                              "de conjunto eu quero fazer. Depois proponha os temas, os conceitos de cada um e os que ficam de fora.")},
            "quote": {"need": "Preciso preservar a fala da fonte e desenvolver a minha interpretação.",
                      "ex": "O trecho copiado palavra por palavra e, ao lado, uma nota que diz por que ele importa.",
                      "dec": ("O trecho é a evidência; a nota é a sua leitura. Misturar os dois enfraquece a análise. Um trecho que não se "
                              "localiza na fonte precisa voltar a ela."),
                      "ask": ("Quero separar evidência e interpretação nas anotações do projeto {proj}. Revise se os trechos são cópias "
                              "literais da fonte e se as notas trazem interpretação, e não paráfrase. Mostre os casos a corrigir.")},
            "q": {"need": "Preciso ligar cada anotação às minhas questões de pesquisa.",
                  "ex": "A nota termina com (Q1) quando o trecho ajuda a responder a primeira questão.",
                  "dec": "Citar a questão na nota mostra para que serve cada trecho e revela questões com pouca evidência.",
                  "ask": ("Quero ver quanta evidência o projeto {proj} reúne para cada questão de pesquisa ({qk}). Conte as notas que "
                          "citam cada questão e aponte as questões com pouca evidência.")},
        },
        "here_fmt": {
            "scale_yes": "Este projeto já tem escala: {names}.",
            "scale_no": "Este projeto ainda não tem escala. Uma possibilidade a avaliar: graduar o quanto cada trecho mostra {q1}.",
            "scale_no2": "Este projeto ainda não tem escala. Uma possibilidade a avaliar: graduar o quanto cada trecho mostra {q1} ou {q2}.",
            "enum_yes": "Este projeto já tem: {names}.",
            "enum_no": ("As fontes deste projeto são descritas por {names}, em texto livre. Para comparar fontes por categoria, como o "
                        "tipo de fonte, um campo de lista fechada no nível da fonte ajudaria."),
            "enum_nosrc": "Para comparar fontes por categoria, como o tipo de fonte, um campo de lista fechada no nível da fonte ajudaria.",
            "chain_yes": "Este projeto já tem o campo {names}, com {n} cadeias registradas. Por exemplo:",
            "chain_no": "Este projeto ainda não registra conexões entre conceitos.",
            "rel_yes": "Relações declaradas e quantas vezes foram usadas: {decl}.",
            "rel_none": "Este projeto ainda não declara relações.",
            "rel_undeclared": " A relação {rels} foi usada sem estar declarada: vale decidir se ela é nova ou se cabe numa das existentes.",
            "code": "{n} conceitos definidos na ontologia; {single} aparecem em uma única fonte.",
            "code_undef": " Usados sem definição: {names}.",
            "topic_yes": "Os conceitos estão reunidos em {n} temas: {groups}.",
            "topic_no": "Os conceitos ainda não estão reunidos em temas.",
            "quote": "{found} de {total} trechos foram localizados na fonte.",
            "quote_nf": " {n} precisa(m) voltar à fonte para conferência.",
            "q_yes": "{cite} de {memos} notas citam uma questão ({keys}).",
            "q_no": "O projeto ainda não tem questões de pesquisa declaradas.",
        },
    },
}

def add_language(code, strings, s, kw, help_, links, tab_short, run_status, guide):
    """Register one more page language. Every table gets the same keys as English (checked by a test)."""
    STRINGS[code], S[code], KW[code], HELP[code], LINKS[code] = strings, s, kw, help_, links
    TAB_SHORT[code], RUN_STATUS[code], GUIDE[code] = tab_short, run_status, guide


# --------------------------------------------------------------------------- Español
add_language(
    "es",
    strings={
        "title": "Vista del proyecto", "files": "Archivos", "awaiting": "Pendiente de tu aceptación",
        "awaiting_hint": "Escrito por el coder; no forma parte del proyecto hasta que aceptes la ejecución.",
        "project": "Proyecto", "template": "Template", "ontology": "Ontología", "annotations": "Anotaciones",
        "records": "Registros", "references": "Referencias", "search": "Buscar en todos los archivos…",
        "code_lines": "Líneas de código", "theme": "Claro / oscuro", "empty": "Todavía no hay nada que mostrar.",
        "blocks": ("bloque", "bloques"), "sources": ("fuente", "fuentes"), "items": ("ítem", "ítems"),
        "concepts": ("concepto", "conceptos"), "fields": ("campo", "campos"), "run": "ejecución",
        "no_match": "Ningún bloque coincide con la búsqueda.",
        "hint": "Vista de solo lectura de los archivos Synesis. Edita los archivos, no esta página.",
        "correct": "Correcto", "wrong": "Incorrecto",
    },
    s={
        "problems": "Validación y revisión", "all_clear": "Sin problemas: el proyecto compila sin errores ni avisos.",
        "error": ("error", "errores"), "warning": ("aviso", "avisos"),
        "notfound": ("fragmento no localizado en la fuente", "fragmentos no localizados en la fuente"),
        "edited": ("archivo modificado desde la aceptación", "archivos modificados desde la aceptación"),
        "pending": ("ejecución pendiente de aceptación", "ejecuciones pendientes de aceptación"),
        "verified": "{n} de {t} fragmentos localizados en la fuente",
        "line": "línea", "open_vs": "Abrir en VS Code", "ask": "Pedir a Claude", "ask_all": "Pedir a Claude que lo resuelva todo",
        "copied": "Solicitud copiada. Pégala en la conversación con Claude.",
        "q_found": "fragmento localizado en la fuente", "q_notfound": "fragmento no localizado en la fuente",
        "q_unver": "fuente no disponible para comprobar",
        "notfound_msg": ("El fragmento no aparece en la fuente @{ref}, ni siquiera tras normalizar comillas, guiones y espacios. "
                         "Cópialo literalmente de la fuente."),
        "accepted": "aceptado en la ejecución {run} · {date}", "hand_edit": "modificado desde la aceptación",
        "hand_edit_file": "modificado desde la aceptación (ejecución {run})", "new_block": "bloque nuevo, escrito a mano",
        "by_hand": "escrito a mano", "proposal": "propuesto por la ejecución {run}",
        "edited_msg": "{n} bloque(s) difieren del contenido aceptado en la ejecución {run}.",
        "undef": "Concepto sin definición en la ontología.", "undef_hint": "Pide a Claude que proponga una definición.",
        "uses": ("usado en {n} ítem", "usado en {n} ítems"), "goto_def": "ver definición",
        "rel_undef": "Relación no declarada en el template para este campo.", "declared_rel": "Relaciones declaradas",
        "values": "Valores", "guidelines": "Orientaciones", "scope": "ámbito",
        "legend": "Pasa el ratón sobre las palabras en azul, los nombres de campo, los conceptos y las relaciones: aparece una explicación breve.",
        "ask_fix": ("En el proyecto {proj}, el bloque {blk} de {file}, línea {line}, tiene estos problemas:\n{lines}\n"
                    "Explica cada problema en lenguaje sencillo y propón la corrección. No modifiques ningún archivo antes de que yo lo apruebe."),
        "ask_review": ("En el proyecto {proj}, revisa el bloque {blk} de {file}, línea {line}: comprueba que los códigos y la cadena siguen "
                       "las orientaciones del template y que el fragmento sostiene la nota. Di qué cambiarías, sin modificar el archivo."),
        "ask_pending": ("Sobre la propuesta de la ejecución {run} (bloque {blk}, línea {line}): explica la elección de códigos y de cadena "
                        "y di si algo debería cambiar antes de que la acepte. No aceptes la ejecución por mí."),
        "ask_all_text": ("En el proyecto {proj}, el panel de problemas muestra:\n{lines}\nResuélvelos uno a uno: explica el problema, "
                         "propón la corrección y espera mi aprobación antes de modificar cada archivo."),
        "sev": {"error": "error", "warning": "aviso", "info": "info", "anchor": "fragmento", "edit": "cambio", "prop": "propuesta"},
        "overview": "Panel", "questions": "Preguntas de investigación", "t_sources": "fuentes anotadas", "t_items": "ítems",
        "t_concepts": "conceptos en la ontología", "t_codes": "códigos aplicados", "t_chains": "cadenas",
        "t_quotes": "fragmentos localizados en la fuente", "top_concepts": "Conceptos más usados (n.º de ítems)",
        "relations_used": "Apariciones de relaciones en las cadenas", "unused": "Conceptos sin uso", "runs": "Ejecuciones del coder",
        "awaiting_short": "pendiente de aceptación", "th_run": "Ejecución", "th_mode": "Modo", "th_target": "Objetivo",
        "th_status": "Estado", "th_date": "Fecha", "th_model": "Modelo", "tpl_fields": "Campos del template", "th_field": "Campo",
        "th_scope": "Ámbito", "th_type": "Tipo", "th_desc": "Descripción",
        "q_note": "Comparación textual con la fuente. No valida la interpretación ni la codificación.",
        "rel_invalid": "no declarada en el template", "sec_valid": "Validación", "sec_changes": "Cambios desde la aceptación",
        "sec_props": "Propuestas para revisar",
        "sec_valid_hint": "Errores y avisos del compilador y fragmentos no localizados: requieren corrección.",
        "sec_changes_hint": "Diferencias respecto a lo aceptado: comprueba que fueron intencionadas.",
        "sec_props_hint": "Escrito por el coder, todavía fuera del proyecto: acéptalo o recházalo.",
        "none": "Nada que señalar.", "prop_msg": "Ejecución {run}: {files} propuesto(s) por el coder, todavía fuera del proyecto.",
        "see_occ": "ver apariciones", "occ_n": ("{n} aparición", "{n} apariciones"), "in_src": "en @{s}", "go_block": "ir al bloque",
        "close": "Cerrar", "matrix": "Conceptos por fuente (n.º de ítems)",
        "matrix_hint": "Color más intenso = más ítems. Haz clic en una celda para ver las apariciones.",
        "tech_on": "Detalles técnicos: activados", "tech_off": "Detalles técnicos: desactivados", "tech": "detalles técnicos",
        "found_n": ("{n} bloque encontrado", "{n} bloques encontrados"),
        "short": {"MissingRequiredField": "Falta el campo obligatorio `{0}` en este bloque.",
                  "InvalidChainRelation": "La relación `{0}` no está declarada en el template para este campo.",
                  "UndefinedCode": "El código `{0}` no tiene definición en la ontología."},
        "short_fallback": "Problema de validación ({code}). Consulta los detalles técnicos.",
        "oc_diag": "{e} error(es) y {w} aviso(s) en este bloque", "sort_by": "Ordenar por", "by_n": "n.º de ítems",
        "by_ns": "n.º de fuentes", "by_name": "nombre", "group": "Grupo", "all": "todos", "no_def": "sin definición",
        "no_group": "(sin grupo)",
        "matrix_hint2": "Incluye todos los códigos usados en las anotaciones, incluso los que aún no tienen definición en la ontología.",
        "no_entry": "Aparece en las anotaciones; no tiene entrada en la ontología, y el template no la exige.",
        "compile_fail": ("No se pudo compilar el proyecto para esta página ({err}). Los archivos se muestran, pero sin validación, "
                         "conceptos ni ayuda de los campos. Pide a Claude que ejecute sk.py check."),
        "capped": "Se muestran los {r} conceptos más frecuentes (de {rt}) y las {c} fuentes con más ítems (de {ct}).",
        "eyebrow": "Synesis · proyecto de investigación", "legend_n": "ítems por celda", "corpus": "Corpus",
        "help": "Cómo leer esta página", "details": "ver detalles", "focus": "Concepto en foco", "dist": "Distribución por fuente",
        "see_all": ("Ver la aparición", "Ver las {n} apariciones"), "in_k": "{n} aparición(es) en {k} de {s} fuentes",
        "pick_hint": "Pasa el ratón sobre una fila; haz clic en un concepto para fijarlo.",
        "scroll_hint": "desliza para ver todas las fuentes →", "more": "Decisión metodológica y solicitud a Claude",
    },
    kw={
        "FIELD": "Crea un campo: una de las informaciones que registrarás en el proyecto. Este se llama {f}.",
        "TYPE": "Indica qué tipo de información guarda el campo {f}. Pasa el ratón sobre el tipo, al lado, para ver qué significa.",
        "T:TEXT": "Texto libre, escrito por ti, en una o varias frases.",
        "T:QUOTATION": "Fragmento copiado palabra por palabra de la fuente. Es la evidencia: no se resume ni se corrige.",
        "T:MEMO": "Una nota tuya, de interpretación: por qué el fragmento importa para la investigación.",
        "T:CODE": "Los conceptos aplicados al fragmento, separados por comas. Cada concepto necesita una definición en la ontología.",
        "T:CHAIN": "Une conceptos mediante una relación (concepto → RELACIÓN → concepto), cuando la propia fuente afirma ese vínculo.",
        "T:TOPIC": "Un tema amplio, que reúne varios conceptos parecidos.",
        "T:ENUMERATED": "Una opción elegida de una lista cerrada de valores.",
        "T:ORDERED": "Una opción elegida de una lista con orden, como bajo, medio y alto.",
        "T:SCALE": "Un número dentro de un rango acordado.",
        "T:DATE": "Una fecha.",
        "SCOPE": "Indica dónde se rellena el campo {f}.",
        "SCOPE:SOURCE": "El campo {f} se rellena una vez por fuente (entrevista, artículo, documento) y describe la fuente en su conjunto.",
        "SCOPE:ITEM": "El campo {f} pertenece a los ítems: se rellena en cada fragmento que destacas de una fuente.",
        "SCOPE:ONTOLOGY": "El campo {f} pertenece a la ontología, el diccionario de conceptos del proyecto: se rellena en cada concepto.",
        "GUIDELINES@G": ("Orientaciones escritas en el template sobre cómo rellenar un campo, con ejemplos correctos e incorrectos. "
                         "Ahí van los criterios de cada nivel o categoría."),
        "DESCRIPTION": "Dice en pocas palabras para qué sirve el campo {f}.",
        "DESCRIPTION@P": "Describe el proyecto en pocas palabras.",
        "GUIDELINES": ("Orientaciones para rellenar el campo {f}, con ejemplos de lo que está bien y lo que está mal. "
                       "Quien codifica, tú o Claude, sigue estas orientaciones."),
        "RELATIONS": "Las relaciones que pueden unir conceptos en este campo, cada una con su significado. Solo se pueden usar estas.",
        "VALUES": "Las opciones permitidas en este campo.",
        "ARITY": "Cuántos conceptos debe unir la cadena ({v}).",
        "REQUIRED": "Campos obligatorios: deben aparecer en todo bloque de este tipo.",
        "OPTIONAL": "Campos opcionales: pueden omitirse cuando no se aplican.",
        "BUNDLE": "Campos que van juntos, formando pares: el primero de uno con el primero del otro, y así sucesivamente.",
        "SOURCE FIELDS": "Los campos que describen cada fuente en su conjunto.",
        "ITEM FIELDS": "Los campos de cada ítem, es decir, de cada fragmento destacado de una fuente.",
        "ONTOLOGY FIELDS": "Los campos de cada concepto de la ontología.",
        "SOURCE": "Abre el registro de la fuente {v}. El nombre tras la @ es el mismo de la bibliografía.",
        "ITEM": "Abre un ítem: un fragmento destacado de la fuente {v}, con tu interpretación y los conceptos aplicados.",
        "ONTOLOGY": "Abre la definición del concepto {v}. Todo concepto usado en los ítems necesita una definición así.",
        "END": "Cierra el bloque {v} abierto más arriba. Todo lo que queda entre la apertura y esta línea le pertenece.",
        "PROJECT": "Abre el archivo del proyecto: su nombre y los archivos que forman parte de él.",
        "TEMPLATE": "El template: el archivo que define qué campos existen y cómo rellenarlos.",
        "INCLUDE": "Incluye en el proyecto un archivo o una carpeta.",
        "BIBLIOGRAPHY": "Las referencias de las fuentes, como en una lista bibliográfica.",
        "ANNOTATIONS": "Dónde están las anotaciones: las fuentes y los fragmentos destacados de ellas.",
        "INC:ONTOLOGY": "Dónde están las definiciones de los conceptos (la ontología).",
        "QUESTIONS": "Las preguntas de investigación. Las notas pueden citarlas, por ejemplo (Q1).",
        "EXPORT": "Genera una copia de los datos del proyecto en otro formato ({v}), para analizarla con otras herramientas.",
        "OUTPUT": "Dónde se guardará la copia exportada.",
        "GENERATED_AT": "Una fecha fija escrita en la copia exportada, para que salga siempre igual.",
    },
    help_={
        "n_tips": ("1 sugerencia para empezar", "{n} sugerencias para empezar"), "tab": "Por dónde empezar",
        "about": ("Este es el proyecto {name}: {src} fuentes, {items} ítems y {conc} conceptos. La página solo muestra los archivos; "
                  "los cambios se hacen en los archivos o pidiéndoselos a Claude en la conversación."),
        "start_err": ("Empieza por la validación: hay {e} y el proyecto no compila así. Abre {link} y usa «Pedir a Claude» en cada problema."),
        "start_warn": "Hay {w} que revisar en {link}.",
        "nf": "{n} no se localizó en la fuente: vuelve a la fuente y cópialo literalmente.",
        "pending": "Una propuesta del coder espera tu decisión en la pestaña {link}. Lee las tarjetas y dile a Claude si aceptas o rechazas la ejecución.",
        "edits": "{n} cambiaron desde la aceptación. Comprueba que los cambios fueron intencionados.",
        "undef": ("El código {codes} todavía no tiene definición en la ontología; Claude puede proponer una.",
                  "Los códigos {codes} todavía no tienen definición en la ontología; Claude puede proponerlas."),
        "clear": "Nada pendiente: el proyecto compila y todos los fragmentos se localizaron en las fuentes.",
        "explore": ("Para explorar, usa la matriz {link}: haz clic en un concepto para verlo en foco y en una celda para leer los fragmentos "
                    "de esa fuente. El concepto más frecuente es «{top}» ({n} ítems)."),
        "learn": ("Las palabras en azul de los archivos (como SCOPE y END ITEM) se explican al pasar el ratón. La pestaña {link} sugiere "
                  "qué más registrar, con solicitudes listas para Claude."),
        "review_link": "Validación y revisión", "matrix_link": "Conceptos por fuente",
        "err": ("1 error", "{n} errores"), "warn": ("1 aviso", "{n} avisos"), "q": ("1 fragmento", "{n} fragmentos"),
        "files": ("1 archivo", "{n} archivos"),
    },
    links={
        "docs": "Documentación", "github": "GitHub", "cite": "Cómo citar", "support_t": "Apoya a Synesis",
        "support": ("Synesis es software libre, hecho por investigadores para investigadores. Si te ayuda en tu trabajo, hay tres "
                    "formas sencillas de corresponder:"),
        "star": "Dale una estrella en GitHub", "star_why": "ayuda a otros investigadores a encontrar Synesis y muestra que se usa.",
        "cite_why": "cita Synesis en las publicaciones que lo usaron; es el reconocimiento que cuenta en la vida académica.",
        "issue": "Cuéntanos qué no funcionó", "issue_why": "los relatos de uso real orientan las próximas versiones.",
        "copy_cite": "Copiar cita (APA)", "copy_bib": "Copiar BibTeX", "copied_cite": "Cita copiada.",
        "copied_bib": "BibTeX copiado. Puedes pegarlo en tu archivo .bib.", "made": "Hecho con Synesis",
    },
    tab_short={"pending": "Pendiente de aceptación", "poss": "Posibilidades"},
    run_status={"accepted": "aceptada", "stale": "desactualizada", "rejected": "rechazada"},
    guide={
        "tab": "Posibilidades de investigación", "sep": ", ", "some": "un fenómeno de la investigación",
        "intro": ("Empieza por lo que quieres investigar, no por el nombre del campo. Cada posibilidad muestra una necesidad, un "
                  "ejemplo, la decisión que requiere y el recurso de Synesis que la lleva a cabo. La solicitud puede copiarse y "
                  "adaptarse en la conversación con Claude: aclarará tu intención y presentará alternativas antes de proponer una estructura."),
        "goal": "Objetivo: que puedas decir «quiero investigar esto; ayúdame a registrarlo y analizarlo», aunque no conozcas los nombres de los campos.",
        "example": "Ejemplo", "decision": "Decisión que tomar", "resource": "Recurso de Synesis", "here": "En este proyecto",
        "ask_label": "Solicitud para adaptar", "copy": "Copiar solicitud para adaptar",
        "tail": " No modifiques ningún archivo antes de que yo lo apruebe.", "more": "Decisión metodológica y solicitud a Claude",
        "groups": {
            "compare": {"title": "Quiero comparar", "lead": "Comparar fuentes, fragmentos o grupos exige un criterio común, registrado de la misma manera en todas partes."},
            "connect": {"title": "Quiero conectar", "lead": "Los vínculos entre conceptos muestran mecanismos: qué lleva a qué, qué permite o impide qué."},
            "organize": {"title": "Quiero comprender y organizar", "lead": "Los conceptos bien definidos reúnen pasajes sobre un mismo fenómeno y permiten revisar el análisis."},
            "support": {"title": "Quiero sustentar mi interpretación", "lead": "Una interpretación convence cuando se puede volver a la fuente y ver de dónde salió."},
        },
        "items": {
            "scale": {"need": "Necesito registrar intensidad, grado o una valoración con números.",
                      "ex": "El grado de confianza que una persona expresa en una institución, de 1 (ninguna) a 5 (total).",
                      "dec": ("¿Quieres registrar la nota que da la propia fuente o valorar tú la intensidad descrita en el fragmento? Son "
                              "informaciones distintas y pueden requerir campos separados. En cualquier caso, cada nivel necesita un criterio "
                              "escrito, para que la misma situación reciba siempre el mismo número."),
                      "ask": ("Quiero registrar una intensidad o un grado en las anotaciones del proyecto {proj}, por ejemplo cuánto muestra "
                              "cada fragmento {q1}. Antes de proponer nada, hazme hasta tres preguntas para entender mi intención, incluida "
                              "si el número lo da la fuente o lo asigno yo. Después presenta alternativas y propón los niveles de la escala, "
                              "un criterio para cada nivel y un ejemplo del proyecto.")},
            "enum": {"need": "Necesito clasificar fuentes o fragmentos en categorías fijas, para comparar grupos.",
                     "ex": "Tipo de participante (liderazgo, voluntario, vecino) o etapa del grupo (inicio, consolidación, declive).",
                     "dec": ("¿Las categorías tienen un orden (bajo, medio, alto) o solo son diferentes entre sí? Con orden, usa ORDERED; "
                             "sin orden, ENUMERATED. ¿Y la categoría describe la fuente entera o cada fragmento?"),
                     "ask": ("Quiero comparar grupos de fuentes o de fragmentos en el proyecto {proj}. Pregúntame primero qué grupos quiero "
                             "comparar y si las categorías tienen orden. Después presenta alternativas y propón un campo con las categorías, "
                             "la definición de cada una y el nivel en que se rellena (la fuente entera o cada fragmento).")},
            "chain": {"need": "Necesito representar cómo las fuentes conectan conceptos u otras informaciones.",
                      "ex": "infraestructura → HABILITA → cambio de hábito",
                      "dec": ("La cadena registra la conexión; las relaciones (RELATIONS) definen el significado de cada conexión permitida. "
                              "Usa la cadena cuando la fuente sostiene el vínculo. Si la conexión es una hipótesis tuya, acuerda con Claude "
                              "una forma de registrarla como interpretación, por ejemplo en la nota."),
                      "ask": ("Quiero representar cómo las fuentes del proyecto {proj} conectan conceptos, por ejemplo {q1} y {q2}. "
                              "Pregúntame primero qué tipo de conexión me interesa y cómo distinguir la conexión afirmada por la fuente de la "
                              "que es interpretación mía. Después presenta alternativas y propón el campo, las relaciones y orientaciones con "
                              "ejemplos correctos e incorrectos.")},
            "rel": {"need": "Necesito distinguir las distintas maneras en que las cosas se relacionan.",
                    "ex": "CAUSA (un factor produce otro), CONDICIÓN (un factor hace posible otro), RESTRICCIÓN (un factor dificulta otro).",
                    "dec": ("Pocas relaciones bien definidas comparan mejor que muchas parecidas. Cada relación necesita una definición, un "
                            "ejemplo y una situación en la que no se aplica."),
                    "ask": ("Ayúdame a revisar las relaciones del proyecto {proj}. Pregúntame primero qué distinciones importan para mis "
                            "preguntas de investigación. Después propón, para cada relación, una definición, un ejemplo y una situación en la "
                            "que no debe usarse.")},
            "code": {"need": "Necesito reunir pasajes sobre un mismo fenómeno.",
                     "ex": "Todos los fragmentos que hablan de abandono reciben el mismo concepto, cuya definición dice cuándo aplicarlo.",
                     "dec": ("¿Reutilizar un concepto existente o crear uno nuevo? Un concepto nuevo necesita una definición, con un criterio "
                             "de cuándo aplicarlo y cuándo no."),
                     "ask": ("Ayúdame a proponer conceptos para los fragmentos del proyecto {proj}, distinguiendo los que ya están en la "
                             "ontología de los que necesitan una definición nueva. Para cada concepto nuevo, propón la definición, cuándo "
                             "aplicarlo y cuándo no.")},
            "topic": {"need": "Necesito agrupar conceptos en temas más amplios.",
                      "ex": "Falta de agua, inseguridad del terreno y falta de fondos reunidos en el tema «obstáculos».",
                      "dec": "Un tema reúne conceptos, pero no sustituye la definición de cada uno. Prefiere pocos temas, que ayuden a leer el conjunto.",
                      "ask": ("Ayúdame a revisar cómo se agrupan en temas los conceptos del proyecto {proj}. Pregúntame primero qué lectura de "
                              "conjunto quiero hacer. Después propón los temas, los conceptos de cada uno y los que quedan fuera.")},
            "quote": {"need": "Necesito conservar las palabras de la fuente y desarrollar mi interpretación.",
                      "ex": "El fragmento copiado palabra por palabra y, al lado, una nota que dice por qué importa.",
                      "dec": ("El fragmento es la evidencia; la nota es tu lectura. Mezclarlos debilita el análisis. Un fragmento que no se "
                              "localiza en la fuente tiene que volver a ella."),
                      "ask": ("Quiero separar evidencia e interpretación en las anotaciones del proyecto {proj}. Comprueba que los fragmentos "
                              "son copias literales de la fuente y que las notas aportan interpretación, no paráfrasis. Muestra los casos que "
                              "hay que corregir.")},
            "q": {"need": "Necesito vincular cada anotación a mis preguntas de investigación.",
                  "ex": "La nota termina con (Q1) cuando el fragmento ayuda a responder la primera pregunta.",
                  "dec": "Citar la pregunta en la nota muestra para qué sirve cada fragmento y revela preguntas con poca evidencia.",
                  "ask": ("Quiero ver cuánta evidencia reúne el proyecto {proj} para cada pregunta de investigación ({qk}). Cuenta las notas "
                          "que citan cada pregunta y señala las preguntas con poca evidencia.")},
        },
        "here_fmt": {
            "scale_yes": "Este proyecto ya tiene una escala: {names}.",
            "scale_no": "Este proyecto aún no tiene escala. Una posibilidad que valorar: graduar cuánto muestra cada fragmento {q1}.",
            "scale_no2": "Este proyecto aún no tiene escala. Una posibilidad que valorar: graduar cuánto muestra cada fragmento {q1} o {q2}.",
            "enum_yes": "Este proyecto ya tiene: {names}.",
            "enum_no": ("Las fuentes de este proyecto se describen con {names}, en texto libre. Para comparar fuentes por categoría, como "
                        "el tipo de fuente, ayudaría un campo de lista cerrada a nivel de fuente."),
            "enum_nosrc": "Para comparar fuentes por categoría, como el tipo de fuente, ayudaría un campo de lista cerrada a nivel de fuente.",
            "chain_yes": "Este proyecto ya tiene el campo {names}, con {n} cadenas registradas. Por ejemplo:",
            "chain_no": "Este proyecto aún no registra conexiones entre conceptos.",
            "rel_yes": "Relaciones declaradas y cuántas veces se usaron: {decl}.",
            "rel_none": "Este proyecto aún no declara relaciones.",
            "rel_undeclared": " La relación {rels} se usó sin estar declarada: conviene decidir si es nueva o cabe en una de las existentes.",
            "code": "{n} conceptos definidos en la ontología; {single} aparecen en una sola fuente.",
            "code_undef": " Usados sin definición: {names}.",
            "topic_yes": "Los conceptos están agrupados en {n} temas: {groups}.",
            "topic_no": "Los conceptos aún no están agrupados en temas.",
            "quote": "{found} de {total} fragmentos se localizaron en la fuente.",
            "quote_nf": " {n} debe(n) volver a la fuente para comprobarse.",
            "q_yes": "{cite} de {memos} notas citan una pregunta ({keys}).",
            "q_no": "El proyecto aún no tiene preguntas de investigación declaradas.",
        },
    },
)


# --------------------------------------------------------------------------- Français
add_language(
    "fr",
    strings={
        "title": "Vue du projet", "files": "Fichiers", "awaiting": "En attente de votre validation",
        "awaiting_hint": "Écrit par le coder ; n’entre dans le projet que lorsque vous acceptez l’exécution.",
        "project": "Projet", "template": "Template", "ontology": "Ontologie", "annotations": "Annotations",
        "records": "Registres", "references": "Références", "search": "Rechercher dans tous les fichiers…",
        "code_lines": "Lignes de code", "theme": "Clair / sombre", "empty": "Rien à afficher pour l’instant.",
        "blocks": ("bloc", "blocs"), "sources": ("source", "sources"), "items": ("item", "items"),
        "concepts": ("concept", "concepts"), "fields": ("champ", "champs"), "run": "exécution",
        "no_match": "Aucun bloc ne correspond à la recherche.",
        "hint": "Vue en lecture seule des fichiers Synesis. Modifiez les fichiers, pas cette page.",
        "correct": "Correct", "wrong": "Incorrect",
    },
    s={
        "problems": "Validation et révision", "all_clear": "Aucun problème : le projet compile sans erreur ni avertissement.",
        "error": ("erreur", "erreurs"), "warning": ("avertissement", "avertissements"),
        "notfound": ("extrait non retrouvé dans la source", "extraits non retrouvés dans la source"),
        "edited": ("fichier modifié depuis la validation", "fichiers modifiés depuis la validation"),
        "pending": ("exécution en attente de validation", "exécutions en attente de validation"),
        "verified": "{n} extraits sur {t} retrouvés dans la source",
        "line": "ligne", "open_vs": "Ouvrir dans VS Code", "ask": "Demander à Claude", "ask_all": "Demander à Claude de tout corriger",
        "copied": "Demande copiée. Collez-la dans la conversation avec Claude.",
        "q_found": "extrait retrouvé dans la source", "q_notfound": "extrait non retrouvé dans la source",
        "q_unver": "source indisponible pour la vérification",
        "notfound_msg": ("L’extrait n’apparaît pas dans la source @{ref}, même après normalisation des guillemets, des tirets et des "
                         "espaces. Copiez-le littéralement depuis la source."),
        "accepted": "accepté dans l’exécution {run} · {date}", "hand_edit": "modifié depuis la validation",
        "hand_edit_file": "modifié depuis la validation (exécution {run})", "new_block": "nouveau bloc, écrit à la main",
        "by_hand": "écrit à la main", "proposal": "proposé par l’exécution {run}",
        "edited_msg": "{n} bloc(s) diffèrent du contenu accepté dans l’exécution {run}.",
        "undef": "Concept sans définition dans l’ontologie.", "undef_hint": "Demandez à Claude de proposer une définition.",
        "uses": ("utilisé dans {n} item", "utilisé dans {n} items"), "goto_def": "voir la définition",
        "rel_undef": "Relation non déclarée dans le template pour ce champ.", "declared_rel": "Relations déclarées",
        "values": "Valeurs", "guidelines": "Consignes", "scope": "portée",
        "legend": "Survolez les mots en bleu, les noms de champ, les concepts et les relations : une courte explication apparaît.",
        "ask_fix": ("Dans le projet {proj}, le bloc {blk} de {file}, ligne {line}, présente ces problèmes :\n{lines}\n"
                    "Expliquez chaque problème simplement et proposez la correction. Ne modifiez aucun fichier avant mon accord."),
        "ask_review": ("Dans le projet {proj}, relisez le bloc {blk} de {file}, ligne {line} : vérifiez que les codes et la chaîne suivent "
                       "les consignes du template et que l’extrait soutient la note. Dites ce que vous changeriez, sans modifier le fichier."),
        "ask_pending": ("À propos de la proposition de l’exécution {run} (bloc {blk}, ligne {line}) : expliquez le choix des codes et de la "
                        "chaîne et dites si quelque chose devrait changer avant que je l’accepte. N’acceptez pas l’exécution à ma place."),
        "ask_all_text": ("Dans le projet {proj}, le panneau des problèmes indique :\n{lines}\nCorrigez-les un par un : expliquez le problème, "
                         "proposez la correction et attendez mon accord avant de modifier chaque fichier."),
        "sev": {"error": "erreur", "warning": "avert.", "info": "info", "anchor": "extrait", "edit": "modif.", "prop": "proposition"},
        "overview": "Tableau de bord", "questions": "Questions de recherche", "t_sources": "sources annotées", "t_items": "items",
        "t_concepts": "concepts dans l’ontologie", "t_codes": "codes appliqués", "t_chains": "chaînes",
        "t_quotes": "extraits retrouvés dans la source", "top_concepts": "Concepts les plus utilisés (nombre d’items)",
        "relations_used": "Occurrences des relations dans les chaînes", "unused": "Concepts inutilisés", "runs": "Exécutions du coder",
        "awaiting_short": "en attente de validation", "th_run": "Exécution", "th_mode": "Mode", "th_target": "Cible",
        "th_status": "État", "th_date": "Date", "th_model": "Modèle", "tpl_fields": "Champs du template", "th_field": "Champ",
        "th_scope": "Portée", "th_type": "Type", "th_desc": "Description",
        "q_note": "Comparaison textuelle avec la source. Elle ne valide ni l’interprétation ni le codage.",
        "rel_invalid": "non déclarée dans le template", "sec_valid": "Validation", "sec_changes": "Modifications depuis la validation",
        "sec_props": "Propositions à examiner",
        "sec_valid_hint": "Erreurs et avertissements du compilateur, extraits non retrouvés : ils demandent une correction.",
        "sec_changes_hint": "Différences avec ce qui a été accepté : vérifiez qu’elles sont voulues.",
        "sec_props_hint": "Écrit par le coder, pas encore dans le projet : acceptez ou refusez.",
        "none": "Rien à signaler.", "prop_msg": "Exécution {run} : {files} proposé(s) par le coder, pas encore dans le projet.",
        "see_occ": "voir les occurrences", "occ_n": ("{n} occurrence", "{n} occurrences"), "in_src": "dans @{s}",
        "go_block": "aller au bloc", "close": "Fermer", "matrix": "Concepts par source (nombre d’items)",
        "matrix_hint": "Couleur plus intense = plus d’items. Cliquez sur une cellule pour voir les occurrences.",
        "tech_on": "Détails techniques : affichés", "tech_off": "Détails techniques : masqués", "tech": "détails techniques",
        "found_n": ("{n} bloc trouvé", "{n} blocs trouvés"),
        "short": {"MissingRequiredField": "Le champ obligatoire `{0}` manque dans ce bloc.",
                  "InvalidChainRelation": "La relation `{0}` n’est pas déclarée dans le template pour ce champ.",
                  "UndefinedCode": "Le code `{0}` n’a pas de définition dans l’ontologie."},
        "short_fallback": "Problème de validation ({code}). Voir les détails techniques.",
        "oc_diag": "{e} erreur(s) et {w} avertissement(s) dans ce bloc", "sort_by": "Trier par", "by_n": "nombre d’items",
        "by_ns": "nombre de sources", "by_name": "nom", "group": "Groupe", "all": "tous", "no_def": "sans définition",
        "no_group": "(sans groupe)",
        "matrix_hint2": "Inclut tous les codes utilisés dans les annotations, même ceux qui n’ont pas encore de définition dans l’ontologie.",
        "no_entry": "Utilisé dans les annotations ; sans entrée dans l’ontologie, et le template ne l’exige pas.",
        "compile_fail": ("Le projet n’a pas pu être compilé pour cette page ({err}). Les fichiers s’affichent, mais sans validation, "
                         "concepts ni aide des champs. Demandez à Claude d’exécuter sk.py check."),
        "capped": "Affichage des {r} concepts les plus fréquents (sur {rt}) et des {c} sources ayant le plus d’items (sur {ct}).",
        "eyebrow": "Synesis · projet de recherche", "legend_n": "items par cellule", "corpus": "Corpus",
        "help": "Comment lire cette page", "details": "voir les détails", "focus": "Concept en vue", "dist": "Répartition par source",
        "see_all": ("Voir l’occurrence", "Voir les {n} occurrences"), "in_k": "{n} occurrence(s) dans {k} sources sur {s}",
        "pick_hint": "Survolez une ligne ; cliquez sur un concept pour le fixer.",
        "scroll_hint": "faites défiler pour voir toutes les sources →", "more": "Décision méthodologique et demande à Claude",
    },
    kw={
        "FIELD": "Crée un champ : une des informations que vous allez enregistrer dans le projet. Celui-ci s’appelle {f}.",
        "TYPE": "Indique quel type d’information le champ {f} contient. Survolez le type, à côté, pour voir ce qu’il signifie.",
        "T:TEXT": "Texte libre, écrit par vous, en une ou plusieurs phrases.",
        "T:QUOTATION": "Extrait copié mot pour mot depuis la source. C’est la preuve : on ne le résume ni ne le corrige.",
        "T:MEMO": "Une note de votre interprétation : pourquoi l’extrait compte pour la recherche.",
        "T:CODE": "Les concepts appliqués à l’extrait, séparés par des virgules. Chaque concept doit avoir une définition dans l’ontologie.",
        "T:CHAIN": "Relie des concepts par une relation (concept → RELATION → concept), quand la source elle-même affirme ce lien.",
        "T:TOPIC": "Un thème large, qui regroupe plusieurs concepts voisins.",
        "T:ENUMERATED": "Une option choisie dans une liste fermée de valeurs.",
        "T:ORDERED": "Une option choisie dans une liste ordonnée, comme faible, moyen et fort.",
        "T:SCALE": "Un nombre compris dans une plage convenue.",
        "T:DATE": "Une date.",
        "SCOPE": "Indique où le champ {f} est rempli.",
        "SCOPE:SOURCE": "Le champ {f} est rempli une fois par source (entretien, article, document) et décrit la source dans son ensemble.",
        "SCOPE:ITEM": "Le champ {f} appartient aux items : il est rempli pour chaque extrait que vous relevez dans une source.",
        "SCOPE:ONTOLOGY": "Le champ {f} appartient à l’ontologie, le dictionnaire des concepts du projet : il est rempli pour chaque concept.",
        "GUIDELINES@G": ("Consignes écrites dans le template sur la façon de remplir un champ, avec des exemples corrects et incorrects. "
                         "C’est là que se trouvent les critères de chaque niveau ou catégorie."),
        "DESCRIPTION": "Dit en quelques mots à quoi sert le champ {f}.",
        "DESCRIPTION@P": "Décrit le projet en quelques mots.",
        "GUIDELINES": ("Consignes pour remplir le champ {f}, avec des exemples de ce qui est juste et de ce qui ne l’est pas. "
                       "Qui code, vous ou Claude, suit ces consignes."),
        "RELATIONS": "Les relations qui peuvent relier des concepts dans ce champ, chacune avec son sens. Seules celles-ci peuvent être utilisées.",
        "VALUES": "Les options autorisées dans ce champ.",
        "ARITY": "Combien de concepts la chaîne doit relier ({v}).",
        "REQUIRED": "Champs obligatoires : ils doivent figurer dans chaque bloc de ce type.",
        "OPTIONAL": "Champs facultatifs : ils peuvent être omis lorsqu’ils ne s’appliquent pas.",
        "BUNDLE": "Champs qui vont ensemble, par paires : le premier de l’un avec le premier de l’autre, et ainsi de suite.",
        "SOURCE FIELDS": "Les champs qui décrivent chaque source dans son ensemble.",
        "ITEM FIELDS": "Les champs de chaque item, c’est-à-dire de chaque extrait relevé dans une source.",
        "ONTOLOGY FIELDS": "Les champs de chaque concept de l’ontologie.",
        "SOURCE": "Ouvre la fiche de la source {v}. Le nom après @ est le même que dans la bibliographie.",
        "ITEM": "Ouvre un item : un extrait relevé dans la source {v}, avec votre interprétation et les concepts appliqués.",
        "ONTOLOGY": "Ouvre la définition du concept {v}. Chaque concept utilisé dans les items a besoin d’une définition de ce type.",
        "END": "Ferme le bloc {v} ouvert plus haut. Tout ce qui se trouve entre l’ouverture et cette ligne lui appartient.",
        "PROJECT": "Ouvre le fichier du projet : son nom et les fichiers qui en font partie.",
        "TEMPLATE": "Le template : le fichier qui définit quels champs existent et comment les remplir.",
        "INCLUDE": "Inclut un fichier ou un dossier dans le projet.",
        "BIBLIOGRAPHY": "Les références des sources, comme dans une bibliographie.",
        "ANNOTATIONS": "L’emplacement des annotations : les sources et les extraits qui y sont relevés.",
        "INC:ONTOLOGY": "L’emplacement des définitions des concepts (l’ontologie).",
        "QUESTIONS": "Les questions de recherche. Les notes peuvent les citer, par exemple (Q1).",
        "EXPORT": "Produit une copie des données du projet dans un autre format ({v}), pour l’analyser avec d’autres outils.",
        "OUTPUT": "L’endroit où la copie exportée sera enregistrée.",
        "GENERATED_AT": "Une date fixe inscrite dans la copie exportée, pour qu’elle soit toujours identique.",
    },
    help_={
        "n_tips": ("1 suggestion pour commencer", "{n} suggestions pour commencer"), "tab": "Par où commencer",
        "about": ("Voici le projet {name} : {src} sources, {items} items et {conc} concepts. La page ne fait que montrer les fichiers ; "
                  "les modifications se font dans les fichiers ou en les demandant à Claude dans la conversation."),
        "start_err": ("Commencez par la validation : il y a {e} et le projet ne compile pas en l’état. Ouvrez {link} et utilisez "
                      "« Demander à Claude » pour chaque problème."),
        "start_warn": "Il y a {w} à examiner dans {link}.",
        "nf": "{n} n’a pas été retrouvé dans la source : revenez à la source et copiez-le littéralement.",
        "pending": ("Une proposition du coder attend votre décision dans l’onglet {link}. Lisez les fiches et dites à Claude si vous "
                    "acceptez ou refusez l’exécution."),
        "edits": "{n} ont changé depuis la validation. Vérifiez que les changements sont voulus.",
        "undef": ("Le code {codes} n’a pas encore de définition dans l’ontologie ; Claude peut en proposer une.",
                  "Les codes {codes} n’ont pas encore de définition dans l’ontologie ; Claude peut les proposer."),
        "clear": "Rien en attente : le projet compile et tous les extraits ont été retrouvés dans les sources.",
        "explore": ("Pour explorer, utilisez la matrice {link} : cliquez sur un concept pour le mettre en vue et sur une cellule pour lire "
                    "les extraits de cette source. Le concept le plus fréquent est «{top}» ({n} items)."),
        "learn": ("Les mots en bleu dans les fichiers (comme SCOPE et END ITEM) s’expliquent au survol. L’onglet {link} suggère ce "
                  "qu’on peut encore enregistrer, avec des demandes prêtes pour Claude."),
        "review_link": "Validation et révision", "matrix_link": "Concepts par source",
        "err": ("1 erreur", "{n} erreurs"), "warn": ("1 avertissement", "{n} avertissements"), "q": ("1 extrait", "{n} extraits"),
        "files": ("1 fichier", "{n} fichiers"),
    },
    links={
        "docs": "Documentation", "github": "GitHub", "cite": "Comment citer", "support_t": "Soutenir Synesis",
        "support": ("Synesis est un logiciel libre, fait par des chercheurs pour des chercheurs. S’il vous aide dans votre travail, "
                    "voici trois façons simples de rendre la pareille :"),
        "star": "Ajoutez une étoile sur GitHub", "star_why": "cela aide d’autres chercheurs à trouver Synesis et montre qu’il est utilisé.",
        "cite_why": "citez Synesis dans les publications qui l’ont utilisé ; c’est la reconnaissance qui compte dans la vie académique.",
        "issue": "Dites-nous ce qui n’a pas fonctionné", "issue_why": "les retours d’usage réel orientent les prochaines versions.",
        "copy_cite": "Copier la citation (APA)", "copy_bib": "Copier le BibTeX", "copied_cite": "Citation copiée.",
        "copied_bib": "BibTeX copié. Vous pouvez le coller dans votre fichier .bib.", "made": "Réalisé avec Synesis",
    },
    tab_short={"pending": "En attente", "poss": "Possibilités"},
    run_status={"accepted": "acceptée", "stale": "périmée", "rejected": "refusée"},
    guide={
        "tab": "Possibilités de recherche", "sep": ", ", "some": "un phénomène de la recherche",
        "intro": ("Partez de ce que vous voulez étudier, pas du nom d’un champ. Chaque possibilité présente un besoin, un exemple, "
                  "la décision qu’elle demande et la fonction de Synesis qui la réalise. La demande peut être copiée et adaptée dans "
                  "la conversation avec Claude : il clarifiera votre intention et proposera des alternatives avant de suggérer une structure."),
        "goal": "Objectif : pouvoir dire « je veux étudier ceci ; aidez-moi à l’enregistrer et à l’analyser », sans connaître le nom des champs.",
        "example": "Exemple", "decision": "Décision à prendre", "resource": "Fonction de Synesis", "here": "Dans ce projet",
        "ask_label": "Demande à adapter", "copy": "Copier la demande à adapter",
        "tail": " Ne modifiez aucun fichier avant mon accord.", "more": "Décision méthodologique et demande à Claude",
        "groups": {
            "compare": {"title": "Je veux comparer", "lead": "Comparer des sources, des extraits ou des groupes exige un critère commun, enregistré partout de la même façon."},
            "connect": {"title": "Je veux relier", "lead": "Les liens entre concepts montrent des mécanismes : ce qui mène à quoi, ce qui permet ou empêche quoi."},
            "organize": {"title": "Je veux comprendre et organiser", "lead": "Des concepts bien définis rassemblent les passages sur un même phénomène et rendent l’analyse vérifiable."},
            "support": {"title": "Je veux étayer mon interprétation", "lead": "Une interprétation convainc quand on peut revenir à la source et voir d’où elle vient."},
        },
        "items": {
            "scale": {"need": "J’ai besoin d’enregistrer une intensité, un degré ou une évaluation sous forme de nombre.",
                      "ex": "Le degré de confiance qu’une personne exprime envers une institution, de 1 (aucune) à 5 (totale).",
                      "dec": ("Voulez-vous enregistrer la note donnée par la source elle-même, ou évaluer vous-même l’intensité décrite dans "
                              "l’extrait ? Ce sont des informations différentes, qui peuvent demander des champs distincts. Dans les deux cas, "
                              "chaque niveau a besoin d’un critère écrit, pour qu’une même situation reçoive toujours le même nombre."),
                      "ask": ("Je veux enregistrer une intensité ou un degré dans les annotations du projet {proj}, par exemple à quel point "
                              "chaque extrait montre {q1}. Avant de proposer quoi que ce soit, posez-moi jusqu’à trois questions pour comprendre "
                              "mon intention, notamment si le nombre vient de la source ou de moi. Puis présentez des alternatives et proposez "
                              "les niveaux de l’échelle, un critère pour chaque niveau et un exemple tiré du projet.")},
            "enum": {"need": "J’ai besoin de classer des sources ou des extraits dans des catégories fixes, pour comparer des groupes.",
                     "ex": "Type de participant (responsable, bénévole, voisin) ou étape du groupe (début, consolidation, déclin).",
                     "dec": ("Les catégories ont-elles un ordre (faible, moyen, fort) ou sont-elles seulement différentes ? Avec un ordre, "
                             "utilisez ORDERED ; sans ordre, ENUMERATED. Et la catégorie décrit-elle toute la source ou chaque extrait ?"),
                     "ask": ("Je veux comparer des groupes de sources ou d’extraits dans le projet {proj}. Demandez-moi d’abord quels groupes "
                             "je veux comparer et si les catégories ont un ordre. Puis présentez des alternatives et proposez un champ avec les "
                             "catégories, la définition de chacune et le niveau où il est rempli (toute la source ou chaque extrait).")},
            "chain": {"need": "J’ai besoin de représenter comment les sources relient des concepts ou d’autres informations.",
                      "ex": "infrastructure → PERMET → changement d’habitude",
                      "dec": ("La chaîne enregistre le lien ; les relations (RELATIONS) définissent le sens de chaque lien autorisé. Utilisez "
                              "la chaîne quand la source soutient le lien. Si le lien est votre propre hypothèse, convenez avec Claude d’une "
                              "façon de l’enregistrer comme interprétation, par exemple dans la note."),
                      "ask": ("Je veux représenter comment les sources du projet {proj} relient des concepts, par exemple {q1} et {q2}. "
                              "Demandez-moi d’abord quel type de lien m’intéresse et comment distinguer un lien affirmé par la source d’un lien "
                              "qui relève de mon interprétation. Puis présentez des alternatives et proposez le champ, les relations et des "
                              "consignes avec des exemples justes et faux.")},
            "rel": {"need": "J’ai besoin de distinguer les différentes façons dont les choses sont liées.",
                    "ex": "CAUSE (un facteur en produit un autre), CONDITION (un facteur en rend un autre possible), FREIN (un facteur en gêne un autre).",
                    "dec": ("Quelques relations bien définies comparent mieux que beaucoup de relations voisines. Chaque relation a besoin "
                            "d’une définition, d’un exemple et d’un cas où elle ne s’applique pas."),
                    "ask": ("Aidez-moi à revoir les relations du projet {proj}. Demandez-moi d’abord quelles distinctions comptent pour mes "
                            "questions de recherche. Puis proposez, pour chaque relation, une définition, un exemple et un cas où elle ne doit "
                            "pas être utilisée.")},
            "code": {"need": "J’ai besoin de rassembler les passages sur un même phénomène.",
                     "ex": "Tous les extraits qui parlent d’abandon reçoivent le même concept, dont la définition dit quand l’appliquer.",
                     "dec": ("Réutiliser un concept existant ou en créer un nouveau ? Un nouveau concept a besoin d’une définition, avec un "
                             "critère pour savoir quand l’appliquer et quand ne pas l’appliquer."),
                     "ask": ("Aidez-moi à proposer des concepts pour les extraits du projet {proj}, en distinguant ceux qui existent déjà dans "
                             "l’ontologie de ceux qui demandent une nouvelle définition. Pour chaque nouveau concept, proposez la définition, "
                             "quand l’appliquer et quand ne pas l’appliquer.")},
            "topic": {"need": "J’ai besoin de regrouper des concepts en thèmes plus larges.",
                      "ex": "Manque d’eau, terrain précaire et manque de fonds réunis sous le thème «obstacles».",
                      "dec": "Un thème regroupe des concepts mais ne remplace pas la définition de chacun. Préférez quelques thèmes qui aident à lire l’ensemble.",
                      "ask": ("Aidez-moi à revoir comment les concepts du projet {proj} sont regroupés en thèmes. Demandez-moi d’abord quelle "
                              "lecture d’ensemble je veux faire. Puis proposez les thèmes, les concepts de chacun et ceux qui restent à part.")},
            "quote": {"need": "J’ai besoin de garder les mots de la source et de développer mon interprétation.",
                      "ex": "L’extrait copié mot pour mot et, à côté, une note qui dit pourquoi il compte.",
                      "dec": ("L’extrait est la preuve ; la note est votre lecture. Les mélanger affaiblit l’analyse. Un extrait introuvable "
                              "dans la source doit y retourner."),
                      "ask": ("Je veux séparer preuve et interprétation dans les annotations du projet {proj}. Vérifiez que les extraits sont "
                              "des copies littérales de la source et que les notes apportent une interprétation, pas une paraphrase. Montrez "
                              "les cas à corriger.")},
            "q": {"need": "J’ai besoin de rattacher chaque annotation à mes questions de recherche.",
                  "ex": "La note se termine par (Q1) quand l’extrait aide à répondre à la première question.",
                  "dec": "Citer la question dans la note montre à quoi sert chaque extrait et révèle les questions peu étayées.",
                  "ask": ("Je veux voir combien d’éléments le projet {proj} réunit pour chaque question de recherche ({qk}). Comptez les "
                          "notes qui citent chaque question et signalez les questions peu étayées.")},
        },
        "here_fmt": {
            "scale_yes": "Ce projet a déjà une échelle : {names}.",
            "scale_no": "Ce projet n’a pas encore d’échelle. Une possibilité à étudier : graduer à quel point chaque extrait montre {q1}.",
            "scale_no2": "Ce projet n’a pas encore d’échelle. Une possibilité à étudier : graduer à quel point chaque extrait montre {q1} ou {q2}.",
            "enum_yes": "Ce projet a déjà : {names}.",
            "enum_no": ("Les sources de ce projet sont décrites par {names}, en texte libre. Pour comparer les sources par catégorie, "
                        "comme le type de source, un champ à liste fermée au niveau de la source serait utile."),
            "enum_nosrc": "Pour comparer les sources par catégorie, comme le type de source, un champ à liste fermée au niveau de la source serait utile.",
            "chain_yes": "Ce projet a déjà le champ {names}, avec {n} chaînes enregistrées. Par exemple :",
            "chain_no": "Ce projet n’enregistre pas encore de liens entre concepts.",
            "rel_yes": "Relations déclarées et nombre d’utilisations : {decl}.",
            "rel_none": "Ce projet ne déclare pas encore de relations.",
            "rel_undeclared": " La relation {rels} a été utilisée sans être déclarée : à vous de décider si elle est nouvelle ou si elle relève d’une relation existante.",
            "code": "{n} concepts définis dans l’ontologie ; {single} n’apparaissent que dans une seule source.",
            "code_undef": " Utilisés sans définition : {names}.",
            "topic_yes": "Les concepts sont regroupés en {n} thèmes : {groups}.",
            "topic_no": "Les concepts ne sont pas encore regroupés en thèmes.",
            "quote": "{found} extraits sur {total} ont été retrouvés dans la source.",
            "quote_nf": " {n} doit/doivent retourner à la source pour vérification.",
            "q_yes": "{cite} notes sur {memos} citent une question ({keys}).",
            "q_no": "Le projet n’a pas encore de questions de recherche déclarées.",
        },
    },
)


# --------------------------------------------------------------------------- Deutsch
add_language(
    "de",
    strings={
        "title": "Projektansicht", "files": "Dateien", "awaiting": "Wartet auf Ihre Freigabe",
        "awaiting_hint": "Vom Coder geschrieben; gehört erst zum Projekt, wenn Sie den Lauf freigeben.",
        "project": "Projekt", "template": "Template", "ontology": "Ontologie", "annotations": "Annotationen",
        "records": "Datensätze", "references": "Literatur", "search": "In allen Dateien suchen…",
        "code_lines": "Codezeilen", "theme": "Hell / dunkel", "empty": "Noch nichts anzuzeigen.",
        "blocks": ("Block", "Blöcke"), "sources": ("Quelle", "Quellen"), "items": ("Item", "Items"),
        "concepts": ("Konzept", "Konzepte"), "fields": ("Feld", "Felder"), "run": "Lauf",
        "no_match": "Kein Block entspricht der Suche.",
        "hint": "Nur-Lese-Ansicht der Synesis-Dateien. Bearbeiten Sie die Dateien, nicht diese Seite.",
        "correct": "Richtig", "wrong": "Falsch",
    },
    s={
        "problems": "Prüfung und Durchsicht", "all_clear": "Keine Probleme: Das Projekt kompiliert ohne Fehler und Warnungen.",
        "error": ("Fehler", "Fehler"), "warning": ("Warnung", "Warnungen"),
        "notfound": ("Auszug nicht in der Quelle gefunden", "Auszüge nicht in der Quelle gefunden"),
        "edited": ("Datei seit der Freigabe geändert", "Dateien seit der Freigabe geändert"),
        "pending": ("Lauf wartet auf Freigabe", "Läufe warten auf Freigabe"),
        "verified": "{n} von {t} Auszügen in der Quelle gefunden",
        "line": "Zeile", "open_vs": "In VS Code öffnen", "ask": "Claude fragen", "ask_all": "Claude bitten, alles zu beheben",
        "copied": "Anfrage kopiert. Fügen Sie sie in das Gespräch mit Claude ein.",
        "q_found": "Auszug in der Quelle gefunden", "q_notfound": "Auszug nicht in der Quelle gefunden",
        "q_unver": "Quelle zur Prüfung nicht verfügbar",
        "notfound_msg": ("Der Auszug kommt in der Quelle @{ref} nicht vor, auch nicht nach Angleichung von Anführungszeichen, "
                         "Strichen und Leerzeichen. Kopieren Sie ihn wörtlich aus der Quelle."),
        "accepted": "freigegeben in Lauf {run} · {date}", "hand_edit": "seit der Freigabe geändert",
        "hand_edit_file": "seit der Freigabe geändert (Lauf {run})", "new_block": "neuer Block, von Hand geschrieben",
        "by_hand": "von Hand geschrieben", "proposal": "vorgeschlagen von Lauf {run}",
        "edited_msg": "{n} Block/Blöcke weichen vom in Lauf {run} freigegebenen Inhalt ab.",
        "undef": "Konzept ohne Definition in der Ontologie.", "undef_hint": "Bitten Sie Claude, eine Definition vorzuschlagen.",
        "uses": ("in {n} Item verwendet", "in {n} Items verwendet"), "goto_def": "Definition ansehen",
        "rel_undef": "Relation ist im Template für dieses Feld nicht deklariert.", "declared_rel": "Deklarierte Relationen",
        "values": "Werte", "guidelines": "Hinweise", "scope": "Geltungsbereich",
        "legend": "Fahren Sie mit der Maus über blaue Wörter, Feldnamen, Konzepte und Relationen: Eine kurze Erklärung erscheint.",
        "ask_fix": ("Im Projekt {proj} hat der Block {blk} in {file}, Zeile {line}, diese Probleme:\n{lines}\n"
                    "Erklären Sie jedes Problem in einfachen Worten und schlagen Sie die Korrektur vor. Ändern Sie keine Datei, bevor ich zustimme."),
        "ask_review": ("Prüfen Sie im Projekt {proj} den Block {blk} in {file}, Zeile {line}: Folgen die Codes und die Kette den Hinweisen "
                       "des Templates, und stützt der Auszug die Notiz? Sagen Sie, was Sie ändern würden, ohne die Datei zu bearbeiten."),
        "ask_pending": ("Zum Vorschlag aus Lauf {run} (Block {blk}, Zeile {line}): Erklären Sie die Wahl der Codes und der Kette und sagen "
                        "Sie, ob sich vor meiner Freigabe etwas ändern sollte. Geben Sie den Lauf nicht für mich frei."),
        "ask_all_text": ("Im Projekt {proj} zeigt die Problemübersicht:\n{lines}\nBeheben Sie sie nacheinander: Erklären Sie das Problem, "
                         "schlagen Sie die Korrektur vor und warten Sie vor jeder Dateiänderung auf meine Zustimmung."),
        "sev": {"error": "Fehler", "warning": "Warnung", "info": "Info", "anchor": "Auszug", "edit": "Änderung", "prop": "Vorschlag"},
        "overview": "Übersicht", "questions": "Forschungsfragen", "t_sources": "annotierte Quellen", "t_items": "Items",
        "t_concepts": "Konzepte in der Ontologie", "t_codes": "vergebene Codes", "t_chains": "Ketten",
        "t_quotes": "Auszüge in der Quelle gefunden", "top_concepts": "Häufigste Konzepte (Anzahl Items)",
        "relations_used": "Vorkommen von Relationen in Ketten", "unused": "Unbenutzte Konzepte", "runs": "Läufe des Coders",
        "awaiting_short": "wartet auf Freigabe", "th_run": "Lauf", "th_mode": "Modus", "th_target": "Ziel",
        "th_status": "Status", "th_date": "Datum", "th_model": "Modell", "tpl_fields": "Felder des Templates", "th_field": "Feld",
        "th_scope": "Geltungsbereich", "th_type": "Typ", "th_desc": "Beschreibung",
        "q_note": "Textvergleich mit der Quelle. Er bestätigt weder die Interpretation noch die Codierung.",
        "rel_invalid": "nicht im Template deklariert", "sec_valid": "Prüfung", "sec_changes": "Änderungen seit der Freigabe",
        "sec_props": "Vorschläge zur Durchsicht",
        "sec_valid_hint": "Fehler und Warnungen des Compilers sowie nicht gefundene Auszüge: Sie müssen korrigiert werden.",
        "sec_changes_hint": "Abweichungen vom Freigegebenen: Prüfen Sie, ob sie beabsichtigt waren.",
        "sec_props_hint": "Vom Coder geschrieben, noch nicht im Projekt: freigeben oder ablehnen.",
        "none": "Nichts zu melden.", "prop_msg": "Lauf {run}: {files} vom Coder vorgeschlagen, noch nicht im Projekt.",
        "see_occ": "Vorkommen ansehen", "occ_n": ("{n} Vorkommen", "{n} Vorkommen"), "in_src": "in @{s}", "go_block": "zum Block",
        "close": "Schließen", "matrix": "Konzepte nach Quelle (Anzahl Items)",
        "matrix_hint": "Kräftigere Farbe = mehr Items. Klicken Sie auf eine Zelle, um die Vorkommen zu sehen.",
        "tech_on": "Technische Details: an", "tech_off": "Technische Details: aus", "tech": "technische Details",
        "found_n": ("{n} Block gefunden", "{n} Blöcke gefunden"),
        "short": {"MissingRequiredField": "In diesem Block fehlt das Pflichtfeld `{0}`.",
                  "InvalidChainRelation": "Die Relation `{0}` ist im Template für dieses Feld nicht deklariert.",
                  "UndefinedCode": "Der Code `{0}` hat keine Definition in der Ontologie."},
        "short_fallback": "Prüfproblem ({code}). Siehe technische Details.",
        "oc_diag": "{e} Fehler und {w} Warnung(en) in diesem Block", "sort_by": "Sortieren nach", "by_n": "Anzahl Items",
        "by_ns": "Anzahl Quellen", "by_name": "Name", "group": "Gruppe", "all": "alle", "no_def": "ohne Definition",
        "no_group": "(ohne Gruppe)",
        "matrix_hint2": "Enthält alle in den Annotationen verwendeten Codes, auch solche, die in der Ontologie noch keine Definition haben.",
        "no_entry": "Kommt in den Annotationen vor; hat keinen Eintrag in der Ontologie, und das Template verlangt keinen.",
        "compile_fail": ("Das Projekt konnte für diese Seite nicht kompiliert werden ({err}). Die Dateien werden angezeigt, aber ohne "
                         "Prüfung, Konzepte und Feldhilfe. Bitten Sie Claude, sk.py check auszuführen."),
        "capped": "Angezeigt werden die {r} häufigsten Konzepte (von {rt}) und die {c} Quellen mit den meisten Items (von {ct}).",
        "eyebrow": "Synesis · Forschungsprojekt", "legend_n": "Items pro Zelle", "corpus": "Korpus",
        "help": "So lesen Sie diese Seite", "details": "Details ansehen", "focus": "Konzept im Fokus", "dist": "Verteilung nach Quelle",
        "see_all": ("Das Vorkommen ansehen", "Die {n} Vorkommen ansehen"), "in_k": "{n} Vorkommen in {k} von {s} Quellen",
        "pick_hint": "Fahren Sie über eine Zeile; klicken Sie auf ein Konzept, um es festzuhalten.",
        "scroll_hint": "wischen, um alle Quellen zu sehen →", "more": "Methodische Entscheidung und Anfrage an Claude",
    },
    kw={
        "FIELD": "Legt ein Feld an: eine der Angaben, die Sie im Projekt festhalten. Dieses heißt {f}.",
        "TYPE": "Gibt an, welche Art von Angabe das Feld {f} enthält. Fahren Sie über den Typ daneben, um seine Bedeutung zu sehen.",
        "T:TEXT": "Freier Text, von Ihnen geschrieben, in einem oder mehreren Sätzen.",
        "T:QUOTATION": "Ein wörtlich aus der Quelle kopierter Auszug. Er ist der Beleg: Er wird weder gekürzt noch korrigiert.",
        "T:MEMO": "Ihre eigene, deutende Notiz: warum der Auszug für die Forschung wichtig ist.",
        "T:CODE": "Die dem Auszug zugeordneten Konzepte, durch Kommas getrennt. Jedes Konzept braucht eine Definition in der Ontologie.",
        "T:CHAIN": "Verbindet Konzepte über eine Relation (Konzept → RELATION → Konzept), wenn die Quelle selbst diese Verbindung behauptet.",
        "T:TOPIC": "Ein breites Thema, das mehrere ähnliche Konzepte zusammenfasst.",
        "T:ENUMERATED": "Eine Option aus einer festen Liste von Werten.",
        "T:ORDERED": "Eine Option aus einer geordneten Liste, etwa niedrig, mittel und hoch.",
        "T:SCALE": "Eine Zahl innerhalb eines vereinbarten Bereichs.",
        "T:DATE": "Ein Datum.",
        "SCOPE": "Gibt an, wo das Feld {f} ausgefüllt wird.",
        "SCOPE:SOURCE": "Das Feld {f} wird einmal pro Quelle (Interview, Artikel, Dokument) ausgefüllt und beschreibt die Quelle als Ganzes.",
        "SCOPE:ITEM": "Das Feld {f} gehört zu den Items: Es wird für jeden Auszug ausgefüllt, den Sie aus einer Quelle hervorheben.",
        "SCOPE:ONTOLOGY": "Das Feld {f} gehört zur Ontologie, dem Begriffsverzeichnis des Projekts: Es wird für jedes Konzept ausgefüllt.",
        "GUIDELINES@G": ("Im Template festgehaltene Hinweise, wie ein Feld auszufüllen ist, mit richtigen und falschen Beispielen. "
                         "Dort stehen die Kriterien für jede Stufe oder Kategorie."),
        "DESCRIPTION": "Sagt in wenigen Worten, wozu das Feld {f} dient.",
        "DESCRIPTION@P": "Beschreibt das Projekt in wenigen Worten.",
        "GUIDELINES": ("Hinweise zum Ausfüllen des Feldes {f}, mit Beispielen für Richtiges und Falsches. "
                       "Wer codiert, Sie oder Claude, folgt diesen Hinweisen."),
        "RELATIONS": "Die Relationen, die in diesem Feld Konzepte verbinden dürfen, jede mit ihrer Bedeutung. Nur diese sind erlaubt.",
        "VALUES": "Die in diesem Feld erlaubten Optionen.",
        "ARITY": "Wie viele Konzepte die Kette verbinden muss ({v}).",
        "REQUIRED": "Pflichtfelder: Sie müssen in jedem Block dieser Art vorkommen.",
        "OPTIONAL": "Optionale Felder: Sie können entfallen, wenn sie nicht zutreffen.",
        "BUNDLE": "Felder, die paarweise zusammengehören: das erste des einen mit dem ersten des anderen und so weiter.",
        "SOURCE FIELDS": "Die Felder, die jede Quelle als Ganzes beschreiben.",
        "ITEM FIELDS": "Die Felder jedes Items, also jedes aus einer Quelle hervorgehobenen Auszugs.",
        "ONTOLOGY FIELDS": "Die Felder jedes Konzepts der Ontologie.",
        "SOURCE": "Öffnet den Eintrag der Quelle {v}. Der Name nach @ ist derselbe wie im Literaturverzeichnis.",
        "ITEM": "Öffnet ein Item: einen aus der Quelle {v} hervorgehobenen Auszug, mit Ihrer Interpretation und den zugeordneten Konzepten.",
        "ONTOLOGY": "Öffnet die Definition des Konzepts {v}. Jedes in den Items verwendete Konzept braucht eine solche Definition.",
        "END": "Schließt den oben geöffneten Block {v}. Alles zwischen der Öffnung und dieser Zeile gehört zu ihm.",
        "PROJECT": "Öffnet die Projektdatei: ihren Namen und die Dateien, die zum Projekt gehören.",
        "TEMPLATE": "Das Template: die Datei, die festlegt, welche Felder es gibt und wie sie auszufüllen sind.",
        "INCLUDE": "Nimmt eine Datei oder einen Ordner in das Projekt auf.",
        "BIBLIOGRAPHY": "Die Literaturangaben der Quellen, wie in einem Literaturverzeichnis.",
        "ANNOTATIONS": "Wo die Annotationen liegen: die Quellen und die daraus hervorgehobenen Auszüge.",
        "INC:ONTOLOGY": "Wo die Definitionen der Konzepte liegen (die Ontologie).",
        "QUESTIONS": "Die Forschungsfragen. Notizen können sie zitieren, zum Beispiel (Q1).",
        "EXPORT": "Erzeugt eine Kopie der Projektdaten in einem anderen Format ({v}), zur Auswertung mit anderen Werkzeugen.",
        "OUTPUT": "Wohin die exportierte Kopie geschrieben wird.",
        "GENERATED_AT": "Ein festes Datum in der exportierten Kopie, damit sie immer gleich ausfällt.",
    },
    help_={
        "n_tips": ("1 Vorschlag für den Einstieg", "{n} Vorschläge für den Einstieg"), "tab": "Wo anfangen",
        "about": ("Dies ist das Projekt {name}: {src} Quellen, {items} Items und {conc} Konzepte. Die Seite zeigt nur die Dateien; "
                  "Änderungen erfolgen in den Dateien oder durch eine Bitte an Claude im Gespräch."),
        "start_err": ("Beginnen Sie mit der Prüfung: Es gibt {e}, und so kompiliert das Projekt nicht. Öffnen Sie {link} und nutzen "
                      "Sie bei jedem Problem «Claude fragen»."),
        "start_warn": "In {link} sind {w} zu prüfen.",
        "nf": "{n} wurde in der Quelle nicht gefunden: Gehen Sie zur Quelle zurück und kopieren Sie den Text wörtlich.",
        "pending": ("Ein Vorschlag des Coders wartet im Reiter {link} auf Ihre Entscheidung. Lesen Sie die Karten und sagen Sie Claude, "
                    "ob Sie den Lauf freigeben oder ablehnen."),
        "edits": "{n} wurden seit der Freigabe geändert. Prüfen Sie, ob die Änderungen beabsichtigt waren.",
        "undef": ("Der Code {codes} hat noch keine Definition in der Ontologie; Claude kann eine vorschlagen.",
                  "Die Codes {codes} haben noch keine Definition in der Ontologie; Claude kann sie vorschlagen."),
        "clear": "Nichts offen: Das Projekt kompiliert, und alle Auszüge wurden in den Quellen gefunden.",
        "explore": ("Zum Erkunden nutzen Sie die Matrix {link}: Klicken Sie auf ein Konzept, um es in den Fokus zu nehmen, und auf "
                    "eine Zelle, um die Auszüge dieser Quelle zu lesen. Das häufigste Konzept ist «{top}» ({n} Items)."),
        "learn": ("Die blauen Wörter in den Dateien (etwa SCOPE und END ITEM) erklären sich beim Überfahren mit der Maus. Der Reiter "
                  "{link} schlägt vor, was sich noch festhalten lässt, mit fertigen Anfragen an Claude."),
        "review_link": "Prüfung und Durchsicht", "matrix_link": "Konzepte nach Quelle",
        "err": ("1 Fehler", "{n} Fehler"), "warn": ("1 Warnung", "{n} Warnungen"), "q": ("1 Auszug", "{n} Auszüge"),
        "files": ("1 Datei", "{n} Dateien"),
    },
    links={
        "docs": "Dokumentation", "github": "GitHub", "cite": "Zitieren", "support_t": "Synesis unterstützen",
        "support": ("Synesis ist freie Software, von Forschenden für Forschende. Wenn sie Ihnen bei der Arbeit hilft, gibt es drei "
                    "einfache Wege, etwas zurückzugeben:"),
        "star": "Auf GitHub einen Stern geben", "star_why": "das hilft anderen Forschenden, Synesis zu finden, und zeigt, dass es genutzt wird.",
        "cite_why": "zitieren Sie Synesis in Veröffentlichungen, die es genutzt haben; das ist die Anerkennung, die im akademischen Leben zählt.",
        "issue": "Sagen Sie uns, was nicht funktioniert hat", "issue_why": "Berichte aus echter Nutzung leiten die nächsten Versionen.",
        "copy_cite": "Zitat kopieren (APA)", "copy_bib": "BibTeX kopieren", "copied_cite": "Zitat kopiert.",
        "copied_bib": "BibTeX kopiert. Sie können es in Ihre .bib-Datei einfügen.", "made": "Erstellt mit Synesis",
    },
    tab_short={"pending": "Wartet auf Freigabe", "poss": "Möglichkeiten"},
    run_status={"accepted": "freigegeben", "stale": "veraltet", "rejected": "abgelehnt"},
    guide={
        "tab": "Forschungsmöglichkeiten", "sep": ", ", "some": "ein Phänomen der Forschung",
        "intro": ("Gehen Sie von dem aus, was Sie untersuchen wollen, nicht vom Namen eines Feldes. Jede Möglichkeit zeigt ein "
                  "Anliegen, ein Beispiel, die dafür nötige Entscheidung und die Synesis-Funktion, die es umsetzt. Die Anfrage lässt "
                  "sich kopieren und im Gespräch mit Claude anpassen: Claude klärt Ihre Absicht und stellt Alternativen vor, bevor eine "
                  "Struktur vorgeschlagen wird."),
        "goal": "Ziel: Sie können sagen „Das will ich untersuchen; hilf mir, es festzuhalten und auszuwerten“, auch ohne die Feldnamen zu kennen.",
        "example": "Beispiel", "decision": "Zu treffende Entscheidung", "resource": "Synesis-Funktion", "here": "In diesem Projekt",
        "ask_label": "Anfrage zum Anpassen", "copy": "Anfrage zum Anpassen kopieren",
        "tail": " Ändern Sie keine Datei, bevor ich zustimme.", "more": "Methodische Entscheidung und Anfrage an Claude",
        "groups": {
            "compare": {"title": "Ich will vergleichen", "lead": "Quellen, Auszüge oder Gruppen zu vergleichen erfordert ein gemeinsames Kriterium, das überall gleich festgehalten wird."},
            "connect": {"title": "Ich will verknüpfen", "lead": "Verbindungen zwischen Konzepten zeigen Mechanismen: was wozu führt, was etwas ermöglicht oder verhindert."},
            "organize": {"title": "Ich will verstehen und ordnen", "lead": "Klar definierte Konzepte bündeln Passagen zum selben Phänomen und machen die Analyse überprüfbar."},
            "support": {"title": "Ich will meine Interpretation belegen", "lead": "Eine Interpretation überzeugt, wenn man zur Quelle zurückgehen und sehen kann, woher sie stammt."},
        },
        "items": {
            "scale": {"need": "Ich muss Intensität, Ausmaß oder eine Bewertung als Zahl festhalten.",
                      "ex": "Wie viel Vertrauen eine Person in eine Institution äußert, von 1 (keines) bis 5 (volles).",
                      "dec": ("Wollen Sie die Bewertung der Quelle selbst festhalten oder die im Auszug beschriebene Intensität selbst "
                              "einstufen? Das sind verschiedene Angaben, die getrennte Felder brauchen können. In jedem Fall braucht jede "
                              "Stufe ein schriftliches Kriterium, damit dieselbe Situation immer dieselbe Zahl erhält."),
                      "ask": ("Ich möchte in den Annotationen des Projekts {proj} eine Intensität oder ein Ausmaß festhalten, zum Beispiel "
                              "wie stark jeder Auszug {q1} zeigt. Bevor Sie etwas vorschlagen, stellen Sie mir bis zu drei Fragen, um meine "
                              "Absicht zu verstehen, auch ob die Zahl von der Quelle stammt oder von mir. Stellen Sie dann Alternativen vor "
                              "und schlagen Sie die Stufen der Skala, ein Kriterium je Stufe und ein Beispiel aus dem Projekt vor.")},
            "enum": {"need": "Ich muss Quellen oder Auszüge festen Kategorien zuordnen, um Gruppen zu vergleichen.",
                     "ex": "Art der Beteiligten (Leitung, Ehrenamtliche, Nachbarschaft) oder Phase der Gruppe (Beginn, Festigung, Niedergang).",
                     "dec": ("Haben die Kategorien eine Reihenfolge (niedrig, mittel, hoch) oder sind sie nur verschieden? Mit Reihenfolge "
                             "ORDERED, ohne ENUMERATED. Und beschreibt die Kategorie die ganze Quelle oder jeden Auszug?"),
                     "ask": ("Ich möchte im Projekt {proj} Gruppen von Quellen oder Auszügen vergleichen. Fragen Sie mich zuerst, welche "
                             "Gruppen ich vergleichen will und ob die Kategorien eine Reihenfolge haben. Stellen Sie dann Alternativen vor "
                             "und schlagen Sie ein Feld mit den Kategorien, der Definition jeder Kategorie und der Ebene vor, auf der es "
                             "ausgefüllt wird (ganze Quelle oder jeder Auszug).")},
            "chain": {"need": "Ich muss darstellen, wie die Quellen Konzepte oder andere Angaben verknüpfen.",
                      "ex": "Infrastruktur → ERMÖGLICHT → Gewohnheitswandel",
                      "dec": ("Die Kette hält die Verbindung fest; die Relationen (RELATIONS) legen die Bedeutung jeder erlaubten Verbindung "
                              "fest. Nutzen Sie die Kette, wenn die Quelle die Verbindung stützt. Ist die Verbindung Ihre eigene Hypothese, "
                              "vereinbaren Sie mit Claude, wie sie als Interpretation festgehalten wird, etwa in der Notiz."),
                      "ask": ("Ich möchte darstellen, wie die Quellen des Projekts {proj} Konzepte verknüpfen, zum Beispiel {q1} und {q2}. "
                              "Fragen Sie mich zuerst, welche Art von Verbindung mich interessiert und wie sich eine von der Quelle behauptete "
                              "Verbindung von meiner Interpretation unterscheiden lässt. Stellen Sie dann Alternativen vor und schlagen Sie "
                              "das Feld, die Relationen und Hinweise mit richtigen und falschen Beispielen vor.")},
            "rel": {"need": "Ich muss unterscheiden, auf welche verschiedenen Weisen Dinge zusammenhängen.",
                    "ex": "URSACHE (ein Faktor erzeugt einen anderen), BEDINGUNG (ein Faktor ermöglicht einen anderen), HEMMNIS (ein Faktor erschwert einen anderen).",
                    "dec": ("Wenige klar definierte Relationen vergleichen besser als viele ähnliche. Jede Relation braucht eine Definition, "
                            "ein Beispiel und einen Fall, in dem sie nicht gilt."),
                    "ask": ("Helfen Sie mir, die Relationen des Projekts {proj} zu überprüfen. Fragen Sie mich zuerst, welche Unterscheidungen "
                            "für meine Forschungsfragen wichtig sind. Schlagen Sie dann für jede Relation eine Definition, ein Beispiel und "
                            "einen Fall vor, in dem sie nicht verwendet werden soll.")},
            "code": {"need": "Ich muss Passagen zum selben Phänomen bündeln.",
                     "ex": "Alle Auszüge, die vom Aussteigen handeln, erhalten dasselbe Konzept, dessen Definition sagt, wann es gilt.",
                     "dec": ("Ein vorhandenes Konzept wiederverwenden oder ein neues anlegen? Ein neues Konzept braucht eine Definition mit "
                             "einem Kriterium, wann es gilt und wann nicht."),
                     "ask": ("Helfen Sie mir, Konzepte für die Auszüge des Projekts {proj} vorzuschlagen, und unterscheiden Sie dabei die schon "
                             "in der Ontologie vorhandenen von denen, die eine neue Definition brauchen. Schlagen Sie für jedes neue Konzept die "
                             "Definition vor, wann es gilt und wann nicht.")},
            "topic": {"need": "Ich muss Konzepte zu breiteren Themen zusammenfassen.",
                      "ex": "Wassermangel, unsicheres Grundstück und fehlende Mittel unter dem Thema «Hindernisse».",
                      "dec": "Ein Thema fasst Konzepte zusammen, ersetzt aber nicht die Definition jedes einzelnen. Wenige Themen helfen, das Ganze zu lesen.",
                      "ask": ("Helfen Sie mir zu überprüfen, wie die Konzepte des Projekts {proj} zu Themen zusammengefasst sind. Fragen Sie "
                              "mich zuerst, welche Gesamtlesart ich anstrebe. Schlagen Sie dann die Themen, die Konzepte jedes Themas und die "
                              "außen vor bleibenden vor.")},
            "quote": {"need": "Ich muss die Worte der Quelle bewahren und meine Interpretation entwickeln.",
                      "ex": "Der wörtlich kopierte Auszug und daneben eine Notiz, die sagt, warum er wichtig ist.",
                      "dec": ("Der Auszug ist der Beleg; die Notiz ist Ihre Lesart. Beides zu vermischen schwächt die Analyse. Ein Auszug, "
                              "der sich in der Quelle nicht findet, muss dorthin zurück."),
                      "ask": ("Ich möchte in den Annotationen des Projekts {proj} Beleg und Interpretation trennen. Prüfen Sie, ob die Auszüge "
                              "wörtliche Kopien der Quelle sind und ob die Notizen Interpretation statt Paraphrase enthalten. Zeigen Sie die "
                              "zu korrigierenden Fälle.")},
            "q": {"need": "Ich muss jede Annotation mit meinen Forschungsfragen verbinden.",
                  "ex": "Die Notiz endet mit (Q1), wenn der Auszug hilft, die erste Frage zu beantworten.",
                  "dec": "Die Frage in der Notiz zu nennen zeigt, wozu jeder Auszug dient, und macht Fragen mit wenig Belegen sichtbar.",
                  "ask": ("Ich möchte sehen, wie viele Belege das Projekt {proj} zu jeder Forschungsfrage ({qk}) sammelt. Zählen Sie die "
                          "Notizen, die jede Frage nennen, und weisen Sie auf Fragen mit wenig Belegen hin.")},
        },
        "here_fmt": {
            "scale_yes": "Dieses Projekt hat bereits eine Skala: {names}.",
            "scale_no": "Dieses Projekt hat noch keine Skala. Eine zu prüfende Möglichkeit: einstufen, wie stark jeder Auszug {q1} zeigt.",
            "scale_no2": "Dieses Projekt hat noch keine Skala. Eine zu prüfende Möglichkeit: einstufen, wie stark jeder Auszug {q1} oder {q2} zeigt.",
            "enum_yes": "Dieses Projekt hat bereits: {names}.",
            "enum_no": ("Die Quellen dieses Projekts werden durch {names} in freiem Text beschrieben. Um Quellen nach Kategorien zu "
                        "vergleichen, etwa nach Art der Quelle, hilft ein Feld mit fester Liste auf Ebene der Quelle."),
            "enum_nosrc": "Um Quellen nach Kategorien zu vergleichen, etwa nach Art der Quelle, hilft ein Feld mit fester Liste auf Ebene der Quelle.",
            "chain_yes": "Dieses Projekt hat bereits das Feld {names}, mit {n} festgehaltenen Ketten. Zum Beispiel:",
            "chain_no": "Dieses Projekt hält noch keine Verbindungen zwischen Konzepten fest.",
            "rel_yes": "Deklarierte Relationen und wie oft sie verwendet wurden: {decl}.",
            "rel_none": "Dieses Projekt deklariert noch keine Relationen.",
            "rel_undeclared": " Die Relation {rels} wurde ohne Deklaration verwendet: Entscheiden Sie, ob sie neu ist oder zu einer vorhandenen passt.",
            "code": "{n} Konzepte in der Ontologie definiert; {single} kommen nur in einer Quelle vor.",
            "code_undef": " Ohne Definition verwendet: {names}.",
            "topic_yes": "Die Konzepte sind in {n} Themen zusammengefasst: {groups}.",
            "topic_no": "Die Konzepte sind noch nicht zu Themen zusammengefasst.",
            "quote": "{found} von {total} Auszügen wurden in der Quelle gefunden.",
            "quote_nf": " {n} muss/müssen zur Prüfung zurück zur Quelle.",
            "q_yes": "{cite} von {memos} Notizen nennen eine Frage ({keys}).",
            "q_no": "Das Projekt hat noch keine deklarierten Forschungsfragen.",
        },
    },
)


# --------------------------------------------------------------------------- Italiano
add_language(
    "it",
    strings={
        "title": "Vista del progetto", "files": "File", "awaiting": "In attesa della tua accettazione",
        "awaiting_hint": "Scritto dal coder; entra nel progetto solo quando accetti l’esecuzione.",
        "project": "Progetto", "template": "Template", "ontology": "Ontologia", "annotations": "Annotazioni",
        "records": "Registri", "references": "Riferimenti", "search": "Cerca in tutti i file…",
        "code_lines": "Righe di codice", "theme": "Chiaro / scuro", "empty": "Ancora niente da mostrare.",
        "blocks": ("blocco", "blocchi"), "sources": ("fonte", "fonti"), "items": ("item", "item"),
        "concepts": ("concetto", "concetti"), "fields": ("campo", "campi"), "run": "esecuzione",
        "no_match": "Nessun blocco corrisponde alla ricerca.",
        "hint": "Vista in sola lettura dei file Synesis. Modifica i file, non questa pagina.",
        "correct": "Corretto", "wrong": "Sbagliato",
    },
    s={
        "problems": "Validazione e revisione", "all_clear": "Nessun problema: il progetto compila senza errori né avvisi.",
        "error": ("errore", "errori"), "warning": ("avviso", "avvisi"),
        "notfound": ("brano non trovato nella fonte", "brani non trovati nella fonte"),
        "edited": ("file modificato dopo l’accettazione", "file modificati dopo l’accettazione"),
        "pending": ("esecuzione in attesa di accettazione", "esecuzioni in attesa di accettazione"),
        "verified": "{n} brani su {t} trovati nella fonte",
        "line": "riga", "open_vs": "Apri in VS Code", "ask": "Chiedi a Claude", "ask_all": "Chiedi a Claude di risolvere tutto",
        "copied": "Richiesta copiata. Incollala nella conversazione con Claude.",
        "q_found": "brano trovato nella fonte", "q_notfound": "brano non trovato nella fonte",
        "q_unver": "fonte non disponibile per la verifica",
        "notfound_msg": ("Il brano non compare nella fonte @{ref}, nemmeno dopo aver uniformato virgolette, trattini e spazi. "
                         "Copialo alla lettera dalla fonte."),
        "accepted": "accettato nell’esecuzione {run} · {date}", "hand_edit": "modificato dopo l’accettazione",
        "hand_edit_file": "modificato dopo l’accettazione (esecuzione {run})", "new_block": "blocco nuovo, scritto a mano",
        "by_hand": "scritto a mano", "proposal": "proposto dall’esecuzione {run}",
        "edited_msg": "{n} blocco/i differiscono dal contenuto accettato nell’esecuzione {run}.",
        "undef": "Concetto senza definizione nell’ontologia.", "undef_hint": "Chiedi a Claude di proporre una definizione.",
        "uses": ("usato in {n} item", "usato in {n} item"), "goto_def": "vedi definizione",
        "rel_undef": "Relazione non dichiarata nel template per questo campo.", "declared_rel": "Relazioni dichiarate",
        "values": "Valori", "guidelines": "Indicazioni", "scope": "ambito",
        "legend": "Passa il mouse sulle parole in blu, sui nomi dei campi, sui concetti e sulle relazioni: compare una breve spiegazione.",
        "ask_fix": ("Nel progetto {proj}, il blocco {blk} in {file}, riga {line}, ha questi problemi:\n{lines}\n"
                    "Spiega ogni problema in parole semplici e proponi la correzione. Non modificare alcun file prima della mia approvazione."),
        "ask_review": ("Nel progetto {proj}, rivedi il blocco {blk} in {file}, riga {line}: verifica che i codici e la catena seguano le "
                       "indicazioni del template e che il brano sostenga la nota. Di’ cosa cambieresti, senza modificare il file."),
        "ask_pending": ("Sulla proposta dell’esecuzione {run} (blocco {blk}, riga {line}): spiega la scelta dei codici e della catena e di’ "
                        "se qualcosa dovrebbe cambiare prima che io la accetti. Non accettare l’esecuzione al posto mio."),
        "ask_all_text": ("Nel progetto {proj}, il pannello dei problemi mostra:\n{lines}\nRisolvili uno alla volta: spiega il problema, "
                         "proponi la correzione e attendi la mia approvazione prima di modificare ciascun file."),
        "sev": {"error": "errore", "warning": "avviso", "info": "info", "anchor": "brano", "edit": "modifica", "prop": "proposta"},
        "overview": "Panoramica", "questions": "Domande di ricerca", "t_sources": "fonti annotate", "t_items": "item",
        "t_concepts": "concetti nell’ontologia", "t_codes": "codici applicati", "t_chains": "catene",
        "t_quotes": "brani trovati nella fonte", "top_concepts": "Concetti più usati (n. di item)",
        "relations_used": "Occorrenze delle relazioni nelle catene", "unused": "Concetti non usati", "runs": "Esecuzioni del coder",
        "awaiting_short": "in attesa di accettazione", "th_run": "Esecuzione", "th_mode": "Modalità", "th_target": "Obiettivo",
        "th_status": "Stato", "th_date": "Data", "th_model": "Modello", "tpl_fields": "Campi del template", "th_field": "Campo",
        "th_scope": "Ambito", "th_type": "Tipo", "th_desc": "Descrizione",
        "q_note": "Confronto testuale con la fonte. Non convalida né l’interpretazione né la codifica.",
        "rel_invalid": "non dichiarata nel template", "sec_valid": "Validazione", "sec_changes": "Modifiche dopo l’accettazione",
        "sec_props": "Proposte da esaminare",
        "sec_valid_hint": "Errori e avvisi del compilatore e brani non trovati: vanno corretti.",
        "sec_changes_hint": "Differenze rispetto a quanto accettato: verifica che siano volute.",
        "sec_props_hint": "Scritto dal coder, non ancora nel progetto: accetta o rifiuta.",
        "none": "Niente da segnalare.", "prop_msg": "Esecuzione {run}: {files} proposto/i dal coder, non ancora nel progetto.",
        "see_occ": "vedi occorrenze", "occ_n": ("{n} occorrenza", "{n} occorrenze"), "in_src": "in @{s}", "go_block": "vai al blocco",
        "close": "Chiudi", "matrix": "Concetti per fonte (n. di item)",
        "matrix_hint": "Colore più intenso = più item. Fai clic su una cella per vedere le occorrenze.",
        "tech_on": "Dettagli tecnici: attivi", "tech_off": "Dettagli tecnici: disattivi", "tech": "dettagli tecnici",
        "found_n": ("{n} blocco trovato", "{n} blocchi trovati"),
        "short": {"MissingRequiredField": "In questo blocco manca il campo obbligatorio `{0}`.",
                  "InvalidChainRelation": "La relazione `{0}` non è dichiarata nel template per questo campo.",
                  "UndefinedCode": "Il codice `{0}` non ha una definizione nell’ontologia."},
        "short_fallback": "Problema di validazione ({code}). Vedi i dettagli tecnici.",
        "oc_diag": "{e} errore/i e {w} avviso/i in questo blocco", "sort_by": "Ordina per", "by_n": "n. di item",
        "by_ns": "n. di fonti", "by_name": "nome", "group": "Gruppo", "all": "tutti", "no_def": "senza definizione",
        "no_group": "(senza gruppo)",
        "matrix_hint2": "Include tutti i codici usati nelle annotazioni, anche quelli che non hanno ancora una definizione nell’ontologia.",
        "no_entry": "Usato nelle annotazioni; non ha una voce nell’ontologia, e il template non la richiede.",
        "compile_fail": ("Non è stato possibile compilare il progetto per questa pagina ({err}). I file sono mostrati, ma senza "
                         "validazione, concetti né aiuto sui campi. Chiedi a Claude di eseguire sk.py check."),
        "capped": "Sono mostrati i {r} concetti più frequenti (su {rt}) e le {c} fonti con più item (su {ct}).",
        "eyebrow": "Synesis · progetto di ricerca", "legend_n": "item per cella", "corpus": "Corpus",
        "help": "Come leggere questa pagina", "details": "vedi dettagli", "focus": "Concetto in primo piano",
        "dist": "Distribuzione per fonte", "see_all": ("Vedi l’occorrenza", "Vedi le {n} occorrenze"),
        "in_k": "{n} occorrenza/e in {k} fonti su {s}",
        "pick_hint": "Passa il mouse su una riga; fai clic su un concetto per fissarlo.",
        "scroll_hint": "scorri per vedere tutte le fonti →", "more": "Decisione metodologica e richiesta a Claude",
    },
    kw={
        "FIELD": "Crea un campo: una delle informazioni che registrerai nel progetto. Questo si chiama {f}.",
        "TYPE": "Indica che tipo di informazione contiene il campo {f}. Passa il mouse sul tipo accanto per vedere cosa significa.",
        "T:TEXT": "Testo libero, scritto da te, in una o più frasi.",
        "T:QUOTATION": "Un brano copiato parola per parola dalla fonte. È la prova: non si riassume né si corregge.",
        "T:MEMO": "Una tua nota interpretativa: perché il brano conta per la ricerca.",
        "T:CODE": "I concetti applicati al brano, separati da virgole. Ogni concetto ha bisogno di una definizione nell’ontologia.",
        "T:CHAIN": "Collega concetti tramite una relazione (concetto → RELAZIONE → concetto), quando è la fonte stessa ad affermare il legame.",
        "T:TOPIC": "Un tema ampio, che riunisce più concetti simili.",
        "T:ENUMERATED": "Un’opzione scelta da un elenco chiuso di valori.",
        "T:ORDERED": "Un’opzione scelta da un elenco ordinato, come basso, medio e alto.",
        "T:SCALE": "Un numero all’interno di un intervallo concordato.",
        "T:DATE": "Una data.",
        "SCOPE": "Indica dove si compila il campo {f}.",
        "SCOPE:SOURCE": "Il campo {f} si compila una volta per fonte (intervista, articolo, documento) e descrive la fonte nel suo insieme.",
        "SCOPE:ITEM": "Il campo {f} appartiene agli item: si compila per ogni brano che evidenzi in una fonte.",
        "SCOPE:ONTOLOGY": "Il campo {f} appartiene all’ontologia, il dizionario dei concetti del progetto: si compila per ogni concetto.",
        "GUIDELINES@G": ("Indicazioni scritte nel template su come compilare un campo, con esempi corretti e sbagliati. "
                         "Lì stanno i criteri di ogni livello o categoria."),
        "DESCRIPTION": "Dice in poche parole a cosa serve il campo {f}.",
        "DESCRIPTION@P": "Descrive il progetto in poche parole.",
        "GUIDELINES": ("Indicazioni su come compilare il campo {f}, con esempi di ciò che è giusto e di ciò che è sbagliato. "
                       "Chi codifica, tu o Claude, segue queste indicazioni."),
        "RELATIONS": "Le relazioni che possono collegare i concetti in questo campo, ciascuna con il suo significato. Si possono usare solo queste.",
        "VALUES": "Le opzioni ammesse in questo campo.",
        "ARITY": "Quanti concetti deve collegare la catena ({v}).",
        "REQUIRED": "Campi obbligatori: devono comparire in ogni blocco di questo tipo.",
        "OPTIONAL": "Campi facoltativi: si possono omettere quando non si applicano.",
        "BUNDLE": "Campi che vanno insieme, a coppie: il primo dell’uno con il primo dell’altro, e così via.",
        "SOURCE FIELDS": "I campi che descrivono ogni fonte nel suo insieme.",
        "ITEM FIELDS": "I campi di ogni item, cioè di ogni brano evidenziato in una fonte.",
        "ONTOLOGY FIELDS": "I campi di ogni concetto dell’ontologia.",
        "SOURCE": "Apre la scheda della fonte {v}. Il nome dopo la @ è lo stesso della bibliografia.",
        "ITEM": "Apre un item: un brano evidenziato nella fonte {v}, con la tua interpretazione e i concetti applicati.",
        "ONTOLOGY": "Apre la definizione del concetto {v}. Ogni concetto usato negli item ha bisogno di una definizione come questa.",
        "END": "Chiude il blocco {v} aperto più sopra. Tutto ciò che sta tra l’apertura e questa riga gli appartiene.",
        "PROJECT": "Apre il file del progetto: il suo nome e i file che ne fanno parte.",
        "TEMPLATE": "Il template: il file che definisce quali campi esistono e come compilarli.",
        "INCLUDE": "Include nel progetto un file o una cartella.",
        "BIBLIOGRAPHY": "I riferimenti delle fonti, come in una bibliografia.",
        "ANNOTATIONS": "Dove si trovano le annotazioni: le fonti e i brani evidenziati in esse.",
        "INC:ONTOLOGY": "Dove si trovano le definizioni dei concetti (l’ontologia).",
        "QUESTIONS": "Le domande di ricerca. Le note possono citarle, per esempio (Q1).",
        "EXPORT": "Produce una copia dei dati del progetto in un altro formato ({v}), da analizzare con altri strumenti.",
        "OUTPUT": "Dove verrà salvata la copia esportata.",
        "GENERATED_AT": "Una data fissa scritta nella copia esportata, perché risulti sempre identica.",
    },
    help_={
        "n_tips": ("1 suggerimento per iniziare", "{n} suggerimenti per iniziare"), "tab": "Da dove iniziare",
        "about": ("Questo è il progetto {name}: {src} fonti, {items} item e {conc} concetti. La pagina mostra solo i file; le modifiche "
                  "si fanno nei file o chiedendole a Claude nella conversazione."),
        "start_err": ("Inizia dalla validazione: ci sono {e} e così il progetto non compila. Apri {link} e usa «Chiedi a Claude» su "
                      "ogni problema."),
        "start_warn": "Ci sono {w} da rivedere in {link}.",
        "nf": "{n} non è stato trovato nella fonte: torna alla fonte e copialo alla lettera.",
        "pending": ("Una proposta del coder attende la tua decisione nella scheda {link}. Leggi le schede e di’ a Claude se accetti o "
                    "rifiuti l’esecuzione."),
        "edits": "{n} sono cambiati dopo l’accettazione. Verifica che i cambiamenti siano voluti.",
        "undef": ("Il codice {codes} non ha ancora una definizione nell’ontologia; Claude può proporne una.",
                  "I codici {codes} non hanno ancora una definizione nell’ontologia; Claude può proporle."),
        "clear": "Niente in sospeso: il progetto compila e tutti i brani sono stati trovati nelle fonti.",
        "explore": ("Per esplorare, usa la matrice {link}: fai clic su un concetto per metterlo in primo piano e su una cella per leggere "
                    "i brani di quella fonte. Il concetto più frequente è «{top}» ({n} item)."),
        "learn": ("Le parole in blu nei file (come SCOPE e END ITEM) si spiegano passandoci sopra con il mouse. La scheda {link} suggerisce "
                  "cos’altro registrare, con richieste pronte per Claude."),
        "review_link": "Validazione e revisione", "matrix_link": "Concetti per fonte",
        "err": ("1 errore", "{n} errori"), "warn": ("1 avviso", "{n} avvisi"), "q": ("1 brano", "{n} brani"),
        "files": ("1 file", "{n} file"),
    },
    links={
        "docs": "Documentazione", "github": "GitHub", "cite": "Come citare", "support_t": "Sostieni Synesis",
        "support": ("Synesis è software libero, fatto da ricercatori per ricercatori. Se ti aiuta nel lavoro, ci sono tre modi semplici "
                    "per ricambiare:"),
        "star": "Metti una stella su GitHub", "star_why": "aiuta altri ricercatori a trovare Synesis e mostra che viene usato.",
        "cite_why": "cita Synesis nelle pubblicazioni che lo hanno usato; è il riconoscimento che conta nella vita accademica.",
        "issue": "Raccontaci cosa non ha funzionato", "issue_why": "i resoconti d’uso reale orientano le prossime versioni.",
        "copy_cite": "Copia citazione (APA)", "copy_bib": "Copia BibTeX", "copied_cite": "Citazione copiata.",
        "copied_bib": "BibTeX copiato. Puoi incollarlo nel tuo file .bib.", "made": "Realizzato con Synesis",
    },
    tab_short={"pending": "In attesa", "poss": "Possibilità"},
    run_status={"accepted": "accettata", "stale": "superata", "rejected": "rifiutata"},
    guide={
        "tab": "Possibilità di ricerca", "sep": ", ", "some": "un fenomeno della ricerca",
        "intro": ("Parti da ciò che vuoi indagare, non dal nome di un campo. Ogni possibilità mostra un’esigenza, un esempio, la "
                  "decisione che richiede e la funzione di Synesis che la realizza. La richiesta si può copiare e adattare nella "
                  "conversazione con Claude: chiarirà la tua intenzione e presenterà alternative prima di proporre una struttura."),
        "goal": "Obiettivo: poter dire «voglio indagare questo; aiutami a registrarlo e analizzarlo», anche senza conoscere i nomi dei campi.",
        "example": "Esempio", "decision": "Decisione da prendere", "resource": "Funzione di Synesis", "here": "In questo progetto",
        "ask_label": "Richiesta da adattare", "copy": "Copia la richiesta da adattare",
        "tail": " Non modificare alcun file prima della mia approvazione.", "more": "Decisione metodologica e richiesta a Claude",
        "groups": {
            "compare": {"title": "Voglio confrontare", "lead": "Confrontare fonti, brani o gruppi richiede un criterio comune, registrato ovunque allo stesso modo."},
            "connect": {"title": "Voglio collegare", "lead": "I legami tra concetti mostrano meccanismi: cosa porta a cosa, cosa permette o impedisce cosa."},
            "organize": {"title": "Voglio comprendere e organizzare", "lead": "Concetti ben definiti riuniscono i passaggi su uno stesso fenomeno e rendono l’analisi verificabile."},
            "support": {"title": "Voglio sostenere la mia interpretazione", "lead": "Un’interpretazione convince quando si può tornare alla fonte e vedere da dove viene."},
        },
        "items": {
            "scale": {"need": "Ho bisogno di registrare intensità, grado o una valutazione come numero.",
                      "ex": "Quanta fiducia una persona esprime verso un’istituzione, da 1 (nessuna) a 5 (piena).",
                      "dec": ("Vuoi registrare il voto dato dalla fonte stessa o valutare tu l’intensità descritta nel brano? Sono "
                              "informazioni diverse e possono richiedere campi separati. In ogni caso, ogni livello ha bisogno di un "
                              "criterio scritto, perché la stessa situazione riceva sempre lo stesso numero."),
                      "ask": ("Voglio registrare un’intensità o un grado nelle annotazioni del progetto {proj}, per esempio quanto ogni brano "
                              "mostra {q1}. Prima di proporre qualcosa, fammi fino a tre domande per capire la mia intenzione, anche se il "
                              "numero viene dalla fonte o da me. Poi presenta alternative e proponi i livelli della scala, un criterio per "
                              "ogni livello e un esempio tratto dal progetto.")},
            "enum": {"need": "Ho bisogno di classificare fonti o brani in categorie fisse, per confrontare gruppi.",
                     "ex": "Tipo di partecipante (responsabile, volontario, vicino) o fase del gruppo (avvio, consolidamento, declino).",
                     "dec": ("Le categorie hanno un ordine (basso, medio, alto) o sono solo diverse tra loro? Con un ordine, usa ORDERED; "
                             "senza, ENUMERATED. E la categoria descrive l’intera fonte o ogni brano?"),
                     "ask": ("Voglio confrontare gruppi di fonti o di brani nel progetto {proj}. Chiedimi prima quali gruppi voglio confrontare "
                             "e se le categorie hanno un ordine. Poi presenta alternative e proponi un campo con le categorie, la definizione "
                             "di ciascuna e il livello in cui si compila (l’intera fonte o ogni brano).")},
            "chain": {"need": "Ho bisogno di rappresentare come le fonti collegano concetti o altre informazioni.",
                      "ex": "infrastruttura → ABILITA → cambiamento di abitudine",
                      "dec": ("La catena registra il collegamento; le relazioni (RELATIONS) definiscono il significato di ogni collegamento "
                              "ammesso. Usa la catena quando la fonte sostiene il legame. Se il collegamento è una tua ipotesi, concorda con "
                              "Claude un modo per registrarlo come interpretazione, per esempio nella nota."),
                      "ask": ("Voglio rappresentare come le fonti del progetto {proj} collegano concetti, per esempio {q1} e {q2}. Chiedimi "
                              "prima che tipo di collegamento mi interessa e come distinguere un collegamento affermato dalla fonte da uno che "
                              "è una mia interpretazione. Poi presenta alternative e proponi il campo, le relazioni e indicazioni con esempi "
                              "giusti e sbagliati.")},
            "rel": {"need": "Ho bisogno di distinguere i diversi modi in cui le cose si relazionano.",
                    "ex": "CAUSA (un fattore ne produce un altro), CONDIZIONE (un fattore ne rende possibile un altro), OSTACOLO (un fattore ne ostacola un altro).",
                    "dec": ("Poche relazioni ben definite confrontano meglio di molte simili. Ogni relazione ha bisogno di una definizione, "
                            "di un esempio e di un caso in cui non si applica."),
                    "ask": ("Aiutami a rivedere le relazioni del progetto {proj}. Chiedimi prima quali distinzioni contano per le mie domande "
                            "di ricerca. Poi proponi, per ogni relazione, una definizione, un esempio e un caso in cui non va usata.")},
            "code": {"need": "Ho bisogno di riunire i passaggi su uno stesso fenomeno.",
                     "ex": "Tutti i brani che parlano di abbandono ricevono lo stesso concetto, la cui definizione dice quando applicarlo.",
                     "dec": ("Riutilizzare un concetto esistente o crearne uno nuovo? Un concetto nuovo ha bisogno di una definizione, con un "
                             "criterio su quando applicarlo e quando no."),
                     "ask": ("Aiutami a proporre concetti per i brani del progetto {proj}, distinguendo quelli già presenti nell’ontologia da "
                             "quelli che richiedono una nuova definizione. Per ogni concetto nuovo, proponi la definizione, quando applicarlo "
                             "e quando no.")},
            "topic": {"need": "Ho bisogno di raggruppare i concetti in temi più ampi.",
                      "ex": "Mancanza d’acqua, terreno precario e mancanza di fondi riuniti nel tema «ostacoli».",
                      "dec": "Un tema riunisce concetti ma non sostituisce la definizione di ciascuno. Meglio pochi temi, che aiutino a leggere l’insieme.",
                      "ask": ("Aiutami a rivedere come i concetti del progetto {proj} sono raggruppati in temi. Chiedimi prima quale lettura "
                              "d’insieme voglio fare. Poi proponi i temi, i concetti di ciascuno e quelli che restano fuori.")},
            "quote": {"need": "Ho bisogno di conservare le parole della fonte e sviluppare la mia interpretazione.",
                      "ex": "Il brano copiato parola per parola e, accanto, una nota che dice perché conta.",
                      "dec": ("Il brano è la prova; la nota è la tua lettura. Mescolarli indebolisce l’analisi. Un brano che non si trova "
                              "nella fonte deve tornarci."),
                      "ask": ("Voglio separare prova e interpretazione nelle annotazioni del progetto {proj}. Verifica che i brani siano copie "
                              "letterali della fonte e che le note portino interpretazione, non parafrasi. Mostra i casi da correggere.")},
            "q": {"need": "Ho bisogno di collegare ogni annotazione alle mie domande di ricerca.",
                  "ex": "La nota termina con (Q1) quando il brano aiuta a rispondere alla prima domanda.",
                  "dec": "Citare la domanda nella nota mostra a cosa serve ogni brano e rivela le domande con poche prove.",
                  "ask": ("Voglio vedere quante prove il progetto {proj} raccoglie per ogni domanda di ricerca ({qk}). Conta le note che "
                          "citano ciascuna domanda e segnala le domande con poche prove.")},
        },
        "here_fmt": {
            "scale_yes": "Questo progetto ha già una scala: {names}.",
            "scale_no": "Questo progetto non ha ancora una scala. Una possibilità da valutare: graduare quanto ogni brano mostra {q1}.",
            "scale_no2": "Questo progetto non ha ancora una scala. Una possibilità da valutare: graduare quanto ogni brano mostra {q1} o {q2}.",
            "enum_yes": "Questo progetto ha già: {names}.",
            "enum_no": ("Le fonti di questo progetto sono descritte da {names}, in testo libero. Per confrontare le fonti per categoria, "
                        "come il tipo di fonte, servirebbe un campo a elenco chiuso a livello di fonte."),
            "enum_nosrc": "Per confrontare le fonti per categoria, come il tipo di fonte, servirebbe un campo a elenco chiuso a livello di fonte.",
            "chain_yes": "Questo progetto ha già il campo {names}, con {n} catene registrate. Per esempio:",
            "chain_no": "Questo progetto non registra ancora collegamenti tra concetti.",
            "rel_yes": "Relazioni dichiarate e quante volte sono state usate: {decl}.",
            "rel_none": "Questo progetto non dichiara ancora relazioni.",
            "rel_undeclared": " La relazione {rels} è stata usata senza essere dichiarata: conviene decidere se è nuova o rientra in una di quelle esistenti.",
            "code": "{n} concetti definiti nell’ontologia; {single} compaiono in una sola fonte.",
            "code_undef": " Usati senza definizione: {names}.",
            "topic_yes": "I concetti sono riuniti in {n} temi: {groups}.",
            "topic_no": "I concetti non sono ancora riuniti in temi.",
            "quote": "{found} brani su {total} sono stati trovati nella fonte.",
            "quote_nf": " {n} deve/devono tornare alla fonte per la verifica.",
            "q_yes": "{cite} note su {memos} citano una domanda ({keys}).",
            "q_no": "Il progetto non ha ancora domande di ricerca dichiarate.",
        },
    },
)


# --------------------------------------------------------------------------- 中文（简体）
add_language(
    "zh",
    strings={
        "title": "项目视图", "files": "文件", "awaiting": "等待您的接受",
        "awaiting_hint": "由 coder 写入；在您接受该次运行之前，不属于项目。",
        "project": "项目", "template": "模板", "ontology": "本体", "annotations": "标注",
        "records": "记录", "references": "参考文献", "search": "在所有文件中搜索…",
        "code_lines": "代码行", "theme": "浅色 / 深色", "empty": "暂无内容。",
        "blocks": ("个块", "个块"), "sources": ("个来源", "个来源"), "items": ("个条目", "个条目"),
        "concepts": ("个概念", "个概念"), "fields": ("个字段", "个字段"), "run": "运行",
        "no_match": "没有与搜索匹配的块。",
        "hint": "Synesis 文件的只读视图。请修改文件，而不是本页面。",
        "correct": "正确", "wrong": "错误",
    },
    s={
        "problems": "校验与审阅", "all_clear": "没有问题：项目编译时没有错误或警告。",
        "error": ("个错误", "个错误"), "warning": ("个警告", "个警告"),
        "notfound": ("段摘录未在来源中找到", "段摘录未在来源中找到"),
        "edited": ("个文件在接受后被修改", "个文件在接受后被修改"),
        "pending": ("次运行等待接受", "次运行等待接受"),
        "verified": "{t} 段摘录中有 {n} 段在来源中找到",
        "line": "行", "open_vs": "在 VS Code 中打开", "ask": "询问 Claude", "ask_all": "请 Claude 全部修复",
        "copied": "请求已复制。请粘贴到与 Claude 的对话中。",
        "q_found": "摘录已在来源中找到", "q_notfound": "摘录未在来源中找到", "q_unver": "无法获取来源进行核对",
        "notfound_msg": "即使统一了引号、破折号和空格，摘录仍未出现在来源 @{ref} 中。请从来源中逐字复制。",
        "accepted": "已在运行 {run} 中接受 · {date}", "hand_edit": "接受后已修改",
        "hand_edit_file": "接受后已修改（运行 {run}）", "new_block": "新块，手工编写",
        "by_hand": "手工编写", "proposal": "由运行 {run} 提议",
        "edited_msg": "有 {n} 个块与运行 {run} 中接受的内容不同。",
        "undef": "该概念在本体中没有定义。", "undef_hint": "请 Claude 提议一个定义。",
        "uses": ("用于 {n} 个条目", "用于 {n} 个条目"), "goto_def": "查看定义",
        "rel_undef": "该关系未在模板中为此字段声明。", "declared_rel": "已声明的关系",
        "values": "取值", "guidelines": "填写指引", "scope": "范围",
        "legend": "将鼠标悬停在蓝色词语、字段名、概念和关系上，会出现简短说明。",
        "ask_fix": ("在项目 {proj} 中，{file} 第 {line} 行的块 {blk} 有以下问题：\n{lines}\n"
                    "请用浅显的语言解释每个问题并提出修改方案。在我批准之前，不要修改任何文件。"),
        "ask_review": ("在项目 {proj} 中，请审阅 {file} 第 {line} 行的块 {blk}：检查代码和链是否符合模板的填写指引，摘录是否支持备注。"
                       "请说明您会修改什么，但不要编辑文件。"),
        "ask_pending": ("关于运行 {run} 的提议（块 {blk}，第 {line} 行）：请解释代码和链的选择，并说明在我接受之前是否需要修改。"
                        "不要替我接受这次运行。"),
        "ask_all_text": ("在项目 {proj} 中，问题面板显示：\n{lines}\n请逐一修复：解释问题，提出修改方案，并在修改每个文件前等待我的批准。"),
        "sev": {"error": "错误", "warning": "警告", "info": "信息", "anchor": "摘录", "edit": "修改", "prop": "提议"},
        "overview": "概览", "questions": "研究问题", "t_sources": "已标注来源", "t_items": "条目",
        "t_concepts": "本体中的概念", "t_codes": "已应用的代码", "t_chains": "链",
        "t_quotes": "在来源中找到的摘录", "top_concepts": "最常用的概念（条目数）",
        "relations_used": "关系在链中出现的次数", "unused": "未使用的概念", "runs": "coder 运行记录",
        "awaiting_short": "等待接受", "th_run": "运行", "th_mode": "模式", "th_target": "对象",
        "th_status": "状态", "th_date": "日期", "th_model": "模型", "tpl_fields": "模板字段", "th_field": "字段",
        "th_scope": "范围", "th_type": "类型", "th_desc": "说明",
        "q_note": "与来源的文本比对。它不验证解释或编码。",
        "rel_invalid": "未在模板中声明", "sec_valid": "校验", "sec_changes": "接受后的修改",
        "sec_props": "待审阅的提议",
        "sec_valid_hint": "编译器的错误和警告，以及未找到的摘录：需要修正。",
        "sec_changes_hint": "与已接受内容的差异：请确认是否为有意修改。",
        "sec_props_hint": "由 coder 写入，尚未进入项目：接受或拒绝。",
        "none": "没有需要报告的内容。", "prop_msg": "运行 {run}：coder 提议了 {files}，尚未进入项目。",
        "see_occ": "查看出现位置", "occ_n": ("{n} 处出现", "{n} 处出现"), "in_src": "在 @{s} 中", "go_block": "转到该块",
        "close": "关闭", "matrix": "按来源的概念（条目数）",
        "matrix_hint": "颜色越深，条目越多。点击单元格可查看出现位置。",
        "tech_on": "技术细节：显示", "tech_off": "技术细节：隐藏", "tech": "技术细节",
        "found_n": ("找到 {n} 个块", "找到 {n} 个块"),
        "short": {"MissingRequiredField": "此块缺少必填字段 `{0}`。",
                  "InvalidChainRelation": "关系 `{0}` 未在模板中为此字段声明。",
                  "UndefinedCode": "代码 `{0}` 在本体中没有定义。"},
        "short_fallback": "校验问题（{code}）。请查看技术细节。",
        "oc_diag": "此块中有 {e} 个错误和 {w} 个警告", "sort_by": "排序方式", "by_n": "条目数",
        "by_ns": "来源数", "by_name": "名称", "group": "分组", "all": "全部", "no_def": "无定义",
        "no_group": "（无分组）",
        "matrix_hint2": "包含标注中使用的所有代码，包括尚未在本体中定义的代码。",
        "no_entry": "出现在标注中；本体中没有对应条目，模板也不要求。",
        "compile_fail": "无法为本页面编译项目（{err}）。文件仍会显示，但没有校验、概念和字段帮助。请 Claude 运行 sk.py check。",
        "capped": "显示最常见的 {r} 个概念（共 {rt} 个）和条目最多的 {c} 个来源（共 {ct} 个）。",
        "eyebrow": "Synesis · 研究项目", "legend_n": "每个单元格的条目数", "corpus": "语料",
        "help": "如何阅读本页", "details": "查看详情", "focus": "当前概念", "dist": "按来源分布",
        "see_all": ("查看该处出现", "查看全部 {n} 处出现"), "in_k": "{n} 处出现，分布在 {s} 个来源中的 {k} 个",
        "pick_hint": "将鼠标悬停在某一行上；点击概念可将其固定。",
        "scroll_hint": "滑动以查看所有来源 →", "more": "方法论决定与给 Claude 的请求",
    },
    kw={
        "FIELD": "创建一个字段：您将在项目中记录的一项信息。此字段名为 {f}。",
        "TYPE": "说明字段 {f} 存放哪种信息。将鼠标悬停在旁边的类型上可查看其含义。",
        "T:TEXT": "由您撰写的自由文本，一句或多句。",
        "T:QUOTATION": "从来源中逐字复制的摘录。它是证据：不得概括或修改。",
        "T:MEMO": "您自己的解释性备注：说明该摘录为何对研究重要。",
        "T:CODE": "应用于该摘录的概念，用逗号分隔。每个概念都需要在本体中有定义。",
        "T:CHAIN": "当来源本身明确提出这种联系时，用一个关系连接概念（概念 → 关系 → 概念）。",
        "T:TOPIC": "一个较宽泛的主题，汇集若干相近的概念。",
        "T:ENUMERATED": "从固定的取值列表中选出的一个选项。",
        "T:ORDERED": "从有顺序的列表中选出的一个选项，例如低、中、高。",
        "T:SCALE": "约定范围内的一个数字。",
        "T:DATE": "一个日期。",
        "SCOPE": "说明字段 {f} 在哪里填写。",
        "SCOPE:SOURCE": "字段 {f} 每个来源（访谈、文章、文件）填写一次，用于整体描述该来源。",
        "SCOPE:ITEM": "字段 {f} 属于条目：您从来源中标出的每段摘录都要填写。",
        "SCOPE:ONTOLOGY": "字段 {f} 属于本体，即项目的概念词典：每个概念都要填写。",
        "GUIDELINES@G": "写在模板中的填写指引，附有正确和错误的示例。每个等级或类别的判断标准就写在这里。",
        "DESCRIPTION": "用几句话说明字段 {f} 的用途。",
        "DESCRIPTION@P": "用几句话描述项目。",
        "GUIDELINES": "字段 {f} 的填写指引，附有正确与错误的示例。无论由您还是 Claude 编码，都遵循这些指引。",
        "RELATIONS": "在此字段中可用于连接概念的关系，每个都有其含义。只能使用这些关系。",
        "VALUES": "此字段允许的选项。",
        "ARITY": "链必须连接的概念数量（{v}）。",
        "REQUIRED": "必填字段：此类每个块中都必须出现。",
        "OPTIONAL": "选填字段：不适用时可以省略。",
        "BUNDLE": "成对出现的字段：一个字段的第一项与另一个字段的第一项对应，依此类推。",
        "SOURCE FIELDS": "整体描述每个来源的字段。",
        "ITEM FIELDS": "每个条目的字段，即从来源中标出的每段摘录的字段。",
        "ONTOLOGY FIELDS": "本体中每个概念的字段。",
        "SOURCE": "打开来源 {v} 的记录。@ 后面的名称与参考文献中的相同。",
        "ITEM": "打开一个条目：从来源 {v} 中标出的一段摘录，附有您的解释和所应用的概念。",
        "ONTOLOGY": "打开概念 {v} 的定义。条目中使用的每个概念都需要这样的定义。",
        "END": "结束上方打开的 {v} 块。开头与这一行之间的所有内容都属于该块。",
        "PROJECT": "打开项目文件：项目名称以及属于项目的文件。",
        "TEMPLATE": "模板：定义有哪些字段以及如何填写的文件。",
        "INCLUDE": "将一个文件或文件夹纳入项目。",
        "BIBLIOGRAPHY": "来源的参考文献，如同参考文献列表。",
        "ANNOTATIONS": "标注所在之处：来源以及从中标出的摘录。",
        "INC:ONTOLOGY": "概念定义所在之处（本体）。",
        "QUESTIONS": "研究问题。备注中可以引用它们，例如 (Q1)。",
        "EXPORT": "以另一种格式（{v}）生成项目数据的副本，供其他工具分析。",
        "OUTPUT": "导出副本的保存位置。",
        "GENERATED_AT": "写入导出副本的固定日期，使其每次生成都完全相同。",
    },
    help_={
        "n_tips": ("1 条入门建议", "{n} 条入门建议"), "tab": "从哪里开始",
        "about": "这是项目 {name}：{src} 个来源、{items} 个条目和 {conc} 个概念。本页面只展示文件；修改需在文件中进行，或在对话中请 Claude 完成。",
        "start_err": "先处理校验：有 {e}，项目因此无法编译。请打开 {link}，并对每个问题使用「询问 Claude」。",
        "start_warn": "{link} 中有 {w} 需要查看。",
        "nf": "{n} 未在来源中找到：请回到来源并逐字复制。",
        "pending": "coder 的一项提议正在 {link} 标签页中等待您的决定。请阅读卡片，并告诉 Claude 您接受还是拒绝这次运行。",
        "edits": "{n} 在接受后发生了变化。请确认这些修改是有意的。",
        "undef": ("代码 {codes} 尚未在本体中定义；Claude 可以提议一个定义。",
                  "代码 {codes} 尚未在本体中定义；Claude 可以提议这些定义。"),
        "clear": "没有待处理事项：项目可以编译，所有摘录都已在来源中找到。",
        "explore": "要进行探索，请使用矩阵 {link}：点击概念可将其设为当前概念，点击单元格可阅读该来源的摘录。最常见的概念是「{top}」（{n} 个条目）。",
        "learn": "文件中的蓝色词语（如 SCOPE 和 END ITEM）在鼠标悬停时会显示说明。{link} 标签页建议还可以记录什么，并附有可直接交给 Claude 的请求。",
        "review_link": "校验与审阅", "matrix_link": "按来源的概念",
        "err": ("1 个错误", "{n} 个错误"), "warn": ("1 个警告", "{n} 个警告"), "q": ("1 段摘录", "{n} 段摘录"),
        "files": ("1 个文件", "{n} 个文件"),
    },
    links={
        "docs": "文档", "github": "GitHub", "cite": "如何引用", "support_t": "支持 Synesis",
        "support": "Synesis 是由研究者为研究者打造的自由软件。如果它对您的工作有帮助，有三种简单的回馈方式：",
        "star": "在 GitHub 上点星", "star_why": "这能帮助其他研究者找到 Synesis，并表明它正在被使用。",
        "cite_why": "在使用了 Synesis 的出版物中引用它；这是学术生活中真正重要的认可。",
        "issue": "告诉我们哪里不顺利", "issue_why": "真实使用中的反馈将指导后续版本。",
        "copy_cite": "复制引文（APA）", "copy_bib": "复制 BibTeX", "copied_cite": "引文已复制。",
        "copied_bib": "BibTeX 已复制。您可以将其粘贴到自己的 .bib 文件中。", "made": "使用 Synesis 制作",
    },
    tab_short={"pending": "等待接受", "poss": "研究可能性"},
    run_status={"accepted": "已接受", "stale": "已过期", "rejected": "已拒绝"},
    guide={
        "tab": "研究可能性", "sep": "、", "some": "研究中的某个现象",
        "intro": ("从您想研究的问题出发，而不是从字段名称出发。每种可能性都给出一个需求、一个示例、它所要求的决定，以及实现它的 "
                  "Synesis 功能。请求可以复制到与 Claude 的对话中并加以调整：Claude 会先澄清您的意图并给出备选方案，再提议结构。"),
        "goal": "目标：即使不知道字段名称，您也能说出“我想研究这个；请帮我记录并分析它”。",
        "example": "示例", "decision": "需要做出的决定", "resource": "Synesis 功能", "here": "在本项目中",
        "ask_label": "可调整的请求", "copy": "复制可调整的请求",
        "tail": " 在我批准之前，不要修改任何文件。", "more": "方法论决定与给 Claude 的请求",
        "groups": {
            "compare": {"title": "我想比较", "lead": "比较来源、摘录或群体，需要一个在各处以相同方式记录的共同标准。"},
            "connect": {"title": "我想建立联系", "lead": "概念之间的联系揭示机制：什么导致什么，什么促成或阻碍什么。"},
            "organize": {"title": "我想理解和整理", "lead": "定义清晰的概念能汇集关于同一现象的段落，并使分析可以复核。"},
            "support": {"title": "我想支撑我的解释", "lead": "当人们能回到来源、看到解释从何而来时，解释才有说服力。"},
        },
        "items": {
            "scale": {"need": "我需要用数字记录强度、程度或评价。",
                      "ex": "一个人对某机构表达的信任程度，从 1（完全没有）到 5（完全信任）。",
                      "dec": ("您是要记录来源本身给出的评分，还是由您来评定摘录所描述的强度？这是两种不同的信息，可能需要分开的字段。"
                              "无论哪种，每个等级都需要书面标准，使同一情形总是得到同一个数字。"),
                      "ask": ("我想在项目 {proj} 的标注中记录强度或程度，例如每段摘录在多大程度上体现了{q1}。在提出任何方案之前，请先问我最多三个问题，"
                              "以了解我的意图，包括这个数字是来自来源还是由我给出。然后给出备选方案，并提议量表的等级、每个等级的标准以及一个取自项目的示例。")},
            "enum": {"need": "我需要把来源或摘录归入固定类别，以便比较不同群体。",
                     "ex": "参与者类型（负责人、志愿者、邻居）或群体阶段（起步、巩固、衰退）。",
                     "dec": "这些类别有顺序（低、中、高）还是仅仅彼此不同？有顺序用 ORDERED；没有顺序用 ENUMERATED。类别描述的是整个来源还是每段摘录？",
                     "ask": ("我想在项目 {proj} 中比较不同的来源群体或摘录群体。请先问我想比较哪些群体，以及这些类别是否有顺序。"
                             "然后给出备选方案，并提议一个字段，包括类别、每个类别的定义以及填写的层级（整个来源或每段摘录）。")},
            "chain": {"need": "我需要表示来源如何把概念或其他信息联系起来。",
                      "ex": "基础设施 → 促成 → 习惯改变",
                      "dec": ("链记录联系；关系（RELATIONS）规定每种允许的联系的含义。当来源支持这一联系时使用链。如果联系是您自己的假设，"
                              "请与 Claude 商定一种把它作为解释来记录的方式，例如写在备注中。"),
                      "ask": ("我想表示项目 {proj} 的来源如何把概念联系起来，例如{q1}和{q2}。请先问我关心哪类联系，以及如何区分来源明确提出的联系与我的解释。"
                              "然后给出备选方案，并提议字段、关系以及附有正误示例的填写指引。")},
            "rel": {"need": "我需要区分事物之间不同的关联方式。",
                    "ex": "原因（一个因素产生另一个因素）、条件（一个因素使另一个成为可能）、制约（一个因素阻碍另一个）。",
                    "dec": "少数定义清晰的关系比许多相近的关系更便于比较。每种关系都需要定义、示例以及一个不适用的情形。",
                    "ask": ("请帮我审阅项目 {proj} 的关系。请先问我哪些区分对我的研究问题重要。然后为每种关系提议定义、示例以及一个不应使用它的情形。")},
            "code": {"need": "我需要汇集关于同一现象的段落。",
                     "ex": "所有谈到退出的摘录都使用同一个概念，其定义说明何时适用。",
                     "dec": "沿用已有概念还是新建一个？新概念需要一个定义，并说明何时适用、何时不适用。",
                     "ask": ("请帮我为项目 {proj} 的摘录提议概念，区分本体中已有的概念和需要新定义的概念。对每个新概念，请提议定义、何时适用以及何时不适用。")},
            "topic": {"need": "我需要把概念归入更宽泛的主题。",
                      "ex": "缺水、土地不稳定和资金不足归入「障碍」这一主题。",
                      "dec": "主题汇集概念，但不能取代各个概念的定义。宜少设主题，以帮助理解整体。",
                      "ask": ("请帮我审阅项目 {proj} 的概念是如何归入主题的。请先问我想做怎样的整体解读。然后提议主题、每个主题包含的概念以及未纳入的概念。")},
            "quote": {"need": "我需要保留来源的原话，并发展我的解释。",
                      "ex": "逐字复制的摘录，旁边是一条说明其为何重要的备注。",
                      "dec": "摘录是证据；备注是您的解读。把两者混在一起会削弱分析。在来源中找不到的摘录必须回到来源核对。",
                      "ask": ("我想在项目 {proj} 的标注中把证据与解释分开。请检查摘录是否为来源的逐字复制，备注是否提供了解释而不是转述。请列出需要修正的情况。")},
            "q": {"need": "我需要把每条标注与我的研究问题联系起来。",
                  "ex": "当摘录有助于回答第一个问题时，备注以 (Q1) 结尾。",
                  "dec": "在备注中注明问题，可以显示每段摘录的用途，并揭示证据不足的问题。",
                  "ask": ("我想了解项目 {proj} 为每个研究问题（{qk}）收集了多少证据。请统计引用每个问题的备注，并指出证据不足的问题。")},
        },
        "here_fmt": {
            "scale_yes": "本项目已有量表：{names}。",
            "scale_no": "本项目尚无量表。一种可考虑的做法：评定每段摘录在多大程度上体现了{q1}。",
            "scale_no2": "本项目尚无量表。一种可考虑的做法：评定每段摘录在多大程度上体现了{q1}或{q2}。",
            "enum_yes": "本项目已有：{names}。",
            "enum_no": "本项目的来源由{names}以自由文本描述。若要按类别（例如来源类型）比较来源，可在来源层级增加一个固定列表字段。",
            "enum_nosrc": "若要按类别（例如来源类型）比较来源，可在来源层级增加一个固定列表字段。",
            "chain_yes": "本项目已有字段{names}，记录了 {n} 条链。例如：",
            "chain_no": "本项目尚未记录概念之间的联系。",
            "rel_yes": "已声明的关系及其使用次数：{decl}。",
            "rel_none": "本项目尚未声明任何关系。",
            "rel_undeclared": "关系 {rels} 在未声明的情况下被使用：请决定它是新关系，还是可归入已有的某个关系。",
            "code": "本体中定义了 {n} 个概念；其中 {single} 个只出现在一个来源中。",
            "code_undef": "未定义而被使用的：{names}。",
            "topic_yes": "概念被归入 {n} 个主题：{groups}。",
            "topic_no": "概念尚未归入主题。",
            "quote": "{total} 段摘录中有 {found} 段在来源中找到。",
            "quote_nf": "有 {n} 段需要回到来源核对。",
            "q_yes": "{memos} 条备注中有 {cite} 条引用了研究问题（{keys}）。",
            "q_no": "本项目尚未声明研究问题。",
        },
    },
)
