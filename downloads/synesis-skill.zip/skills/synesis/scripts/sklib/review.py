# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Review of a sample of annotations: sample, page, export, import, report, corrections.

Practices of data validation that the review follows:

- the sample is drawn by the script, not chosen by the researcher: stratified by the groups of the
  project (sklib/sample.py), proportional allocation with at least one per group, a recorded seed;
- the sample is FROZEN: each annotation is stored as it was when drawn (its Synesis block, its
  values, the excerpt in its source), and the page shows that copy. If the project changes later,
  the page and the report say which annotations changed; judgements always refer to the copy;
- what the computer already checks (the excerpt is in the source: sk.py anchor) is shown as a seal
  and not asked; the researcher judges what only a person can: codes, chains, notes, categories;
- the judgement is blind to the model and the run that produced the annotation;
- one quick verdict per annotation (approved / rejected / doubt), an optional Likert rating per
  field, a reason mapped to the triage classes of SKILL.md section 5, a note, and optionally the
  block as the researcher thinks it should be (a proposed correction);
- each rater has a separate, initially empty session in the browser, so a second rater never
  inherits the first one's answers;
- the export is one Markdown file for the coordinator of the project: the answers, the proposed
  corrections, instructions for the AI that will read it, and the data for `--import`;
- the import refuses duplicated judgements and files of another sample;
- what the sample shows is the OBSERVED rate in the sample, with the Wilson interval of the sample;
  the groups are not weighted equally in the draw (at least one per group), so a rate for the whole
  project is given separately, weighted by group size, and without an interval;
- several raters on the same sample give percent agreement, Cohen's kappa (first two) and
  Krippendorff's alpha (nominal, any number of raters, missing values allowed).
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import html
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import anchor as anchor_mod
from . import runs as runs_mod
from . import sample as sampling
from .common import project_state, read_json, write_json
from .review_text import R, REASONS

DEFAULT_SIZE = 30            # 0 rejections in 30 -> below 10% with 95% confidence (rule of three)
CONTEXT_CHARS = 350
STOP_AFTER = 20              # stopping rule: after this many judged ...
STOP_SHARE = 0.25            # ... warn when at least this share is rejected
VERDICTS = ("approved", "rejected", "doubt")
JUDGED_TYPES = ("CODE", "CHAIN", "MEMO", "TEXT", "TOPIC", "ENUMERATED", "ORDERED", "SCALE", "DATE")
EXPORT_MARK = "<!-- synesis-review-data -->"
LANGUAGE_NAMES = {"en": "English", "pt": "Brazilian Portuguese", "es": "Spanish", "fr": "French",
                  "de": "German", "it": "Italian", "zh": "Simplified Chinese"}

# Read by any AI that receives an exported review or the consolidated corrections. English, like the
# rest of the Synesis tooling; the AI answers the coordinator in the language given.
AI_GUIDE = """You are helping the coordinator of a qualitative research project written in the Synesis
language (https://synesis-lang.org). This file comes from the review page of the Synesis plugin for
Claude (synesis-skill). Read these rules before you say or change anything.

1. What this is. Researchers judged a frozen sample of annotations (ITEM blocks) drawn at random
   from the project, stratified by group. Each annotation has a verdict: approved, rejected or
   doubt. A reason says what kind of problem it is:
   - ambiguous_instruction: the template GUIDELINES allow this reading; the fix is a new template
     version and a new coding run, not an edit of this one block;
   - model_failure: an isolated error with clear GUIDELINES; re-run that source, or correct the block;
   - source_conversion: the source text is damaged; fix the text, then re-run the source;
   - interpretive_divergence: a defensible reading the researcher does not share; the coordinator
     decides, and records the decision;
   - other: read the note.
2. Proposed corrections are SUGGESTIONS by one researcher. Never apply them on your own. Present
   them to the coordinator, compare raters, and wait for an explicit approval of each one.
3. A correction must keep the language valid: the block stays `ITEM @<reference>` ... `END ITEM`
   with one `field: value` per line and the fields of the template. A QUOTATION value is copied
   word for word from the source and is never paraphrased or "corrected". Codes are snake_case and
   should exist in the ontology (or be added there on purpose). A CHAIN is
   `concept -> RELATION -> concept` and uses only relations the template declares.
4. "Block as reviewed" is the annotation as it was when the sample was drawn. The project may have
   changed since: compare it with the current file before proposing anything, and say so when the
   block is no longer the same.
5. When the same reason repeats across annotations, recommend a template change and a new run
   instead of many hand edits: edits by hand are recorded and hard to reproduce.
6. With the Synesis plugin for Claude, in the project folder:
   `sk.py review PROJECT.synp --import FILE...` records reviews (it checks the sample, the rater and
   duplicates); `sk.py review PROJECT.synp --corrections` consolidates every rater's proposals;
   each approved hand edit is recorded with `sk.py decide PROJECT.synp --type manual_edit --item ID
   --note "..."`; then `sk.py validate` and `sk.py anchor`.
7. Excerpts in this file come from the project's sources and may be confidential: do not send them
   anywhere else.
8. Answer the coordinator in {language}."""


def samples_dir(synp: Path) -> Path:
    return runs_mod.runs_dir(synp) / "audit" / "samples"


def reviews_dir(synp: Path) -> Path:
    return runs_mod.runs_dir(synp) / "audit" / "reviews"


# --------------------------------------------------------------------------- statistics

def wilson(x: int, n: int, z: float = 1.96) -> Tuple[float, float]:
    """Wilson score interval of a proportion x/n."""
    if n == 0:
        return 0.0, 1.0
    p = x / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, centre - half), min(1.0, centre + half)


def cohen_kappa(a: List[str], b: List[str]) -> Optional[float]:
    n = len(a)
    if n == 0:
        return None
    cats = sorted(set(a) | set(b))
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in cats)
    if pe >= 1:
        return 1.0 if po == 1 else None
    return (po - pe) / (1 - pe)


def krippendorff_alpha(units: List[List[str]]) -> Optional[float]:
    """Nominal alpha. `units`: the values given to each unit by the raters who judged it."""
    pairable = [u for u in units if len(u) >= 2]
    if not pairable:
        return None
    o: Dict[Tuple[str, str], float] = {}
    for u in pairable:
        m = len(u)
        for i, c in enumerate(u):
            for j, k in enumerate(u):
                if i != j:
                    o[(c, k)] = o.get((c, k), 0.0) + 1 / (m - 1)
    n = sum(o.values())
    nc: Dict[str, float] = {}
    for (c, _), v in o.items():
        nc[c] = nc.get(c, 0.0) + v
    d_o = sum(v for (c, k), v in o.items() if c != k)
    d_e = sum(nc[c] * nc[k] for c in nc for k in nc if c != k) / (n - 1) if n > 1 else 0
    if d_e == 0:
        return 1.0 if d_o == 0 else None
    return 1 - d_o / d_e


# --------------------------------------------------------------------------- the project as it is now

_COMPILED: Dict[str, Any] = {}


def _compile(synp: Path) -> Dict[str, Any]:
    """Compile once per command: drawing the sample and writing its page read the same state."""
    from .project import compile_project

    key = str(synp)
    state = project_state(synp)["state"]
    hit = _COMPILED.get(key)
    if hit is None or hit["state"]["state"] != state:
        hit = _COMPILED[key] = compile_project(synp)
    return hit


def _fields(analytic: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    specs = ((analytic or {}).get("template") or {}).get("field_specs") or {}
    return {k: {"t": (v or {}).get("type", ""), "s": (v or {}).get("scope", ""),
                "d": ((v or {}).get("description") or "").strip()} for k, v in specs.items()}


def _strata(synp: Path, fields: Dict[str, Dict[str, Any]], strata: Optional[str]) -> Tuple[Dict[str, str], str]:
    """Source key -> group, read from the annotation files the project includes."""
    from . import view

    entries, _ = view.collect(synp)
    parsed = {e.label: view.parse(e.path.read_text(encoding="utf-8", errors="replace"))
              for e in entries if e.group == "annotations"}
    types = {k: v.get("t", "") for k, v in fields.items()}
    us, rule = sampling.units(parsed, types, fields, strata)
    return {k: u.stratum for k, u in us.items()}, rule


def block_text(base: Path, rel: Optional[str], line: Optional[int]) -> Optional[str]:
    """The Synesis text of the block that starts at `rel`:`line` (ITEM ... END ITEM), or None."""
    from . import view

    if not rel or not line:
        return None
    p = base / rel
    if not p.is_file():
        return None
    text = p.read_text(encoding="utf-8", errors="replace").replace("\r\n", "\n")
    for n in view.parse(text):
        if n.kind == "block" and n.line == line:
            lines = text.split("\n")
            return "\n".join(lines[line - 1:(n.end_line or line)]).rstrip()
    return None


def _context(text: str, excerpt: str) -> Optional[List[str]]:
    hay = anchor_mod.normalize(text)
    needle = anchor_mod.normalize(anchor_mod._strip_outer_quotes(excerpt))
    i = hay.find(needle) if needle else -1
    if i < 0:
        return None
    a, b = max(0, i - CONTEXT_CHARS), min(len(hay), i + len(needle) + CONTEXT_CHARS)
    return [("…" if a else "") + hay[a:i], needle, hay[i + len(needle):b] + ("…" if b < len(hay) else "")]


def _snapshot(synp: Path, comp: Dict[str, Any], chosen: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Everything the page shows about each annotation, as it is now (frozen with the sample)."""
    base = synp.parent
    analytic = comp["analytic"] or {}
    fields = _fields(analytic)
    item_fields = [k for k, v in fields.items() if v["s"] == "ITEM"]
    by_id = {it.get("id"): it for it in analytic.get("corpus") or []}
    anc = anchor_mod.check(base, analytic, comp["state"]["state"])
    status = {(r["item"], r["field"], r["occurrence"]): r["status"] for r in anc["results"]}
    by_file = anchor_mod.run_sources(base)
    fallback = anchor_mod.source_texts(base, analytic)
    items = []
    for p in chosen:
        it = by_id[p["id"]]
        ref = str(it.get("source_ref", "")).lstrip("@")
        src = (by_file.get(p["file"] or "") or {}).get(anchor_mod._ref_key(ref)) or fallback.get(anchor_mod._ref_key(ref))
        vals = []
        for name in item_fields:
            raw = (it.get("data") or {}).get(name)
            if raw in (None, "", []):
                continue
            t = fields[name]["t"]
            values = raw if isinstance(raw, list) else [raw]
            if t == "QUOTATION":
                for i, v in enumerate(values):
                    vals.append({"n": name, "t": t, "v": str(v), "st": status.get((p["id"], name, i), "unverifiable"),
                                 "ctx": _context(src["text"], str(v)) if src else None})
            elif t == "CHAIN":
                vals.append({"n": name, "t": t, "v": [[str(x.get("from", "")), str(x.get("relation", "")), str(x.get("to", ""))]
                                                      if isinstance(x, dict) else [str(x), "", ""] for x in values]})
            elif t == "CODE":
                vals.append({"n": name, "t": t, "v": [str(x) for x in values]})
            else:
                vals.append({"n": name, "t": t, "v": "; ".join(str(x) for x in values)})
        items.append({"id": p["id"], "src": ref, "g": p["group"], "f": p["file"], "l": p["line"],
                      "block": block_text(base, p["file"], p["line"]) or "", "vals": vals,
                      "source_sha": hashlib.sha256(src["text"].encode("utf-8")).hexdigest() if src else None})
    return {"fields": {k: fields[k] for k in item_fields},
            "likert": [k for k in item_fields if fields[k]["t"] in JUDGED_TYPES], "items": items}


def changed_items(synp: Path, rec: Dict[str, Any]) -> List[str]:
    """Ids of sampled annotations whose block is no longer the same in the project."""
    base = Path(synp).resolve().parent
    return [it["id"] for it in rec["snapshot"]["items"]
            if (block_text(base, it["f"], it["l"]) or "") != it["block"]]


# --------------------------------------------------------------------------- sample

def draw(synp: Path, size: int = DEFAULT_SIZE, seed: int = sampling.DEFAULT_SEED, focus: Optional[str] = None,
         strata: Optional[str] = None) -> Dict[str, Any]:
    """Draw and freeze a sample of annotations (ITEMs). Returns the sample record."""
    import random

    synp = Path(synp).resolve()
    comp = _compile(synp)
    analytic = comp["analytic"] or {}
    fields = _fields(analytic)
    group_of, rule = _strata(synp, fields, strata)
    pop = []
    f = (focus or "").strip().lstrip("@").casefold()
    for it in analytic.get("corpus") or []:
        key = str(it.get("source_ref", "")).lstrip("@").casefold()
        grp = group_of.get(key, "")
        if f:
            concepts = set()
            for name, spec in fields.items():
                if spec["s"] == "ITEM" and spec["t"] in ("CODE", "CHAIN"):
                    raw = (it.get("data") or {}).get(name)
                    for v in (raw if isinstance(raw, list) else [raw]):
                        if isinstance(v, dict):
                            concepts.update(str(v.get(x, "")).casefold() for x in ("from", "to"))
                        elif v:
                            concepts.add(str(v).casefold())
            if f not in (key, grp.casefold(), Path(grp).name.casefold()) and f not in concepts:
                continue
        tr = it.get("traceability") or {}
        pop.append({"id": it.get("id"), "source": key, "group": grp, "file": tr.get("file"), "line": tr.get("line")})
    by: Dict[str, List[Dict[str, Any]]] = {}
    for p in pop:
        by.setdefault(p["group"], []).append(p)
    sizes = {g: len(v) for g, v in by.items()}
    has_groups = len([g for g in by if g]) >= 2
    take = sampling.allocate(sizes, size, 1 if has_groups else 0)
    chosen: List[Dict[str, Any]] = []
    for g, k in take.items():
        ids = set(sampling._draw([p["id"] for p in by[g]], k, seed, "review|" + g))
        chosen += [p for p in by[g] if p["id"] in ids]
    order = sorted(p["id"] for p in chosen)            # judged in a random order: groups and files mixed
    random.Random(f"{seed}|order").shuffle(order)
    pos = {i: n for n, i in enumerate(order)}
    chosen.sort(key=lambda p: pos[p["id"]])
    today = _dt.date.today().isoformat()
    sid = f"{today.replace('-', '')}-n{len(chosen)}-s{seed}"
    d = samples_dir(synp)
    k = 2
    while (d / f"{sid}.json").exists():
        sid = f"{today.replace('-', '')}-n{len(chosen)}-s{seed}-{k}"
        k += 1
    record = {
        "kind": "synesis-skill/review-sample", "id": sid, "project": synp.stem,
        "state": comp["state"]["state"], "created_on": today, "seed": seed, "size": size,
        "focus": focus or "", "groups_rule": rule,
        "groups": {g: [take.get(g, 0), sizes[g]] for g in sorted(sizes, key=lambda g: (-sizes[g], g))},
        "population": len(pop), "items": chosen,
        "snapshot": _snapshot(synp, comp, chosen),
    }
    write_json(d / f"{sid}.json", record)
    runs_mod.decide(synp, "review_sample", note=f"sample {sid}: {len(chosen)} of {len(pop)} annotations",
                    sample=sid)
    return record


def load_sample(synp: Path, sample_id: Optional[str] = None) -> Dict[str, Any]:
    d = samples_dir(synp)
    files = sorted(d.glob("*.json")) if d.is_dir() else []
    if sample_id:
        files = [p for p in files if p.stem == sample_id]
    if not files:
        raise SystemExit(f"error: no review sample {sample_id or ''} in {d}")
    rec = read_json(files[-1])
    if "snapshot" not in rec:
        raise SystemExit(f"error: sample {rec.get('id')} was drawn by an older version without a frozen copy; "
                         "draw a new sample")
    return rec


# --------------------------------------------------------------------------- page

def page_data(synp: Path, rec: Dict[str, Any], language: str = "English") -> Dict[str, Any]:
    """What the page shows: the frozen copy of the sample, and what changed in the project since."""
    synp = Path(synp).resolve()
    snap = rec["snapshot"]
    changed = set(changed_items(synp, rec))
    items = [dict(it, changed=1) if it["id"] in changed else dict(it) for it in snap["items"]]
    for it in items:
        it.pop("source_sha", None)
    return {"sample": rec["id"], "project": rec["project"], "state": rec["state"], "seed": rec["seed"],
            "population": rec["population"], "groups": rec["groups"], "items": items,
            "likert": snap["likert"], "fields": snap["fields"], "reasons": list(REASONS),
            "stop": [STOP_AFTER, STOP_SHARE],
            "project_changed": project_state(synp)["state"] != rec["state"],
            "ai": AI_GUIDE.replace("{language}", language)}


def build_page(synp: Path, rec: Dict[str, Any], lang: str, out_dir: Optional[Path] = None) -> Path:
    import os

    from . import view

    synp = Path(synp).resolve()
    out = Path(out_dir).resolve() if out_dir else synp.parent / "review"
    out.mkdir(parents=True, exist_ok=True)
    meta = view.LANGS.get(lang) or view.LANGS["en"]
    data = page_data(synp, rec, LANGUAGE_NAMES.get(lang, "English"))
    t = R.get(lang) or R["en"]
    try:
        base = Path(os.path.relpath(synp.parent, out)).as_posix()
    except ValueError:
        base = synp.parent.as_uri()
    payload = json.dumps({"d": data, "t": t}, ensure_ascii=False).replace("<", "\\u003c")
    page = (PAGE.replace("__LANG__", html.escape(meta["html"]))
            .replace("__TITLE__", html.escape(f'{t["title"]} · {rec["project"]}'))
            .replace("__BASE__", html.escape(base)).replace("__DATA__", payload))
    target = out / "index.html"
    target.write_text(page, encoding="utf-8", newline="\n")
    return target


# --------------------------------------------------------------------------- import

def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_") or "rater"


def read_export(path: Path) -> Dict[str, Any]:
    """A review exported by the page: the Markdown file (data block after EXPORT_MARK) or plain JSON."""
    text = Path(path).read_text(encoding="utf-8")
    if text.lstrip().startswith("{"):
        return json.loads(text)
    i = text.find(EXPORT_MARK)
    m = re.search(r"```json\s*\n(.*?)\n```", text[i:], re.S) if i >= 0 else None
    if not m:
        raise SystemExit(f"error: {Path(path).name} has no review data (was it exported by the review page?)")
    return json.loads(m.group(1))


def import_review(synp: Path, path: Path) -> Dict[str, Any]:
    data = read_export(path)
    if data.get("kind") != "synesis-skill/review":
        raise SystemExit("error: not a review file exported by the review page")
    rec = load_sample(synp, data.get("sample"))
    if data.get("sample") != rec["id"]:
        raise SystemExit(f"error: the file is for sample {data.get('sample')}, not found in this project")
    ids = {p["id"] for p in rec["items"]}
    raw = data.get("judgments") or []
    seen: Dict[str, int] = {}
    for j in raw:
        seen[j.get("item")] = seen.get(j.get("item"), 0) + 1
    dup = sorted(k for k, n in seen.items() if n > 1)
    if dup:
        raise SystemExit(f"error: {len(dup)} annotations are judged more than once in this file (e.g. {dup[0]}); "
                         "nothing was imported")
    unknown = [j for j in raw if j.get("item") not in ids]
    bad = [j for j in raw if j.get("item") in ids and j.get("verdict") not in VERDICTS]
    if unknown or bad:
        raise SystemExit(f"error: {len(unknown)} judgements of annotations outside the sample and {len(bad)} without a "
                         "valid verdict; nothing was imported")
    rater = (data.get("rater") or "").strip() or "rater"
    blocks = {it["id"]: it["block"] for it in rec["snapshot"]["items"]}
    clean = {"kind": "synesis-skill/review", "sample": rec["id"], "project": rec["project"], "rater": rater,
             "exported_on": data.get("exported_on"),
             "judgments": sorted(({**{k: j.get(k) for k in ("item", "verdict", "likert", "reason", "note")},
                                  "proposal": (j.get("proposal") or "").strip()
                                  if (j.get("proposal") or "").strip() != blocks.get(j["item"], "").strip() else ""}
                                  for j in raw), key=lambda j: str(j["item"]))}
    target = reviews_dir(synp) / f"{rec['id']}--{_slug(rater)}.json"
    replaced = target.exists()
    write_json(target, clean)
    runs_mod.decide(synp, "import_review", note=f"review of sample {rec['id']} by {rater}: "
                    f"{len(raw)} of {len(rec['items'])} judged"
                    + (f", {sum(1 for j in clean['judgments'] if j['proposal'])} corrections proposed" if raw else "")
                    + (" (replaces an earlier import of this rater)" if replaced else ""),
                    sample=rec["id"], file=target.relative_to(Path(synp).resolve().parent).as_posix())
    clean["replaced"] = replaced
    return clean


# --------------------------------------------------------------------------- report

def _raters(synp: Path, sample_id: str) -> List[Dict[str, Any]]:
    d = reviews_dir(synp)
    return [read_json(p) for p in sorted(d.glob(f"{sample_id}--*.json"))] if d.is_dir() else []


def report(synp: Path, sample_id: Optional[str] = None) -> Dict[str, Any]:
    """Counts, rates, reasons, proposals and agreement for one sample (the latest by default)."""
    rec = load_sample(synp, sample_id)
    raters = _raters(synp, rec["id"])
    changed = changed_items(synp, rec)
    out: Dict[str, Any] = {"sample": rec["id"], "size": len(rec["items"]), "population": rec["population"],
                           "groups": rec["groups"], "changed_since_draw": len(changed), "raters": []}
    group_of = {p["id"]: p["group"] for p in rec["items"]}
    for r in raters:
        js = r["judgments"]
        c = {v: sum(j["verdict"] == v for j in js) for v in VERDICTS}
        decided = c["approved"] + c["rejected"]
        lo, hi = wilson(c["rejected"], decided)
        by_group: Dict[str, Dict[str, int]] = {}
        for j in js:
            g = by_group.setdefault(group_of.get(j["item"], ""), {v: 0 for v in VERDICTS})
            g[j["verdict"]] += 1
        # weighted by group size: each group's observed rate counts as much as the group weighs
        num = den = 0.0
        for g, v in by_group.items():
            dec = v["approved"] + v["rejected"]
            if dec:
                size = (rec["groups"].get(g) or [0, 0])[1]
                num += size * v["rejected"] / dec
                den += size
        reasons: Dict[str, int] = {}
        for j in js:
            if j["verdict"] != "approved" and j.get("reason"):
                reasons[j["reason"]] = reasons.get(j["reason"], 0) + 1
        likert: Dict[str, List[int]] = {}
        for j in js:
            for f, v in (j.get("likert") or {}).items():
                if isinstance(v, int) and 1 <= v <= 5:
                    likert.setdefault(f, []).append(v)
        out["raters"].append({
            "rater": r["rater"], "judged": len(js), "counts": c,
            "observed_rejection_rate": round(c["rejected"] / decided, 3) if decided else None,
            "sample_wilson95": [round(lo, 3), round(hi, 3)] if decided else None,
            "rule_of_three": round(min(1.0, 3 / decided), 3) if decided and not c["rejected"] else None,
            "weighted_rejection_rate": round(num / den, 3) if den and len(by_group) > 1 else None,
            "by_group": by_group, "reasons": reasons,
            "proposals": sum(1 for j in js if j.get("proposal")),
            "likert_mean": {f: round(sum(v) / len(v), 2) for f, v in likert.items()},
            "judged_changed_since_draw": sum(1 for j in js if j["item"] in set(changed)),
        })
    if len(raters) >= 2:
        verdicts = [{j["item"]: j["verdict"] for j in r["judgments"]} for r in raters]
        common = sorted(set.intersection(*(set(v) for v in verdicts)))
        a = [verdicts[0][i] for i in common]
        b = [verdicts[1][i] for i in common]
        units = [[v[i] for v in verdicts if i in v] for i in sorted(set().union(*verdicts))]
        out["agreement"] = {
            "items_in_common": len(common),
            "percent": round(sum(x == y for x, y in zip(a, b)) / len(common), 3) if common else None,
            "cohen_kappa_first_two": None if (k := cohen_kappa(a, b)) is None else round(k, 3),
            "krippendorff_alpha": None if (al := krippendorff_alpha(units)) is None else round(al, 3),
        }
    return out


# --------------------------------------------------------------------------- corrections, for the coordinator

def corrections(synp: Path, sample_id: Optional[str] = None, language: str = "English",
                out_dir: Optional[Path] = None) -> Tuple[Path, Dict[str, int]]:
    """One Markdown file with every rater's verdicts and proposed corrections, item by item, with the
    instructions for the AI of the coordinator. Nothing in the project is changed."""
    synp = Path(synp).resolve()
    rec = load_sample(synp, sample_id)
    raters = _raters(synp, rec["id"])
    if not raters:
        raise SystemExit(f"error: no review of sample {rec['id']} imported yet (sk.py review --import FILE)")
    changed = set(changed_items(synp, rec))
    base = synp.parent
    lines = [f"# Synesis review — consolidated corrections for the coordinator", "",
             f"Project: {rec['project']} · sample: {rec['id']} ({len(rec['items'])} of {rec['population']} annotations) · "
             f"raters: {', '.join(r['rater'] for r in raters)}", "",
             "## Instructions for the AI that reads this file", "", AI_GUIDE.replace("{language}", language), "",
             "## Annotations with a rejection, a doubt or a proposed correction", ""]
    n = {"items": 0, "proposals": 0, "disagreements": 0, "changed": 0}
    by_item = {it["id"]: it for it in rec["snapshot"]["items"]}
    for p in rec["items"]:
        js = [(r["rater"], j) for r in raters for j in r["judgments"] if j["item"] == p["id"]]
        flagged = [x for x in js if x[1]["verdict"] != "approved" or x[1].get("proposal")]
        if not flagged:
            continue
        n["items"] += 1
        it = by_item[p["id"]]
        disagree = len({j["verdict"] for _, j in js}) > 1
        n["disagreements"] += disagree
        lines += [f"### {p['id']} — @{it['src']}" + (f" ({it['g']})" if it["g"] else "") + f" — {it['f']}:{it['l']}", ""]
        if disagree:
            lines += ["**The raters disagree.**", ""]
        for rater, j in js:
            lines.append(f"- **{rater}**: {j['verdict']}" + (f" — reason: {j['reason']}" if j.get("reason") else "")
                         + (f" — note: {j['note']}" if j.get("note") else ""))
        lines += ["", "Block as reviewed:", "", "```synesis", it["block"], "```", ""]
        if p["id"] in changed:
            n["changed"] += 1
            now = block_text(base, it["f"], it["l"])
            lines += ["**This block changed in the project after the sample was drawn.** Current block:", "",
                      "```synesis", now or "(no block at this place any more)", "```", ""]
        for rater, j in js:
            if j.get("proposal"):
                n["proposals"] += 1
                lines += [f"Correction proposed by {rater}:", "", "```synesis", j["proposal"], "```", ""]
    if not n["items"]:
        lines += ["Every judged annotation was approved, and no correction was proposed.", ""]
    out = Path(out_dir).resolve() if out_dir else base / "review"
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"corrections-{rec['id']}.md"
    target.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return target, n


# --------------------------------------------------------------------------- page template

PAGE = r"""<!doctype html>
<html lang="__LANG__"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--ink:#1d2733;--muted:#5d6b7a;--line:#dde3ea;--accent:#006d77;--accent-ink:#fff;
--ok:#1f7a4d;--bad:#b42318;--doubt:#9a6700;--mark:#fff3bf;--chip:#eef3f6;
--font:"IBM Plex Sans",system-ui,-apple-system,"Segoe UI",sans-serif;--serif:"IBM Plex Serif",Georgia,serif;--mono:"IBM Plex Mono",ui-monospace,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0f1720;--panel:#16212c;--ink:#e6edf3;--muted:#9fb0c0;--line:#2a3846;--accent:#5fb3bb;--accent-ink:#0f1720;
--ok:#6fcf97;--bad:#f28b82;--doubt:#e3b341;--mark:#4a3f12;--chip:#1e2c39}}
:root[data-theme="dark"]{--bg:#0f1720;--panel:#16212c;--ink:#e6edf3;--muted:#9fb0c0;--line:#2a3846;--accent:#5fb3bb;--accent-ink:#0f1720;
--ok:#6fcf97;--bad:#f28b82;--doubt:#e3b341;--mark:#4a3f12;--chip:#1e2c39}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 var(--font)}
header{position:sticky;top:0;z-index:5;background:var(--panel);border-bottom:1px solid var(--line);padding:10px 16px;display:flex;flex-wrap:wrap;gap:10px;align-items:center}
header h1{font-size:17px;margin:0 12px 0 0}header .sub{color:var(--muted);font-size:13px}
.bar{flex:1;min-width:160px;height:8px;background:var(--chip);border-radius:4px;overflow:hidden}.bar i{display:block;height:100%;background:var(--accent)}
.prog{font-size:13px;color:var(--muted);white-space:nowrap}
button,select,input,textarea{font:inherit;color:inherit}
.btn{border:1px solid var(--line);background:var(--panel);border-radius:8px;padding:6px 12px;cursor:pointer}
.btn:hover{border-color:var(--accent)}.btn.pri{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
main{display:grid;grid-template-columns:260px minmax(0,1fr);gap:16px;max-width:1240px;margin:0 auto;padding:16px}
@media (max-width:860px){main{grid-template-columns:minmax(0,1fr)}aside.list{order:2}}
aside.list{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px;align-self:start;position:sticky;top:76px;max-height:calc(100vh - 96px);overflow:auto}
@media (max-width:860px){aside.list{position:static;max-height:none}}
.list .f{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px}.list .f button{font-size:12px;padding:3px 8px}
.list .f button.on{border-color:var(--accent);color:var(--accent)}
.li{display:flex;gap:8px;align-items:center;width:100%;text-align:left;border:0;background:none;padding:5px 6px;border-radius:6px;cursor:pointer;font-size:13px}
.li:hover,.li.cur{background:var(--chip)}.dot{width:10px;height:10px;border-radius:50%;border:1.5px solid var(--muted);flex:none}
.dot.approved{background:var(--ok);border-color:var(--ok)}.dot.rejected{background:var(--bad);border-color:var(--bad)}.dot.doubt{background:var(--doubt);border-color:var(--doubt)}
.li span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.li .pen{margin-left:auto;color:var(--accent)}
section.card,.intro{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:18px 20px;margin-bottom:16px}
.intro p{margin:6px 0}.intro ul{margin:6px 0 0 18px;padding:0;color:var(--muted);font-size:14px}.muted{color:var(--muted)}.small{font-size:13px}
.meta{display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-size:13px;color:var(--muted);margin-bottom:10px}
.meta a{color:var(--accent)}.chip{display:inline-block;background:var(--chip);border-radius:999px;padding:1px 10px;font-size:13px;margin:2px 4px 2px 0}
.fld{margin:12px 0}.fn{font:12px var(--mono);color:var(--muted);margin-bottom:2px}
blockquote{margin:0;padding:6px 14px;border-left:3px solid var(--accent);font-family:var(--serif);font-size:17px}
.seal{font-size:12px;margin-top:4px}.seal.found{color:var(--ok)}.seal.not_found{color:var(--bad)}.seal.unverifiable{color:var(--doubt)}
details.ctx{margin-top:6px;font-size:14px}details.ctx div{margin-top:6px;padding:10px;background:var(--bg);border-radius:8px;font-family:var(--serif);line-height:1.6}
mark{background:var(--mark);color:inherit;padding:0 2px}
.chain{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:3px 0}.rel{font:12px var(--mono);color:var(--muted)}
.verdict{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
.verdict button{flex:1;min-width:120px;padding:12px;border-radius:10px;border:2px solid var(--line);background:var(--panel);cursor:pointer;font-weight:600}
.verdict button kbd{font:11px var(--mono);color:var(--muted);margin-left:6px}
.verdict .approved.on{border-color:var(--ok);background:color-mix(in srgb,var(--ok) 14%,var(--panel))}
.verdict .rejected.on{border-color:var(--bad);background:color-mix(in srgb,var(--bad) 14%,var(--panel))}
.verdict .doubt.on{border-color:var(--doubt);background:color-mix(in srgb,var(--doubt) 14%,var(--panel))}
.why{margin-top:12px;display:none}.why.on{display:block}.why select,.rater input,textarea{width:100%;padding:8px;border:1px solid var(--line);border-radius:8px;background:var(--bg)}
textarea{margin-top:10px;min-height:60px}textarea.code{font:13px/1.5 var(--mono);min-height:150px;white-space:pre}
details.lk,details.fix{margin-top:12px}.lkq{margin:10px 0}.lkq .opts{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}
.lkq label{border:1px solid var(--line);border-radius:8px;padding:4px 8px;font-size:13px;cursor:pointer}
.lkq input{position:absolute;opacity:0}.lkq label:has(input:checked){border-color:var(--accent);background:var(--chip)}
.lkq label:has(input:focus-visible){outline:2px solid var(--accent)}
.nav{display:flex;gap:8px;justify-content:space-between;flex-wrap:wrap;margin-top:16px}
.stats{font-size:14px}.stats p{margin:4px 0}.warn{border-left:3px solid var(--doubt);padding:6px 10px;background:color-mix(in srgb,var(--doubt) 10%,var(--panel));border-radius:6px}
.rater{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.rater input{max-width:260px}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
</style></head>
<body data-base="__BASE__">
<header><h1 id="h"></h1><span class="sub" id="sub"></span><div class="bar"><i id="pb" style="width:0"></i></div><span class="prog" id="pg"></span>
<button class="btn" id="th" type="button" aria-label="theme">◐</button>
<label class="btn" for="imp" id="impl"></label><input type="file" id="imp" accept=".md,.json" hidden>
<button class="btn pri" id="exp" type="button"></button></header>
<main><aside class="list" aria-label="list"><div class="f" id="flt"></div><div id="lst"></div></aside>
<div><div class="intro" id="intro"></div><section class="card" id="card" aria-live="polite"></section><div class="card stats" id="st"></div></div></main>
<script id="data" type="application/json">__DATA__</script>
<script>
"use strict";
var P=JSON.parse(document.getElementById('data').textContent),D=P.d,T=P.t,d=document;
/* one session per rater: changing the name opens that rater's own answers, empty for a new rater */
var BASEKEY='synesis-review:'+D.project+':'+D.sample,S,cur=0,flt='all';
function rkey(r){return BASEKEY+':r:'+r}
function load(r){var s=null;try{s=JSON.parse(localStorage.getItem(rkey(r))||'null')}catch(e){}return s&&s.j?s:{rater:r,j:{},dirty:false}}
var last='';try{last=localStorage.getItem(BASEKEY+':last')||''}catch(e){}
S=last?load(last):{rater:'',j:{},dirty:false};
try{var th=localStorage.getItem('synesis-theme');if(th)d.documentElement.dataset.theme=th}catch(e){}
function save(){if(!S.rater)return;S.dirty=true;try{localStorage.setItem(rkey(S.rater),JSON.stringify(S));localStorage.setItem(BASEKEY+':last',S.rater)}catch(e){}stats();list()}
function esc(x){return String(x==null?'':x).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function f(s,o){return s.replace(/\{(\w+)\}/g,function(_,k){return o[k]})}
function vs(rel,line){var u=new URL((d.body.dataset.base||'..')+'/'+rel,location.href),p=decodeURIComponent(u.pathname);if(/^\/[A-Za-z]:/.test(p))p=p.slice(1);return'vscode://file/'+p+':'+line}
d.getElementById('h').textContent=T.title;d.getElementById('sub').textContent=f(T.sub,{proj:D.project,sample:D.sample});
d.getElementById('exp').textContent=T.export;d.getElementById('impl').textContent=T.import;
var intro=d.getElementById('intro');intro.innerHTML=(D.project_changed?'<p class="warn">'+esc(T.changed_project)+'</p>':'')+'<p>'+esc(T.intro)+'</p><p class="muted small">'+esc(f(T.sample_note,{n:D.items.length,N:D.population,seed:D.seed}))+(Object.keys(D.groups).filter(function(g){return g}).length>1?' '+esc(T.groups_note):'')+' '+esc(T.blind)+'</p><ul>'+T.how.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul>'
+'<div class="rater" style="margin-top:10px"><label for="rt">'+esc(T.rater)+'</label><input id="rt" autocomplete="off"><span class="muted small">'+esc(T.rater_note)+'</span></div>';
var rt=d.getElementById('rt');rt.value=S.rater||'';
rt.onchange=function(){var r=rt.value.trim();if(r===S.rater)return;S=r?load(r):{rater:'',j:{},dirty:false};if(r){try{localStorage.setItem(BASEKEY+':last',r)}catch(e){}}var fo=D.items.findIndex(function(it){return!S.j[it.id]});cur=fo<0?0:fo;show()};
d.getElementById('flt').innerHTML=['all','open','flag'].map(function(k){return'<button class="btn" type="button" data-f="'+k+'">'+esc(T.filter[k])+'</button>'}).join('');
d.getElementById('flt').onclick=function(e){var b=e.target.closest('[data-f]');if(b){flt=b.dataset.f;list()}};
function vis(i){var j=S.j[D.items[i].id];return flt==='all'||(flt==='open'&&!(j&&j.verdict))||(flt==='flag'&&j&&j.verdict&&j.verdict!=='approved')}
function list(){d.querySelectorAll('#flt button').forEach(function(b){b.classList.toggle('on',b.dataset.f===flt)});
d.getElementById('lst').innerHTML=D.items.map(function(it,i){if(!vis(i))return'';var j=S.j[it.id];return'<button class="li'+(i===cur?' cur':'')+'" type="button" data-i="'+i+'"><i class="dot '+(j&&j.verdict?j.verdict:'')+'"></i><span>'+(i+1)+'. @'+esc(it.src)+'</span>'+(j&&j.proposal?'<span class="pen" title="'+esc(T.propose)+'">✎</span>':'')+'</button>'}).join('')}
d.getElementById('lst').onclick=function(e){var b=e.target.closest('[data-i]');if(b){cur=+b.dataset.i;show()}};
function ctx(c){return c?'<details class="ctx"><summary>'+esc(T.context)+'</summary><div>'+esc(c[0])+'<mark>'+esc(c[1])+'</mark>'+esc(c[2])+'</div></details>':''}
function val(v){if(v.t==='QUOTATION')return'<blockquote>'+esc(v.v)+'</blockquote><div class="seal '+v.st+'">'+(v.st==='found'?'✓ ':v.st==='not_found'?'✕ ':'? ')+esc(T['q_'+v.st])+'</div>'+ctx(v.ctx);
if(v.t==='CODE')return v.v.map(function(x){return'<span class="chip">'+esc(x)+'</span>'}).join('');
if(v.t==='CHAIN')return v.v.map(function(c){return'<div class="chain"><span class="chip">'+esc(c[0])+'</span><span class="rel">→ '+esc(c[1])+' →</span><span class="chip">'+esc(c[2])+'</span></div>'}).join('');
if(v.t==='ENUMERATED'||v.t==='ORDERED'||v.t==='TOPIC')return'<span class="chip">'+esc(v.v)+'</span>';return'<div>'+esc(v.v)+'</div>'}
function show(){var it=D.items[cur],j=S.j[it.id]||{},c=d.getElementById('card'),on=!!S.rater;
var h='<div class="meta"><b>'+esc(T.annotation)+' '+(cur+1)+'/'+D.items.length+'</b><span>'+esc(T.source)+': @'+esc(it.src)+'</span>'+(it.g?'<span>'+esc(T.group)+': '+esc(it.g)+'</span>':'')
+'<a href="'+esc(vs(it.f,it.l))+'">'+esc(T.open_vs)+' ('+esc(it.f)+':'+it.l+')</a></div>';
if(it.changed)h+='<p class="warn">'+esc(T.item_changed)+'</p>';
h+=(it.vals||[]).map(function(v){return'<div class="fld"><div class="fn">'+esc(v.n)+'</div>'+val(v)+'</div>'}).join('');
if(!on)h+='<p class="warn">'+esc(T.need_rater)+'</p>';
h+='<div class="verdict">'+[['approved',T.approve,1],['rejected',T.reject,2],['doubt',T.doubt,3]].map(function(b){return'<button type="button" class="'+b[0]+(j.verdict===b[0]?' on':'')+'" data-v="'+b[0]+'"'+(on?'':' disabled')+'>'+esc(b[1])+'<kbd>'+b[2]+'</kbd></button>'}).join('')+'</div>';
h+='<div class="why'+(j.verdict&&j.verdict!=='approved'?' on':'')+'"><label for="rs">'+esc(T.reason)+'</label><select id="rs"><option value=""></option>'+D.reasons.map(function(r){return'<option value="'+r+'"'+(j.reason===r?' selected':'')+'>'+esc(T.reasons[r])+'</option>'}).join('')+'</select></div>';
h+='<textarea id="nt" placeholder="'+esc(T.note)+'"'+(on?'':' disabled')+'>'+esc(j.note||'')+'</textarea>';
h+='<details class="fix"'+(j.proposal?' open':'')+'><summary>'+esc(T.propose)+'</summary><p class="muted small">'+esc(T.propose_hint)+'</p><textarea id="pp" class="code" spellcheck="false"'+(on?'':' disabled')+'>'+esc(j.proposal||it.block)+'</textarea></details>';
if(D.likert.length)h+='<details class="lk"'+(j.likert&&Object.keys(j.likert).length?' open':'')+'><summary>'+esc(T.detail)+'</summary>'+D.likert.filter(function(n){return(it.vals||[]).some(function(v){return v.n===n})}).map(function(n){return'<div class="lkq" role="radiogroup" aria-label="'+esc(f(T.likert_q,{f:n}))+'"><div>'+esc(f(T.likert_q,{f:n}))+'</div><div class="opts">'+T.likert.map(function(l,k){var ck=j.likert&&j.likert[n]===k+1;return'<label><input type="radio" name="lk-'+esc(n)+'" value="'+(k+1)+'" data-n="'+esc(n)+'"'+(ck?' checked':'')+(on?'':' disabled')+'>'+(k+1)+' · '+esc(l)+'</label>'}).join('')+'</div></div>'}).join('')+'</details>';
h+='<div class="nav"><button class="btn" type="button" id="pv">← '+esc(T.prev)+'</button><button class="btn" type="button" id="no">'+esc(T.next_open)+'</button><button class="btn" type="button" id="nx">'+esc(T.next)+' →</button></div>';
c.innerHTML=h;
c.querySelectorAll('[data-v]').forEach(function(b){b.onclick=function(){verdict(b.dataset.v)}});
d.getElementById('rs').onchange=function(e){upd({reason:e.target.value})};d.getElementById('nt').onchange=function(e){upd({note:e.target.value})};
d.getElementById('pp').onchange=function(e){var v=e.target.value.replace(/\s+$/,'');upd({proposal:v===it.block.replace(/\s+$/,'')?'':v})};
c.querySelectorAll('input[type=radio]').forEach(function(r){r.onchange=function(){var o=Object.assign({},(S.j[it.id]||{}).likert||{});o[r.dataset.n]=+r.value;upd({likert:o})}});
d.getElementById('pv').onclick=function(){go(-1)};d.getElementById('nx').onclick=function(){go(1)};d.getElementById('no').onclick=nextOpen;list();stats()}
function upd(p){var it=D.items[cur];if(!S.rater)return;S.j[it.id]=Object.assign({item:it.id,verdict:null,likert:{},reason:'',note:'',proposal:''},S.j[it.id]||{},p);save()}
function verdict(v){if(!S.rater)return;upd({verdict:v});show();if(v==='approved')setTimeout(function(){nextOpen()},150)}
function go(k){cur=Math.max(0,Math.min(D.items.length-1,cur+k));show()}
function nextOpen(){for(var k=1;k<=D.items.length;k++){var i=(cur+k)%D.items.length;var j=S.j[D.items[i].id];if(!(j&&j.verdict)){cur=i;show();return}}show()}
function wil(x,n){var z=1.96;if(!n)return[0,1];var p=x/n,dn=1+z*z/n,c=(p+z*z/(2*n))/dn,hw=z*Math.sqrt(p*(1-p)/n+z*z/(4*n*n))/dn;return[Math.max(0,c-hw),Math.min(1,c+hw)]}
function pc(x){return(Math.round(x*1000)/10).toLocaleString(d.documentElement.lang||undefined)}
function judged(){return D.items.map(function(it){return S.j[it.id]}).filter(function(j){return j&&j.verdict})}
function stats(){var js=judged(),a=0,r=0,o=0;js.forEach(function(j){if(j.verdict==='approved')a++;else if(j.verdict==='rejected')r++;else o++});
var k=js.length,n=D.items.length;d.getElementById('pb').style.width=(100*k/n)+'%';d.getElementById('pg').textContent=(S.rater?S.rater+' · ':'')+f(T.progress,{k:k,n:n})+(S.dirty?' · '+T.unsaved:'');
var h='<p><b>'+esc(f(T.stats,{a:a,r:r,d:o}))+'</b></p>',dec=a+r;
if(dec){if(r){var w=wil(r,dec);h+='<p>'+esc(f(T.rate,{p:pc(r/dec),r:r,n:dec,lo:pc(w[0]),hi:pc(w[1])}))+'</p>'}else h+='<p>'+esc(f(T.rule3,{n:dec,u:pc(Math.min(1,3/dec))}))+'</p>';h+='<p class="muted small">'+esc(T.rate_note)+'</p>'}
var first=D.items.slice(0,D.stop[0]).map(function(it){return S.j[it.id]}),fj=first.filter(function(j){return j&&j.verdict}),fr=fj.filter(function(j){return j.verdict==='rejected'}).length;
if(fj.length>=Math.min(D.stop[0],n)&&fr>=Math.ceil(D.stop[1]*fj.length))h+='<p class="warn">'+esc(f(T.stop,{k:fj.length,r:fr}))+'</p>';
d.getElementById('st').innerHTML=h}
/* export: one Markdown file for the coordinator, readable by people and by an AI, with the data for --import */
function fence(s){return'```synesis\n'+s+'\n```'}
d.getElementById('exp').onclick=function(){if(!S.rater){alert(T.need_rater);return}var js=judged(),today=new Date().toISOString().slice(0,10);
var data={kind:'synesis-skill/review',sample:D.sample,project:D.project,state:D.state,rater:S.rater,exported_on:today,judgments:js};
var a=0,r=0,o=0;js.forEach(function(j){if(j.verdict==='approved')a++;else if(j.verdict==='rejected')r++;else o++});
var md=['# Synesis review — '+D.project+' — '+S.rater,'','> '+f(T.md_human,{rater:S.rater}),'',
'Project: '+D.project+' · sample: '+D.sample+' ('+D.items.length+' of '+D.population+' annotations) · rater: '+S.rater+' · exported: '+today,'',
'## Instructions for the AI that reads this file','',D.ai,'',
'## Summary','','Judged '+js.length+' of '+D.items.length+': approved '+a+', rejected '+r+', doubt '+o+'. Proposed corrections: '+js.filter(function(j){return j.proposal}).length+'.','',
'## Annotations','',''];
D.items.forEach(function(it,i){var j=S.j[it.id];if(!(j&&j.verdict))return;
md.push('### '+(i+1)+'. '+it.id+' — @'+it.src+(it.g?' ('+it.g+')':'')+' — '+it.f+':'+it.l+' — '+j.verdict.toUpperCase(),'');
if(j.reason)md.push('Reason: '+j.reason);if(j.note)md.push('Note: '+j.note.replace(/\n/g,' '));
if(j.likert&&Object.keys(j.likert).length)md.push('Scale 1-5: '+Object.keys(j.likert).map(function(k){return k+'='+j.likert[k]}).join(', '));
md.push('','Block as reviewed:','',fence(it.block),'');if(j.proposal)md.push('Proposed correction:','',fence(j.proposal),'')});
md.push('## Data for the import (do not edit)','','<!-- synesis-review-data -->','```json',JSON.stringify(data,null,1),'```','');
var name=D.project+'-review-'+D.sample+'-'+S.rater.replace(/[^A-Za-z0-9_.-]+/g,'_')+'.md';
var blob=new Blob([md.join('\n')],{type:'text/markdown'});var el=d.createElement('a');el.href=URL.createObjectURL(blob);el.download=name;d.body.appendChild(el);el.click();el.remove();
S.dirty=false;try{localStorage.setItem(rkey(S.rater),JSON.stringify(S))}catch(e){}stats();alert(f(T.exported,{file:name}))};
d.getElementById('imp').onchange=function(e){var fl=e.target.files[0];if(!fl)return;var rd=new FileReader();rd.onload=function(){try{var tx=String(rd.result),x;
if(/^\s*\{/.test(tx))x=JSON.parse(tx);else{var i=tx.indexOf('<!-- synesis-review-data -->'),m=i<0?null:/```json\s*\n([\s\S]*?)\n```/.exec(tx.slice(i));if(!m)throw new Error('no review data');x=JSON.parse(m[1])}
if(x.sample!==D.sample)throw new Error(D.sample);S=load(x.rater||S.rater||'rater');S.rater=x.rater||S.rater;(x.judgments||[]).forEach(function(j){S.j[j.item]=j});rt.value=S.rater;save();show()}catch(err){alert(err)}};rd.readAsText(fl);e.target.value=''};
d.getElementById('th').onclick=function(){var c2=d.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'),nx=c2==='dark'?'light':'dark';d.documentElement.dataset.theme=nx;try{localStorage.setItem('synesis-theme',nx)}catch(e){}};
d.addEventListener('keydown',function(e){if(/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))return;if(e.key==='1')verdict('approved');else if(e.key==='2')verdict('rejected');else if(e.key==='3')verdict('doubt');else if(e.key==='ArrowRight')go(1);else if(e.key==='ArrowLeft')go(-1)});
var firstOpen=D.items.findIndex(function(it){var j=S.j[it.id];return!(j&&j.verdict)});cur=firstOpen<0?0:firstOpen;show();
</script></body></html>
"""
