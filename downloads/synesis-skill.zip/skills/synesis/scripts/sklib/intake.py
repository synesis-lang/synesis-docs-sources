# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""Source intake: look at the raw files a researcher dropped in the inbox, and prepare them.

Everything here runs on the researcher's computer. `scan` classifies each file and recommends
how to use it; `apply` copies what can be prepared into the project:

- `.txt` / `.md` / `.docx` -> `fontes/<key>.txt|.md` plus the .bib entry the coder requires;
- `.bib` -> its entries are appended to the project bibliography;
- `.toml` -> `fontes/<name>.toml` (one record per file).

Originals are never changed and nothing is ever overwritten. PDF is not converted: the page
tells the researcher how to turn it into .txt, because columns, headers and scans need a
human check. Python 3.10+, no dependency beyond what synesis already installs.
"""

from __future__ import annotations

import io
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .anchor import _bib_abstract
from .common import INBOX_MARKER, die, read_json, sha256_bytes, write_json
from .project import include_target

MAX_BYTES = 20 * 1024 * 1024            # a larger "text" is almost certainly not one source
MIN_WORDS = 30                          # fewer words than this is suspicious for a source text

_EXT = {
    ".ris": "ref_export", ".enw": "ref_export", ".nbib": "ref_export", ".xml": "unknown",
    ".csv": "table", ".tsv": "table", ".xlsx": "table", ".xls": "table", ".ods": "table",
    ".doc": "office", ".odt": "office", ".rtf": "office", ".html": "office", ".htm": "office", ".epub": "office",
    ".mp3": "media", ".wav": "media", ".m4a": "media", ".mp4": "media", ".mov": "media", ".ogg": "media", ".webm": "media",
    ".png": "image", ".jpg": "image", ".jpeg": "image", ".tif": "image", ".tiff": "image", ".heic": "image",
    ".zip": "archive", ".rar": "archive", ".7z": "archive", ".gz": "archive",
    ".pdf": "pdf",
}
READY = {"bib_ok", "bib_partial", "bib_none", "text_ok", "text_enc", "text_short", "docx_ok", "toml_ok"}
KINDS = sorted(READY | set(_EXT.values()) | {"empty", "docx_bad", "toml_bad", "bib_bad", "duplicate", "too_big"})


# --------------------------------------------------------------------------- inbox


def find_inbox(folder: Path) -> Optional[Path]:
    """The inbox is the subfolder that carries the marker file, whatever its name."""
    folder = Path(folder)
    if not folder.is_dir():
        return None
    for p in sorted(folder.iterdir()):
        if p.is_dir() and (p / INBOX_MARKER).exists():
            return p
    return None


def make_inbox(folder: Path, name: str) -> Path:
    """Create (or return) the inbox. A folder that already holds files is never taken over."""
    existing = find_inbox(folder)
    if existing:
        return existing
    inbox = Path(folder) / name
    if inbox.exists() and any(inbox.iterdir()):
        die(f"the folder '{name}' already exists and is not empty; choose another with --inbox NAME")
    inbox.mkdir(parents=True, exist_ok=True)
    (inbox / INBOX_MARKER).write_text("{}\n", encoding="utf-8", newline="\n")
    return inbox


def _private(inbox: Path) -> Dict[str, Any]:
    """Which original became which key. It stays in the inbox, with the originals, and is never shared."""
    try:
        data = read_json(inbox / INBOX_MARKER)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


# --------------------------------------------------------------------------- reading


def decode(data: bytes) -> Tuple[str, bool]:
    """(text, sure). UTF-8 and BOM-marked files are certain; anything else is read as Windows-1252."""
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", errors="replace"), True
    try:
        return data.decode("utf-8-sig"), True
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace"), False


def docx_text(data: bytes) -> Optional[str]:
    """Paragraphs of the body of a .docx (tables included; deleted text, footnotes and comments are not)."""
    w = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if z.getinfo("word/document.xml").file_size > 5 * MAX_BYTES:
                return None
            xml = z.read("word/document.xml")
        if b"<!DOCTYPE" in xml or b"<!ENTITY" in xml:     # never valid in a .docx
            return None
        root = ET.fromstring(xml)
    except (KeyError, zipfile.BadZipFile, ET.ParseError, RuntimeError, NotImplementedError, OSError):
        return None
    out = []
    for p in root.iter(w + "p"):
        parts = []
        for node in p.iter():
            if node.tag == w + "t":
                parts.append(node.text or "")
            elif node.tag == w + "tab":
                parts.append("\t")
            elif node.tag in (w + "br", w + "cr"):
                parts.append("\n")
        out.append("".join(parts).rstrip())
    return re.sub(r"\n{3,}", "\n\n", "\n\n".join(out)).strip()


def bib_blocks(text: str) -> List[Tuple[str, str, str]]:
    """[(type, key, raw)] of every BibTeX entry, by balanced braces. @string has an empty key."""
    out, i = [], 0
    for m in re.finditer(r"@(\w+)\s*\{", text):
        if m.start() < i:
            continue
        depth, j = 0, m.end() - 1
        while j < len(text):
            if text[j] == "\\":
                j += 2
                continue
            depth += {"{": 1, "}": -1}.get(text[j], 0)
            if depth == 0:
                break
            j += 1
        if j >= len(text):
            continue                                    # never closes: ignore only this one
        raw, i = text[m.start(): j + 1], j + 1
        kind = m.group(1).lower()
        if kind in ("comment", "preamble"):
            continue
        key = "" if kind == "string" else raw[m.end() - m.start():].split(",", 1)[0].strip()
        if kind == "string" or re.fullmatch(r"[^\s{}\"=]+", key):
            out.append((kind, key, raw))
    return out


def _toml(data: bytes) -> Optional[Dict[str, Any]]:
    try:
        import tomllib
    except ModuleNotFoundError:                        # Python 3.10: synesis depends on tomli there
        import tomli as tomllib                        # type: ignore[no-redef]
    try:
        return tomllib.loads(decode(data)[0])
    except Exception:  # noqa: BLE001 - any parse problem means "not a usable record"
        return None


def record_text(data: Dict[str, Any]) -> str:
    """Every string of a TOML record, for anchoring the excerpts taken from it."""
    out: List[str] = []

    def walk(v: Any) -> None:
        if isinstance(v, dict):
            for x in v.values():
                walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)
        elif isinstance(v, str):
            out.append(v)
    walk(data)
    return "\n".join(out)


def _words(text: str) -> int:
    """Words; in Chinese or Japanese, which do not separate them, characters."""
    cjk = len(re.findall(r"[\u3040-\u30ff\u4e00-\u9fff]", text))
    return len(re.sub(r"[\u3040-\u30ff\u4e00-\u9fff]+", " ", text).split()) + cjk


def _classify(path: Path, data: bytes) -> Dict[str, Any]:
    ext = path.suffix.lower()
    if ext in _EXT:
        return {"kind": _EXT[ext]}
    if ext not in (".txt", ".md", ".markdown", ".docx", ".bib", ".toml"):
        return {"kind": "unknown"}
    if not data.strip():
        return {"kind": "empty"}
    if ext == ".docx":
        text = docx_text(data)
        return {"kind": "docx_ok", "words": _words(text)} if text else {"kind": "docx_bad"}
    if ext == ".toml":
        rec = _toml(data)
        return {"kind": "toml_ok", "sections": len(rec)} if rec else {"kind": "toml_bad"}
    text, sure = decode(data)
    if ext == ".bib":
        entries = [raw for kind, key, raw in bib_blocks(text) if key]
        if not entries:
            return {"kind": "bib_bad"}
        n = len(entries)
        a = sum(bool((_bib_abstract(x) or "").strip()) for x in entries)
        return {"kind": "bib_ok" if a == n else "bib_none" if a == 0 else "bib_partial", "n": n, "a": a, "m": n - a}
    words = _words(text)
    return {"kind": "text_enc" if not sure else "text_short" if words < MIN_WORDS else "text_ok", "words": words}


def _raw_files(inbox: Path) -> List[Path]:
    """Files of the inbox. Hidden files, Office lock files and symbolic links are left out."""
    out = []
    for p in sorted(inbox.rglob("*")):
        parts = p.relative_to(inbox).parts
        if p.is_symlink() or not p.is_file() or any(x.startswith((".", "~$")) for x in parts):
            continue
        if any((inbox / Path(*parts[:i])).is_symlink() for i in range(1, len(parts))):
            continue
        out.append(p)
    return out


def scan(folder: Path) -> Dict[str, Any]:
    """Inventory of the inbox. Reads the files here, on this computer; sends nothing anywhere."""
    inbox = find_inbox(folder)
    files: List[Dict[str, Any]] = []
    neutral = False
    if inbox:
        private = _private(inbox)
        neutral = bool(private.get("neutral"))
        done = private.get("prepared") or {}
        seen: Dict[str, str] = {}
        # shortest name first: of two equal files, 'a.txt' is kept and 'a copy.txt' is the repeated one
        for p in sorted(_raw_files(inbox), key=lambda x: (len(x.name), x.as_posix())):
            name = p.relative_to(inbox).as_posix()
            if p.stat().st_size > MAX_BYTES and p.suffix.lower() not in _EXT:
                files.append({"name": name, "kind": "too_big"})
                continue
            if p.suffix.lower() in _EXT:               # recognized by extension: not even opened
                files.append({"name": name, "kind": _EXT[p.suffix.lower()]})
                continue
            data = p.read_bytes()
            sha = sha256_bytes(data)
            item = {"name": name, "sha256": sha, **_classify(p, data)}
            if sha in seen and item["kind"] in READY:
                item = {"name": name, "sha256": sha, "kind": "duplicate", "of": seen[sha]}
            else:
                seen.setdefault(sha, name)
                if sha in done:
                    item["keys"] = done[sha]
            files.append(item)
    files.sort(key=lambda f: f["name"].lower())
    return {"inbox": inbox.name if inbox else None, "files": files, "neutral": neutral}


def counts(inventory: Dict[str, Any]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for f in inventory["files"]:
        out[f["kind"]] = out.get(f["kind"], 0) + 1
    return dict(sorted(out.items()))


def project_sources(synp: Path) -> Dict[str, int]:
    """What the project itself already has: texts in fontes/, references, abstracts, records."""
    base = Path(synp).resolve().parent
    texts = records = refs = abstracts = 0
    for name in ("fontes", "sources"):
        d = base / name
        if d.is_dir():
            texts += sum(p.suffix.lower() in (".txt", ".md") for p in d.iterdir())
            records += sum(p.suffix.lower() == ".toml" for p in d.iterdir())
    bib = include_target(synp, "BIBLIOGRAPHY")
    if bib is not None and bib.is_file():
        for _, key, raw in bib_blocks(decode(bib.read_bytes())[0]):
            if key:
                refs += 1
                abstracts += bool((_bib_abstract(raw) or "").strip())
    return {"texts": texts, "refs": refs, "abstracts": abstracts, "records": records}


# --------------------------------------------------------------------------- parts of a converted PDF

_PART = re.compile(r"^(.+)\.p(\d+)-(\d+)\.md$", re.I)


def clean_markdown(text: str) -> str:
    """Plain text of the Markdown a PDF converter wrote: no page comments, no backslash escapes."""
    text = re.sub(r"<!--.*?-->[ \t]*\n?", "", text, flags=re.S)
    text = re.sub(r"\\([\\`*_{}\[\]()#+\-.!|<>~&])", r"\1", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def join_parts(folder: Path) -> Dict[str, Any]:
    """Join `NAME.p001-010.md`, `NAME.p011-020.md`... of the inbox into `NAME.md`, here, word for word.

    Only a sequence that starts at page 1 and has no gap or overlap is joined. The parts go to the
    hidden folder `.parts/` of the inbox; an existing NAME.md is never overwritten."""
    inbox = find_inbox(folder)
    if inbox is None:
        die("there is no inbox in this folder; run `sk.py intake` first")
    groups: Dict[Tuple[Path, str], List[Tuple[int, int, Path]]] = {}
    for p in _raw_files(inbox):
        m = _PART.match(p.name)
        if m:
            groups.setdefault((p.parent, m.group(1)), []).append((int(m.group(2)), int(m.group(3)), p))
    out: Dict[str, Any] = {"joined": 0, "incomplete": 0, "exists": 0}
    for (parent, stem), parts in sorted(groups.items(), key=lambda kv: kv[0][1]):
        parts.sort(key=lambda x: x[0])
        expected = 1
        for a, b, _ in parts:
            if a != expected or b < a:
                break
            expected = b + 1
        else:
            dest = parent / f"{stem}.md"
            if dest.exists():
                out["exists"] += 1
                continue
            text = "\n\n".join(clean_markdown(decode(p.read_bytes())[0]) for _, _, p in parts)
            with open(dest, "x", encoding="utf-8", newline="\n") as fh:
                fh.write(text + "\n")
            store = inbox / ".parts"
            store.mkdir(exist_ok=True)
            for _, _, p in parts:
                if not (store / p.name).exists():
                    p.rename(store / p.name)
            out["joined"] += 1
            continue
        out["incomplete"] += 1
    return out


# --------------------------------------------------------------------------- preparing


def _key_from(name: str) -> str:
    s = unicodedata.normalize("NFKD", Path(name).stem)
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")[:40].strip("_")
    return s if s and s[0].isalpha() else f"s_{s}".rstrip("_") if s else "source"


def _unique(key: str, taken: set) -> str:
    if key.lower() not in taken:
        return key
    n = 2
    while f"{key}_{n}".lower() in taken:
        n += 1
    return f"{key}_{n}"


def _neutral(prefix: str, taken: set) -> str:
    n = 1
    while f"{prefix}{n:02d}".lower() in taken:
        n += 1
    return f"{prefix}{n:02d}"


def apply(synp: Path, keys: str = "name", prefix: str = "src", only: Optional[List[str]] = None) -> Dict[str, Any]:
    """Prepare the ready files. Idempotent: a file already prepared (same content) is skipped."""
    from .runs import decide

    synp = Path(synp).resolve()
    base = synp.parent
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", prefix):
        die("--prefix must start with a letter and use only letters, digits and _")
    inbox = find_inbox(base)
    if inbox is None:
        die("there is no inbox in this project; run `sk.py intake` first")
    bib = include_target(synp, "BIBLIOGRAPHY")
    chosen = [f for f in scan(base)["files"] if f["kind"] in READY and f.get("keys") is None
              and (not only or f["name"] in only)]
    # a project made only of TOML records has no bibliography, and needs none
    needs_bib = any(f["kind"] != "toml_ok" for f in chosen)
    if needs_bib and (bib is None or bib.suffix.lower() != ".bib" or "*" in bib.name):
        die('the project must declare one bibliography file: INCLUDE BIBLIOGRAPHY "references.bib"')
    if needs_bib and not bib.resolve().is_relative_to(base):
        die("the project bibliography is outside the project folder; intake only writes inside the project")
    bib_text = ""
    if needs_bib and bib.exists():
        bib_text, sure = decode(bib.read_bytes())
        if not sure:
            die(f"{bib.name} is not UTF-8; save it as UTF-8 first, so nothing in it is changed by accident")
    known = {k.lower(): raw for _, k, raw in bib_blocks(bib_text) if k}
    strings = {raw for kind, k, raw in bib_blocks(bib_text) if kind == "string"}
    fontes = base / "fontes"
    private = _private(inbox)
    prepared: Dict[str, List[str]] = dict(private.get("prepared") or {})
    append: List[str] = []
    result: Dict[str, Any] = {"texts": [], "references": [], "records": [], "conflicts": [], "left": 0, "skipped": 0}
    items = scan(base)["files"]
    if only:
        unknown = sorted(set(only) - {f["name"] for f in items})
        if unknown:
            die("not in the inbox: " + ", ".join(unknown))
    outputs: Dict[str, str] = {}
    originals: List[str] = []

    for f in items:
        if f["kind"] not in READY or (only and f["name"] not in only):
            result["left"] += 1
            continue
        if f.get("keys") is not None:
            result["skipped"] += 1
            continue
        src = inbox / f["name"]
        data = src.read_bytes()
        originals.append(f["sha256"])
        if f["kind"].startswith("bib"):
            got = []
            for kind, key, raw in bib_blocks(decode(data)[0]):
                if kind == "string":
                    if raw not in strings:
                        strings.add(raw)
                        append.append(raw)
                    continue
                if key.lower() in known:
                    if re.sub(r"\s+", " ", known[key.lower()]) != re.sub(r"\s+", " ", raw):
                        result["conflicts"].append(key)   # same key, different content: the researcher decides
                    continue
                known[key.lower()] = raw
                append.append(raw)
                got.append(key)
            result["references"] += got
            prepared[f["sha256"]] = got
            continue
        ext = ".toml" if f["kind"] == "toml_ok" else ".md" if src.suffix.lower() in (".md", ".markdown") else ".txt"
        taken = set(known) | ({p.stem.lower() for p in fontes.iterdir()} if fontes.is_dir() else set())
        key = _neutral(prefix, taken) if keys == "neutral" else _unique(_key_from(f["name"]), taken)
        dest = fontes / f"{key}{ext}"
        if ext == ".toml":
            payload = data                                # a record is copied as it is
        else:
            text = docx_text(data) if f["kind"] == "docx_ok" else decode(data)[0]
            payload = (text or "").replace("\r\n", "\n").replace("\r", "\n").rstrip("\n").encode("utf-8") + b"\n"
        fontes.mkdir(exist_ok=True)
        with open(dest, "xb") as fh:                      # "x": never overwrites
            fh.write(payload)
        outputs[dest.relative_to(base).as_posix()] = sha256_bytes(payload)
        prepared[f["sha256"]] = [key]
        if ext == ".toml":
            result["records"].append(key)
            continue
        title = key if keys == "neutral" else re.sub(r"[{}\\%#&$^~\"]+", " ", Path(f["name"]).stem.replace("_", " ")).strip() or key
        raw = f"@misc{{{key},\n    title = {{{title}}},\n    note = {{Source document of the project}}\n}}"
        known[key.lower()] = raw
        append.append(raw)
        result["texts"].append(key)

    if append:
        sep = "" if not bib_text else "\n" if bib_text.endswith("\n") else "\n\n"
        bib.parent.mkdir(parents=True, exist_ok=True)
        with open(bib, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(sep + "\n\n".join(append) + "\n")
    private["prepared"] = prepared
    if keys == "neutral":
        private["neutral"] = True
    write_json(inbox / INBOX_MARKER, private)
    if outputs or append:
        # The shared record has keys and hashes only: no original file name, no original path.
        decide(synp, "source_intake", note=f"{len(result['texts'])} text(s), {len(result['references'])} reference(s), "
               f"{len(result['records'])} record(s) prepared", keys=keys, outputs=outputs,
               references=sorted(result["references"]), originals=sorted(originals))
    return result


def gitignore_hint(folder: Path, inbox: Path) -> bool:
    """True when the inbox (raw, possibly personal data) is not ignored by the project's .gitignore."""
    gi = Path(folder) / ".gitignore"
    lines = gi.read_text(encoding="utf-8", errors="replace").splitlines() if gi.exists() else []
    return not any(ln.strip().strip("/") == inbox.name for ln in lines)
