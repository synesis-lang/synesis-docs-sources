# Copyright 2026 Christian Maciel De Britto
# SPDX-License-Identifier: Apache-2.0
"""The "Research possibilities" tab: from what the researcher wants to do to a Synesis feature.

Each possibility has: the need (in the researcher's voice), a general example, the methodological decision
it asks for, the Synesis feature (with hover help), what already exists "in this project" (computed from
the files by field TYPE and SCOPE, never by field name) and a request to copy and adapt in the conversation.
"""
import html
import re

from .view_text import GUIDE

E = lambda s: html.escape(str(s), quote=True)  # noqa: E731


def facts(entries, types, concepts, fields, anc, occ, parse_lines, synp_text, undefined=()):
    by_type = {}
    for k, v in fields.items():
        by_type.setdefault(v["t"], []).append(k)
    declared = {r for v in fields.values() for r in v["r"]}
    chains, memos = [], []
    for e in entries:
        if e.group != "annotations":
            continue
        for b in parse_lines(e.path.read_text(encoding="utf-8")):
            if b.kind != "block" or b.kw != "ITEM":
                continue
            for f in b.children:
                if f.kind != "field":
                    continue
                val = " ".join([f.text, *f.extra]).strip()
                if types.get(f.kw) == "CHAIN" and val:
                    chains.append((f.kw, val))
                elif types.get(f.kw) == "MEMO" and val:
                    memos.append(val)
    rel_count = {}
    for _, c in chains:
        for r in [x.strip() for x in c.split("->")][1:-1:2]:
            rel_count[r] = rel_count.get(r, 0) + 1
    topic = next((k for k, v in fields.items() if v["t"] == "TOPIC" and v["s"] == "ONTOLOGY"), None)
    groups = {}
    for name, c in concepts.items():
        for k, v in c.get("f", []):
            if k == topic:
                groups[v] = groups.get(v, 0) + 1
    top = sorted(occ.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    qkeys = re.findall(r"^\s*(Q\d+)\s*:", synp_text, re.M)
    summ = anc.get("summary", {})
    # an example chain: the longest one that uses only declared relations
    good = [c for c in chains if all(r in declared for r in [x.strip() for x in c[1].split("->")][1:-1:2])]
    sample = max(good, key=lambda c: c[1].count("->"), default=None)
    return {
        "by_type": by_type, "declared": [r for f in fields.values() for r in f["r"]], "rel_count": rel_count,
        "undeclared": sorted(r for r in rel_count if r not in declared), "chains": chains, "sample": sample,
        "memos": memos, "cite": sum(1 for m in memos if re.search(r"\bQ\d+\b", m)), "qkeys": qkeys,
        "topic": topic, "groups": groups, "n_concepts": len(concepts),
        "undefined": sorted(undefined),
        "single": sum(1 for c, lst in occ.items() if len({o["s"] for o in lst}) == 1),
        "top": [c for c, _ in top[:2]], "found": summ.get("found", 0), "total": sum(summ.values()),
        "notfound": summ.get("not_found", 0),
        "source_fields": [k for k, v in fields.items() if v["s"] == "SOURCE"],
    }


# Where each possibility looks in the project, and the Synesis features it shows. The texts are in
# view_text.GUIDE, one complete set per language; this module only fills in what the project has.
LAYOUT = [
    ("compare", [("scale", ["T:SCALE", "GUIDELINES@G"]), ("enum", ["T:ENUMERATED", "T:ORDERED"])]),
    ("connect", [("chain", ["T:CHAIN", "RELATIONS"]), ("rel", ["RELATIONS"])]),
    ("organize", [("code", ["T:CODE", "INC:ONTOLOGY"]), ("topic", ["T:TOPIC"])]),
    ("support", [("quote", ["T:QUOTATION", "T:MEMO"]), ("q", ["QUESTIONS", "T:MEMO"])]),
]


def _names(xs, g):
    return g["sep"].join(f"«{x}»" for x in xs)


def _here(key, g, f, q1, q2, chain_html):
    """What this project already has, for one possibility: (text, optional html)."""
    h = g["here_fmt"]
    bt = f["by_type"]

    def has(*ts):
        return [n for t in ts for n in bt.get(t, [])]
    if key == "scale":
        found = has("SCALE")
        if found:
            return h["scale_yes"].format(names=_names(found, g)), ""
        return (h["scale_no2"] if len(f["top"]) > 1 else h["scale_no"]).format(q1=q1, q2=q2), ""
    if key == "enum":
        found = has("ENUMERATED", "ORDERED")
        if found:
            return h["enum_yes"].format(names=_names(found, g)), ""
        if f["source_fields"]:
            return h["enum_no"].format(names=_names(f["source_fields"], g)), ""
        return h["enum_nosrc"], ""
    if key == "chain":
        found = has("CHAIN")
        if not found:
            return h["chain_no"], ""
        example = chain_html(f["sample"][0], f["sample"][1]) if f["sample"] else ""
        return h["chain_yes"].format(names=_names(found, g), n=len(f["chains"])), example
    if key == "rel":
        decl = g["sep"].join(f"{r} ({f['rel_count'].get(r, 0)})" for r in f["declared"])
        text = h["rel_yes"].format(decl=decl) if decl else h["rel_none"]
        if f["undeclared"]:
            text += h["rel_undeclared"].format(rels=g["sep"].join(f["undeclared"]))
        return text, ""
    if key == "code":
        text = h["code"].format(n=f["n_concepts"], single=f["single"])
        if f["undefined"]:
            text += h["code_undef"].format(names=_names(f["undefined"], g))
        return text, ""
    if key == "topic":
        if not f["groups"]:
            return h["topic_no"], ""
        groups = g["sep"].join(f"{name} ({n})" for name, n in sorted(f["groups"].items()))
        return h["topic_yes"].format(n=len(f["groups"]), groups=groups), ""
    if key == "quote":
        text = h["quote"].format(found=f["found"], total=f["total"])
        if f["notfound"]:
            text += h["quote_nf"].format(n=f["notfound"])
        return text, ""
    if f["qkeys"]:
        return h["q_yes"].format(cite=f["cite"], memos=len(f["memos"]), keys=g["sep"].join(f["qkeys"])), ""
    return h["q_no"], ""


def groups(lang, f, proj, chain_html):
    """[(group id, title, lead, [item...])], every text from GUIDE[lang], filled with this project's facts."""
    g = GUIDE.get(lang) or GUIDE["en"]
    c1, c2 = (f["top"] + ["", ""])[:2]
    q1 = f"«{c1}»" if c1 else g["some"]
    q2 = f"«{c2}»" if c2 else q1
    qk = g["sep"].join(f["qkeys"]) or "Q1"
    out = []
    for gid, items in LAYOUT:
        rows = []
        for key, res in items:
            text = g["items"][key]
            here, here_html = _here(key, g, f, q1, q2, chain_html)
            rows.append({"need": text["need"], "ex": text["ex"], "dec": text["dec"], "res": res, "here": here,
                         "here_html": here_html, "ask": text["ask"].format(proj=proj, q1=q1, q2=q2, qk=qk)})
        out.append((gid, g["groups"][gid]["title"], g["groups"][gid]["lead"], rows))
    return out


def build(lang, f, proj, chain_html):
    """Return (links for the file bar, body of the tab, number of possibilities)."""
    t = GUIDE.get(lang) or GUIDE["en"]
    gs = groups(lang, f, proj, chain_html)
    nav, body, n = [], [f'<section class="poss-intro"><p>{E(t["intro"])}</p><p class="muted small">{E(t["goal"])}</p></section>'], 0
    for gid, title, lead, items in gs:
        nav.append(f'<a href="#poss-{gid}"><span>{E(title)}</span><small>{len(items)}</small></a>')
        cards = []
        for it in items:
            n += 1
            res = " ".join(
                f'<span class="kw rpill" data-k="{E(k)}" tabindex="0">{E(k.split(":")[-1].replace("@G", ""))}</span>' for k in it["res"])
            ex = it["ex"]
            ex_html = (f'<span class="chain">{E(ex)}</span>' if "→" in ex else E(ex))
            ask = it["ask"] + t["tail"]
            here = E(it["here"]) + (f'<div class="here-ex">{it["here_html"]}</div>' if it.get("here_html") else "")
            cards.append(
                '<article class="poss">'
                f'<h4>“{E(it["need"])}”</h4>'
                f'<dl><dt>{E(t["example"])}</dt><dd>{ex_html}</dd>'
                f'<dt>{E(t["resource"])}</dt><dd>{res}</dd>'
                f'<dt>{E(t["here"])}</dt><dd class="here">{here}</dd></dl>'
                f'<details class="pmore"><summary>{E(t["more"])}</summary>'
                f'<div class="al">{E(t["decision"])}</div><p class="dec">{E(it["dec"])}</p>'
                f'<div class="askbox"><div class="al">{E(t["ask_label"])}</div><p>{E(ask)}</p></div></details>'
                f'<div class="pact"><button class="act ask" type="button" data-ask="{E(ask)}">{E(t["copy"])}</button></div></article>')
        body.append(f'<section class="poss-group" id="poss-{gid}"><h2>{E(title)}</h2><p class="lead">{E(lead)}</p>'
                    f'<div class="poss-grid">{"".join(cards)}</div></section>')
    return nav, "".join(body), n


CSS = """
.poss-intro{background:var(--panel);border:1px solid var(--line);border-left:4px solid var(--accent);border-radius:10px;padding:10px 16px;margin:6px 0 14px}
.poss-intro p{margin:4px 0}
.poss-group{scroll-margin-top:calc(var(--hh,120px) + 10px);margin:18px 0 6px}
.poss-group h2{font-size:17px;margin:0 0 2px}.poss-group .lead{color:var(--muted);margin:0 0 10px;font-size:13.5px}
.poss-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(440px,100%),1fr));gap:12px}
.poss{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 16px;box-shadow:var(--shadow);display:flex;flex-direction:column}
.poss h4{margin:0 0 8px;font-size:15px;font-weight:600;color:var(--ink)}
.poss dl{margin:0;display:grid;grid-template-columns:max-content minmax(0,1fr);gap:6px 12px;font-size:13.5px}
.poss dt{color:var(--muted);font-size:12px;padding-top:1px}.poss dd{margin:0}
.poss .dec{border-left:3px solid var(--s-field);padding-left:8px}
.poss .here{color:var(--ink)}.here-ex{margin-top:4px}
.rpill{display:inline-block;border:1px solid var(--line);border-radius:6px;padding:0 7px;margin:0 4px 2px 0;font:12.5px ui-monospace,Consolas,monospace}
.askbox{margin-top:auto;padding-top:10px}.askbox .al{font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin:8px 0 3px}
.askbox p{margin:0 0 8px;font-size:13px;background:var(--bg);border:1px dashed var(--line);border-radius:8px;padding:8px 10px;color:var(--ink)}
.pmore{margin-top:12px;border-top:1px solid var(--line);padding-top:8px}
.pmore>summary{cursor:pointer;list-style:none;color:var(--accent);font-size:14px}.pmore>summary::-webkit-details-marker{display:none}
.pmore>summary::before{content:"▸ "}.pmore[open]>summary::before{content:"▾ "}
.pmore .al{font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin:10px 0 3px}
.pmore .dec{margin:0;font-size:14px;border-left:3px solid var(--s-field);padding-left:10px}
.pmore .askbox{padding-top:0}.pact{margin-top:auto;padding-top:12px}
.poss dl{font-size:14.5px}.poss dt{font-size:12.5px}
@media(max-width:720px){.poss dl{grid-template-columns:minmax(0,1fr)}.poss dt{margin-top:4px}}
"""
