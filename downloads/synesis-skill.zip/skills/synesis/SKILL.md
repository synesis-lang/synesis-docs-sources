---
name: synesis
description: Set up and run qualitative research projects in the Synesis language (synesis-lang.org) for a researcher - install the Synesis tools with uv, design a template whose every field has GUIDELINES, code interviews, documents and article abstracts with synesis-coder (API or the researcher's own Claude session via handoff), validate, check that quotations exist in the sources, review a sample of annotations, and build offline pages to read the project and its results (large projects in breadth and depth). Use when someone wants to start, code, audit or share a Synesis project (.synp, .synt, .syn, .syno files), or asks to "code my interviews/articles with Synesis".
compatibility: Requires Claude Code in a local session (Claude Desktop Code tab, CLI or IDE extension) with terminal access and internet to install packages from PyPI. Does not work in claude.ai chat or Cowork.
---

# Synesis for researchers

You conduct; the researcher decides; **synesis-coder codes**; **synesis validates**.
Never write or edit ITEM blocks yourself. Never choose categories, theory or
research questions for the researcher: ask, propose, and record what was decided.

Paths below: `SKILL_DIR` is this skill's base directory. `PY` is the Python of the
Synesis tool environment (the installer prints it). Run helpers as
`PY SKILL_DIR/scripts/sk.py <command> <project.synp> ...`.

## 0. Before anything: confidentiality (read `references/confidentiality.md`)

Ask whether the sources contain confidential or personal data, then state the
modality and get agreement **before opening any source file**:

- **A, cloud**: you read sources; the coder uses an API or the handoff.
- **B, reduced exposure**: you see only methodology, template, fictitious examples
  and counts; the coder runs on Ollama; no handoff; you never open sources,
  `.syn` files or the dashboard. Say plainly that this is not fully local.
- **C, local**: you do not take part. Point to VS Code + `@synesis` + Ollama.

## 0b. Language: Synesis stays in English, the conversation follows the researcher

Synesis keywords (`TEMPLATE`, `FIELD`, `ITEM`...), tool output, diagnostics and
`synesis-help` are **English**, and stay English. Everything around them follows
the researcher's language:

1. **Detect it.** The main signal is the language the researcher writes in.
   Confirm with `PY sk.py locale [project.synp]` (system locale, the suggested
   coder language, and what the project `.env` already declares). If the
   researcher writes in Brazilian Portuguese, or the locale is `pt-BR` and they
   have not written yet, use Brazilian Portuguese.
2. **Talk in it.** Explain, ask and summarize in that language. Translate tool
   output, diagnostics and `synesis-help` answers when you relay them; quote
   the original English message (or code, e.g. `SYNESIS_E047`) once, so the
   researcher can look it up.
3. **Write the project's prose in it**: the `DESCRIPTION` and `QUESTIONS` of the
   `.synp`; field `DESCRIPTION`, `GUIDELINES` and value descriptions in the
   `.synt`; ontology definitions. Field names and values may be in that
   language too: `snake_case`, no spaces; prefer no accents in names. Keywords
   stay English.
4. **Make the coder write in it.** Pass `--language "Brazilian Portuguese"` (or
   the `suggested_coder_language`) to every `sk.py code` run; it is recorded in
   the run manifest. If the researcher prefers, they can put
   `SYNESIS_CODER_LANGUAGE=Brazilian Portuguese` in the project `.env`
   themselves. Quotations always stay in the language of the source.
5. Record the choice once: `PY sk.py decide project.synp --type project_language
   --note "<language>; prose, guidelines and coder output in it"`.

## 0c. A project that already exists: measure it, then offer where to start

1. **Measure first**: `PY sk.py size project.synp`. It takes about a second, compiles nothing and
   prints only counts (safe in modality B): the size class (`small`, `medium`, `large`), sources,
   items, concepts, references, Synesis files in the folder that the `.synp` does not include
   (backups, tests), and how long a complete view takes and weighs.
   **The role of this skill**: it teaches the language and the method and it reviews the data. It
   does not replace working with the Synesis tools directly (the `synesis` command line, the
   `EXPORT` blocks, the VS Code extension). A slow pass in the conversation can put people off the
   whole approach: when a task is heavy, show the researcher how to do it with the tools instead.
2. **Medium or large project: do not open or list the `.syn`, `.syno` or `.bib` files yourself.**
   Thousands of blocks make the conversation slow and fill your context; the `sk.py` commands read
   them and summarize. Before anything exhaustive (a complete view, reading every annotation,
   re-coding everything), say how long it takes (from `size`) and wait for a yes. Prefer the
   breadth-and-depth path (§2b): panoramic view, then samples, then one place read whole.
3. **Offer a numbered menu** in the researcher's language, with the times from `size`, and let them
   pick one or more. Leave out what does not apply (no samples in a small project, no results
   before anything is coded):
   1. **Know the project**: the project view (panoramic when the project is large).
   2. **Read more deeply**: a sampled view, or one group, source or concept read whole.
   3. **Review a sample of the annotations**: the review page (§4b).
   4. **See the results**: the results page (§4); in a **large** project, the Synesis tools directly.
   5. **What this project can answer**: the *Possibilities* tab of the view, starting from the
      research questions (compare, connect, organize, support an interpretation).
   6. **Fix the problems**: errors, excerpts not found, runs awaiting acceptance (`sk.py validate`).
   7. **Continue the work**: add sources (§1b), code (§3), build the ontology.
   8. **Export**: the `EXPORT` blocks the `.synp` declares.
4. **Three pages, three names.** Never say "the panel" or "the dashboard" alone:
   - **Project view** (`sk.py view`, `view/index.html`): to know and read the project.
   - **Review** (`sk.py review`, `review/index.html`): to judge a sample of the annotations.
   - **Results** (`sk.py dashboard`, `dashboard/dashboard.html`): what the project found.
   In Portuguese: *Visão do projeto*, *Conferência*, *Resultados*. When the researcher asks for
   "o painel", "the dashboard" or "a page" without saying which, ask in one line which of the three,
   with what each is for, before building any.

## 1. Install (once per machine)

Recommend the **Manual** permission mode so the researcher sees each command.
Windows: `powershell -ExecutionPolicy ByPass -File SKILL_DIR/scripts/install.ps1`
macOS/Linux: `sh SKILL_DIR/scripts/install.sh` (add `--with-graph` only if asked).
Read the report: versions must match (`synesis-coder --version` core = synesis);
the smoke test must say `ok`. In this terminal, call tools through the `bin`
path in the report; new terminals have them on PATH. Then run `PY sk.py doctor`.

## 1b. First session of a project: receive the sources

Researchers rarely know which format their material needs. If the texts are already in `fontes/`
(one `.txt`/`.md` per source), skip the inbox: show the **Your sources** tab, check the encoding, and
write the `.bib` entry of each text yourself (key = file name). Otherwise, once the modality is agreed:

1. `PY sk.py intake FOLDER --lang <page language> --open` (in modality B without `--open`: give the
   path). It creates an inbox folder and `view/index.html`, whose **Your sources** tab explains the
   formats and how to turn PDF into text. Tell the researcher to put the raw files in the inbox.
2. When they say the files are there, run `sk.py intake FOLDER` again. It inspects the files on the
   researcher's computer and prints **only counts by kind**. Add `--names` only in modality A: file
   names can identify people. Never open the inbox in modality B.
3. Recommend a format for each kind of file, **tied to the research questions**, and let the
   researcher decide:
   - `.bib` with abstracts (`--mode abstract`): literature reviews where the abstract is enough; only
     the abstract is coded, never the full article. Say so.
   - `.txt` / `.md` (`--mode document`): interviews, field notes, documents, full articles.
   - `.toml` (`--mode dataset`): sources with the same structure. One record per file; the template
     needs `ON DATASET` fields and the `.synp` `INCLUDE DATASET "fontes/*.toml"`; a project made only of
     records has no `INCLUDE BIBLIOGRAPHY`
     (`sk.py help --lookup MOD_ON_BIBLIOGRAPHY`, `CASE_NEWS_FRAMING`). A spreadsheet can become
     records; propose the sections first, and convert it only in modality A and after approval.
   - **PDF: never read it and retype the text** (retyping changes words, and excerpts must be literal).
     Offer, in this order: the reference with abstract, if it is enough; the researcher converts it to
     `.txt` (UTF-8, one file per document) with the steps on the page; or, **in modality A only**, a
     PDF connector (see "PDF connector" below). The researcher always checks columns, headers,
     hyphenation and scans before `--apply`.
   - Audio, images, `.doc`, `.odt`: the page says what to do with each.
4. After the project exists (§2.3) and the researcher approved, `PY sk.py intake project.synp --apply`.
   It writes `fontes/<key>.txt`, the reference each text needs, and merges `.bib` entries; it never
   changes the originals nor overwrites anything, and records `source_intake` in the decisions. Use
   `--only FILE` for a partial approval. With personal data, or in modality B, use `--keys neutral
   --prefix ent` (`ent01`, `ent02`...): keys go to the prompts and to published files.
5. Add the inbox to `.gitignore` (append the line; create the file if it does not exist). Relay conflicts (same reference key, different content): the
   researcher decides which one stays.

**PDF connector (modality A only, optional).** Example: *PDF Tools* by Open Document Alliance (a
third-party desktop extension, <https://claude.com/marketplace/connectors/pdf-tools>). It reads the
PDF on the researcher's computer, but what its tools return is sent to Anthropic: say so first. In
modality B or C, do not offer it. Never install it yourself; the researcher decides.

- First see whether a PDF tool is available in this session. If not, the researcher can add it from
  the connector directory and allow the project folder in its settings; a desktop extension may not
  reach the Code tab, so if it does not appear, fall back to the manual conversion.
- Use only a tool that **writes the file itself**. With PDF Tools: `convert_pdf_to_markdown` with
  `output_path` in the inbox, at most 10 pages per call, named `NAME.p001-010.md`,
  `NAME.p011-020.md`...; `include_page_boundaries: false`. `NAME` is the PDF name without
  extension. Never copy the returned text into a file by hand, and never use the e-signing tools.
- `PY sk.py intake FOLDER --join` joins the parts locally, word for word, and removes Markdown
  escapes; it refuses a sequence with a missing part. Relay the gaps and warnings the tool reported.
- Scanned pages need OCR: do not transcribe page images yourself. Send the researcher to OCR software.

## 2. Design (read `references/template_design.md`)

1. Interview the researcher: research questions, the sources received (§1b), what to
   extract (free codes, closed categories, causal relations, scales).
2. **Consult `synesis-help` before writing or fixing any construct** (it matches
   the installed compiler; see `references/help.md`):
   - `PY sk.py help <words>`: full-text search, JSON (e.g. `help bundle status`);
   - `PY sk.py help --lookup <ID>`: one entry (`TYPE_CHAIN`, `E047`, `BLOCK_EXPORT`);
   - `PY sk.py help --category case_study`: the nine **case studies**, complete
     projects adapted from real research. Start the design from the closest one
     (`GUIDE_CASE_STUDIES` picks by research design) and adapt its vocabulary.
   `synesis help-field <TYPE>` gives the field matrix; `references/language.md`
   is the static fallback. `SKILL_DIR/examples/prova` is a small complete project.
3. Create the project: `.synp` with `QUESTIONS` and an `EXPORT JSON` block with
   a fixed `GENERATED_AT`; `INCLUDE ANNOTATIONS` and `INCLUDE ONTOLOGY` pointing
   to **folders**; `INCLUDE BIBLIOGRAPHY` to one `.bib`; `fontes/` with the source texts
   named `<bibref>.txt` (§1b.4 fills them).
4. Write the template: **GUIDELINES in every field**, Correct/Wrong pairs,
   examples from another topic, one-line values. Show the researcher one example
   ITEM before the full template.
5. `PY sk.py check project.synp` must print `OK`. Then the researcher approves:
   `PY sk.py decide project.synp --type template_approved --note "<who/what>"`.

## 2b. Let the researcher read the files: the project view (read `references/view.md`)

Researchers should not have to read raw Synesis code. `PY sk.py view project.synp [--open]` writes
`view/index.html`: one offline, read-only page built from the project's own template, with tabs for
the overview, the sources, where to start, each kind of file (every block a card with its problems
and an **Ask Claude** button) and research possibilities.

- It refreshes by itself after `check`, a finished `code` run and `accept`; run it yourself after you
  change a `.synp`, `.synt`, `.syno` or `.syn`.
- **Large projects**: the depth follows the size (`overview`, `sample`, `full`); `--focus` reads one
  group, source or concept whole. Counts, matrix and problems always cover the whole project.
- Requests pasted from the page are the researcher's own: explain, propose, wait for approval.
- Tell the researcher the path and what to look at; **do not paste file contents into the chat**
  when the page shows them. In modality B generate it and give the path; never open it.

## 3. Code (read `references/coder.md`)

One run per source, **one at a time**, accepting each before starting the next
(the coder's context includes what was already accepted):

    PY sk.py code project.synp --backend api|handoff --mode document --target <bibref> --input fontes/<bibref>.txt [--language "<language>"]
    PY sk.py code project.synp --backend ... --mode abstract --target <bibref>     # .bib abstract
    PY sk.py code project.synp --backend ... --mode dataset --target <record id> --input fontes/<file>.toml   # one record
    PY sk.py accept project.synp --run <run-id>
    ...after all sources:
    PY sk.py code project.synp --backend ... --mode ontology --target ontology

- **api**: needs a key in the project `.env`, typed by the researcher, never in
  the chat. Run a 2-3 source pilot first and report the cost.
- **handoff** (default for subscribers, modality A only): the run stops with
  `pending` requests. Answer each `runs/<id>/requests/<rid>.md` with a fresh
  subagent that reads only that file and writes only `responses/<rid>.txt`
  (exact prompt in `references/coder.md`), then rerun with `--run <id>` until
  `complete`. Declare your model with `--model` on the first pass. While requests are pending the
  coder logs `LLM call failed` or `failed validation`: it is the expected pause, not an error.

## 4. Validate and audit

    PY sk.py validate project.synp      # diagnostics as JSON-able report; never blocks
    PY sk.py anchor project.synp        # found / not_found / unverifiable per quotation
    PY sk.py dashboard project.synp     # dashboard/dashboard.html, offline, one file

"Ready" means: 0 errors, 0 warnings, every quotation `found`, nothing stale.
Do not say quotations "were verified" unless `anchor` printed `verified=True`.
The dashboard is the **Results** page: what the project found, the quality checks and the summary
of the reviews. The researcher judges annotations on the review page (§4b), not in the dashboard.

**Large project** (`sk.py size` says `large`): `sk.py dashboard` does not build the page and prints
the manual route instead. Explain it as part of learning the language, and offer to run the first
command with the researcher:

    synesis compile project.synp --xls results.xlsx      # or --csv DIR, --json FILE
    synesis export project.synp                          # the EXPORT blocks the project declares

and the Synesis extension for VS Code (explorer, graph, chat with the project). Build the page
anyway (`--anyway`) only if the researcher asks for it after hearing the time and size it prints.
The project view (panoramic) and the review stay fast at any size.

## 4b. Review a sample of the annotations (read `references/review.md`)

    PY sk.py review project.synp [--size 30] [--open]        # draw a frozen sample + review/index.html
    PY sk.py review project.synp --import A.md B.md ...      # one file per rater, then the report
    PY sk.py review project.synp --corrections               # every rater's proposals, for the coordinator

- The script draws the sample (stratified, seed recorded) and freezes each annotation as it was; the
  page judges that copy, blind to model and run: approved / rejected / doubt, reason, note, optional
  scale and an optional **proposed correction** (the block as the researcher thinks it should be).
- Each rater has a separate session; the export is one Markdown file for the coordinator, with
  instructions for the AI that reads it. Several researchers can review on their own computers and
  send their files to the coordinator; corrections enter the project only after the coordinator
  approves each one, recorded as `manual_edit`.
- Report the rejection **observed in the sample** (Wilson interval of the sample) and, separately,
  the estimate weighted by group; never present the sample rate as the rate of the whole project.

When a diagnostic appears, look it up before explaining it:
`PY sk.py help --lookup SYNESIS_E0NN` (the entry has the message, what the
compiler checks and the fix), then explain it in the researcher's language.

## 5. Problems: triage before fixing (read `references/triage.md`)

Classify each problem, propose the class, let the researcher confirm, record it:
`PY sk.py decide project.synp --type triage --class <class> --item <id> --note "..."`.
`ambiguous_instruction` → new template version + re-code the audited sample;
`model_failure` → re-run that source; `source_conversion` → fix the text, re-run;
`interpretive_divergence` → the researcher decides; record it.
Never hand-edit `.syn` files unless the researcher asks; the dashboard flags
edits made after acceptance.

## 6. Hand-over

Tell the researcher which guarantee they have (`references/coder.md` §Reproducibility):
re-running the protocol gives *similar* results; the run records reconstruct
*these* results exactly (`PY sk.py rebuild project.synp --out <dir>`).
Version everything except `.env`, the inbox, `dashboard/`, `view/`, `review/`, `saida/`. Summarize: sources coded,
backend and model, decisions you made, open issues.
