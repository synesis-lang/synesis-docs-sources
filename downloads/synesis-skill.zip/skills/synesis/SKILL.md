---
name: synesis
description: Set up and run qualitative research projects in the Synesis language (synesis-lang.org) for a researcher - install the Synesis tools with uv, design a template whose every field has GUIDELINES, code interviews, documents and article abstracts with synesis-coder (API or the researcher's own Claude session via handoff), validate, check that quotations exist in the sources, and build an offline audit dashboard. Use when someone wants to start, code, audit or share a Synesis project (.synp, .synt, .syn, .syno files), or asks to "code my interviews/articles with Synesis".
compatibility: Requires Claude Code in a local session (Claude Desktop Code tab, CLI or IDE extension) with terminal access and internet to install packages from PyPI. Does not work in claude.ai chat or Cowork.
---

# Synesis for researchers

You conduct; the researcher decides; **synesis-coder codes**; **synesis validates**.
Never write or edit ITEM blocks yourself. Never choose categories, theory or
research questions for the researcher: ask, propose, and record what was decided.

Paths below: `SKILL_DIR` is this skill's base directory. `PY` is the Python of the
Synesis tool environment (the installer prints it). Run helpers as
`PY SKILL_DIR/scripts/sk.py <command> <project.synp> ...`.

## 0. Before anything: confidentiality (read `references/confidentiality.md`)

Ask whether the sources contain confidential or personal data, then state the
modality and get agreement **before opening any source file**:

- **A, cloud**: you read sources; the coder uses an API or the handoff.
- **B, reduced exposure**: you see only methodology, template, fictitious examples
  and counts; the coder runs on Ollama; no handoff; you never open sources,
  `.syn` files or the dashboard. Say plainly that this is not fully local.
- **C, local**: you do not take part. Point to VS Code + `@synesis` + Ollama.

## 0b. Language: Synesis stays in English, the conversation follows the researcher

Synesis keywords (`TEMPLATE`, `FIELD`, `ITEM`...), tool output, diagnostics and
`synesis-help` are **English**, and stay English. Everything around them follows
the researcher's language:

1. **Detect it.** The main signal is the language the researcher writes in.
   Confirm with `PY sk.py locale [project.synp]` (system locale, the suggested
   coder language, and what the project `.env` already declares). If the
   researcher writes in Brazilian Portuguese, or the locale is `pt-BR` and they
   have not written yet, use Brazilian Portuguese.
2. **Talk in it.** Explain, ask and summarize in that language. Translate tool
   output, diagnostics and `synesis-help` answers when you relay them; quote
   the original English message (or code, e.g. `SYNESIS_E047`) once, so the
   researcher can look it up.
3. **Write the project's prose in it**: the `DESCRIPTION` and `QUESTIONS` of the
   `.synp`; field `DESCRIPTION`, `GUIDELINES` and value descriptions in the
   `.synt`; ontology definitions. Field names and values may be in that
   language too: `snake_case`, no spaces; prefer no accents in names. Keywords
   stay English.
4. **Make the coder write in it.** Pass `--language "Brazilian Portuguese"` (or
   the `suggested_coder_language`) to every `sk.py code` run; it is recorded in
   the run manifest. If the researcher prefers, they can put
   `SYNESIS_CODER_LANGUAGE=Brazilian Portuguese` in the project `.env`
   themselves. Quotations always stay in the language of the source.
5. Record the choice once: `PY sk.py decide project.synp --type project_language
   --note "<language>; prose, guidelines and coder output in it"`.

## 1. Install (once per machine)

Recommend the **Manual** permission mode so the researcher sees each command.
Windows: `powershell -ExecutionPolicy ByPass -File SKILL_DIR/scripts/install.ps1`
macOS/Linux: `sh SKILL_DIR/scripts/install.sh` (add `--with-graph` only if asked).
Read the report: versions must match (`synesis-coder --version` core = synesis);
the smoke test must say `ok`. In this terminal, call tools through the `bin`
path in the report; new terminals have them on PATH. Then run `PY sk.py doctor`.

## 2. Design (read `references/template_design.md`)

1. Interview the researcher: research questions, kind of sources (interviews
   `.txt/.md`, articles in `.bib` with abstracts, records in TOML), what to
   extract (free codes, closed categories, causal relations, scales).
2. **Consult `synesis-help` before writing or fixing any construct** (it matches
   the installed compiler; see `references/help.md`):
   - `PY sk.py help <words>`: full-text search, JSON (e.g. `help bundle status`);
   - `PY sk.py help --lookup <ID>`: one entry (`TYPE_CHAIN`, `E047`, `BLOCK_EXPORT`);
   - `PY sk.py help --category case_study`: the nine **case studies**, complete
     projects adapted from real research. Start the design from the closest one
     (`GUIDE_CASE_STUDIES` picks by research design) and adapt its vocabulary.
   `synesis help-field <TYPE>` gives the field matrix; `references/language.md`
   is the static fallback. `SKILL_DIR/examples/prova` is a small complete project.
3. Create the project: `.synp` with `QUESTIONS` and an `EXPORT JSON` block with
   a fixed `GENERATED_AT`; `INCLUDE ANNOTATIONS` and `INCLUDE ONTOLOGY` pointing
   to **folders** (an empty `.syno` file does not compile); `.bib`; `fontes/` with
   the source texts named `<bibref>.txt`.
4. Write the template: **GUIDELINES in every field**, Correct/Wrong pairs,
   examples from another topic, one-line values. Show the researcher one example
   ITEM before the full template.
5. `PY sk.py check project.synp` must print `OK`. Then the researcher approves:
   `PY sk.py decide project.synp --type template_approved --note "<who/what>"`.

## 3. Code (read `references/coder.md`)

One run per source, **one at a time**, accepting each before starting the next
(the coder's context includes what was already accepted):

    PY sk.py code project.synp --backend api|handoff --mode document --target <bibref> --input fontes/<bibref>.txt [--language "<language>"]
    PY sk.py code project.synp --backend ... --mode abstract --target <bibref>     # .bib abstract
    PY sk.py accept project.synp --run <run-id>
    ...after all sources:
    PY sk.py code project.synp --backend ... --mode ontology --target ontology

- **api**: needs a key in the project `.env`, typed by the researcher, never in
  the chat. Run a 2-3 source pilot first and report the cost.
- **handoff** (default for subscribers, modality A only): the run stops with
  `pending` requests. Answer each `runs/<id>/requests/<rid>.md` with a fresh
  subagent that reads only that file and writes only `responses/<rid>.txt`
  (exact prompt in `references/coder.md`), then rerun with `--run <id>` until
  `complete`. Declare your model with `--model` on the first pass.

## 4. Validate and audit

    PY sk.py validate project.synp      # diagnostics as JSON-able report; never blocks
    PY sk.py anchor project.synp        # found / not_found / unverifiable per quotation
    PY sk.py dashboard project.synp     # dashboard/dashboard.html, offline, one file

"Ready" means: 0 errors, 0 warnings, every quotation `found`, nothing stale.
Do not say quotations "were verified" unless `anchor` printed `verified=True`.
The researcher audits in the dashboard (marks: correct / wrong / doubt + note),
exports the marks file, and you import it: `PY sk.py marks project.synp --import <file>`.

When a diagnostic appears, look it up before explaining it:
`PY sk.py help --lookup SYNESIS_E0NN` (the entry has the message, what the
compiler checks and the fix), then explain it in the researcher's language.

## 5. Problems: triage before fixing (read `references/triage.md`)

Classify each problem, propose the class, let the researcher confirm, record it:
`PY sk.py decide project.synp --type triage --class <class> --item <id> --note "..."`.
`ambiguous_instruction` → new template version + re-code the audited sample;
`model_failure` → re-run that source; `source_conversion` → fix the text, re-run;
`interpretive_divergence` → the researcher decides; record it.
Never hand-edit `.syn` files unless the researcher asks; the dashboard flags
edits made after acceptance.

## 6. Hand-over

Tell the researcher which guarantee they have (`references/coder.md` §Reproducibility):
re-running the protocol gives *similar* results; the run records reconstruct
*these* results exactly (`PY sk.py rebuild project.synp --out <dir>`).
Version everything except `.env`, `dashboard/`, `saida/`. Summarize: sources coded,
backend and model, decisions you made, open issues.
