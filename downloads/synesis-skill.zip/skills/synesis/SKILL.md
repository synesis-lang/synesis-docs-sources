---
name: synesis
description: Set up and run qualitative research projects in the Synesis language (synesis-lang.org) for a researcher - install the Synesis tools with uv, design a template whose every field has GUIDELINES, code interviews, documents and article abstracts with synesis-coder (API or the researcher's own Claude session via handoff), validate, check that quotations exist in the sources, and build an offline audit dashboard. Use when someone wants to start, code, audit or share a Synesis project (.synp, .synt, .syn, .syno files), or asks to "code my interviews/articles with Synesis".
compatibility: Requires Claude Code in a local session (Claude Desktop Code tab, CLI or IDE extension) with terminal access and internet to install packages from PyPI. Does not work in claude.ai chat or Cowork.
---

# Synesis for researchers

You conduct; the researcher decides; **synesis-coder codes**; **synesis validates**.
Never write or edit ITEM blocks yourself. Never choose categories, theory or
research questions for the researcher: ask, propose, and record what was decided.

Paths below: `SKILL_DIR` is this skill's base directory. `PY` is the Python of the
Synesis tool environment (the installer prints it). Run helpers as
`PY SKILL_DIR/scripts/sk.py <command> <project.synp> ...`.

## 0. Before anything: confidentiality (read `references/confidentiality.md`)

Ask whether the sources contain confidential or personal data, then state the
modality and get agreement **before opening any source file**:

- **A, cloud**: you read sources; the coder uses an API or the handoff.
- **B, reduced exposure**: you see only methodology, template, fictitious examples
  and counts; the coder runs on Ollama; no handoff; you never open sources,
  `.syn` files or the dashboard. Say plainly that this is not fully local.
- **C, local**: you do not take part. Point to VS Code + `@synesis` + Ollama.

## 0b. Language: Synesis stays in English, the conversation follows the researcher

Synesis keywords (`TEMPLATE`, `FIELD`, `ITEM`...), tool output, diagnostics and
`synesis-help` are **English**, and stay English. Everything around them follows
the researcher's language:

1. **Detect it.** The main signal is the language the researcher writes in.
   Confirm with `PY sk.py locale [project.synp]` (system locale, the suggested
   coder language, and what the project `.env` already declares). If the
   researcher writes in Brazilian Portuguese, or the locale is `pt-BR` and they
   have not written yet, use Brazilian Portuguese.
2. **Talk in it.** Explain, ask and summarize in that language. Translate tool
   output, diagnostics and `synesis-help` answers when you relay them; quote
   the original English message (or code, e.g. `SYNESIS_E047`) once, so the
   researcher can look it up.
3. **Write the project's prose in it**: the `DESCRIPTION` and `QUESTIONS` of the
   `.synp`; field `DESCRIPTION`, `GUIDELINES` and value descriptions in the
   `.synt`; ontology definitions. Field names and values may be in that
   language too: `snake_case`, no spaces; prefer no accents in names. Keywords
   stay English.
4. **Make the coder write in it.** Pass `--language "Brazilian Portuguese"` (or
   the `suggested_coder_language`) to every `sk.py code` run; it is recorded in
   the run manifest. If the researcher prefers, they can put
   `SYNESIS_CODER_LANGUAGE=Brazilian Portuguese` in the project `.env`
   themselves. Quotations always stay in the language of the source.
5. Record the choice once: `PY sk.py decide project.synp --type project_language
   --note "<language>; prose, guidelines and coder output in it"`.

## 1. Install (once per machine)

Recommend the **Manual** permission mode so the researcher sees each command.
Windows: `powershell -ExecutionPolicy ByPass -File SKILL_DIR/scripts/install.ps1`
macOS/Linux: `sh SKILL_DIR/scripts/install.sh` (add `--with-graph` only if asked).
Read the report: versions must match (`synesis-coder --version` core = synesis);
the smoke test must say `ok`. In this terminal, call tools through the `bin`
path in the report; new terminals have them on PATH. Then run `PY sk.py doctor`.

## 1b. First session of a project: receive the sources

Researchers rarely know which format their material needs. If the texts are already in `fontes/`
(one `.txt`/`.md` per source), skip the inbox: show the **Your sources** tab, check the encoding, and
write the `.bib` entry of each text yourself (key = file name). Otherwise, once the modality is agreed:

1. `PY sk.py intake FOLDER --lang <page language> --open` (in modality B without `--open`: give the
   path). It creates an inbox folder and `view/index.html`, whose **Your sources** tab explains the
   formats and how to turn PDF into text. Tell the researcher to put the raw files in the inbox.
2. When they say the files are there, run `sk.py intake FOLDER` again. It inspects the files on the
   researcher's computer and prints **only counts by kind**. Add `--names` only in modality A: file
   names can identify people. Never open the inbox in modality B.
3. Recommend a format for each kind of file, **tied to the research questions**, and let the
   researcher decide:
   - `.bib` with abstracts (`--mode abstract`): literature reviews where the abstract is enough; only
     the abstract is coded, never the full article. Say so.
   - `.txt` / `.md` (`--mode document`): interviews, field notes, documents, full articles.
   - `.toml` (`--mode dataset`): sources with the same structure. One record per file; the template
     needs `ON DATASET` fields and the `.synp` `INCLUDE DATASET "fontes/*.toml"`; a project made only of
     records has no `INCLUDE BIBLIOGRAPHY`
     (`sk.py help --lookup MOD_ON_BIBLIOGRAPHY`, `CASE_NEWS_FRAMING`). A spreadsheet can become
     records; propose the sections first, and convert it only in modality A and after approval.
   - **PDF: never read it and retype the text** (retyping changes words, and excerpts must be literal).
     Offer, in this order: the reference with abstract, if it is enough; the researcher converts it to
     `.txt` (UTF-8, one file per document) with the steps on the page; or, **in modality A only**, a
     PDF connector (see "PDF connector" below). The researcher always checks columns, headers,
     hyphenation and scans before `--apply`.
   - Audio, images, `.doc`, `.odt`: the page says what to do with each.
4. After the project exists (§2.3) and the researcher approved, `PY sk.py intake project.synp --apply`.
   It writes `fontes/<key>.txt`, the reference each text needs, and merges `.bib` entries; it never
   changes the originals nor overwrites anything, and records `source_intake` in the decisions. Use
   `--only FILE` for a partial approval. With personal data, or in modality B, use `--keys neutral
   --prefix ent` (`ent01`, `ent02`...): keys go to the prompts and to published files.
5. Add the inbox to `.gitignore` (append the line; create the file if it does not exist). Relay conflicts (same reference key, different content): the
   researcher decides which one stays.

**PDF connector (modality A only, optional).** Example: *PDF Tools* by Open Document Alliance (a
third-party desktop extension, <https://claude.com/marketplace/connectors/pdf-tools>). It reads the
PDF on the researcher's computer, but what its tools return is sent to Anthropic: say so first. In
modality B or C, do not offer it. Never install it yourself; the researcher decides.

- First see whether a PDF tool is available in this session. If not, the researcher can add it from
  the connector directory and allow the project folder in its settings; a desktop extension may not
  reach the Code tab, so if it does not appear, fall back to the manual conversion.
- Use only a tool that **writes the file itself**. With PDF Tools: `convert_pdf_to_markdown` with
  `output_path` in the inbox, at most 10 pages per call, named `NAME.p001-010.md`,
  `NAME.p011-020.md`...; `include_page_boundaries: false`. `NAME` is the PDF name without
  extension. Never copy the returned text into a file by hand, and never use the e-signing tools.
- `PY sk.py intake FOLDER --join` joins the parts locally, word for word, and removes Markdown
  escapes; it refuses a sequence with a missing part. Relay the gaps and warnings the tool reported.
- Scanned pages need OCR: do not transcribe page images yourself. Send the researcher to OCR software.

## 2. Design (read `references/template_design.md`)

1. Interview the researcher: research questions, the sources received (§1b), what to
   extract (free codes, closed categories, causal relations, scales).
2. **Consult `synesis-help` before writing or fixing any construct** (it matches
   the installed compiler; see `references/help.md`):
   - `PY sk.py help <words>`: full-text search, JSON (e.g. `help bundle status`);
   - `PY sk.py help --lookup <ID>`: one entry (`TYPE_CHAIN`, `E047`, `BLOCK_EXPORT`);
   - `PY sk.py help --category case_study`: the nine **case studies**, complete
     projects adapted from real research. Start the design from the closest one
     (`GUIDE_CASE_STUDIES` picks by research design) and adapt its vocabulary.
   `synesis help-field <TYPE>` gives the field matrix; `references/language.md`
   is the static fallback. `SKILL_DIR/examples/prova` is a small complete project.
3. Create the project: `.synp` with `QUESTIONS` and an `EXPORT JSON` block with
   a fixed `GENERATED_AT`; `INCLUDE ANNOTATIONS` and `INCLUDE ONTOLOGY` pointing
   to **folders**; `INCLUDE BIBLIOGRAPHY` to one `.bib`; `fontes/` with the source texts
   named `<bibref>.txt` (§1b.4 fills them).
4. Write the template: **GUIDELINES in every field**, Correct/Wrong pairs,
   examples from another topic, one-line values. Show the researcher one example
   ITEM before the full template.
5. `PY sk.py check project.synp` must print `OK`. Then the researcher approves:
   `PY sk.py decide project.synp --type template_approved --note "<who/what>"`.

## 2b. Let the researcher read the files (friendly view)

Researchers should not have to read raw Synesis code in a text editor. `PY sk.py view project.synp`
writes `view/index.html` next to the project: one offline page, read-only, built from the project
itself (field names, types, scopes, relations and values come from the template; nothing is tied to
a particular template). Tabs:

- **Overview**: title, description and research questions; corpus size; a *validation and review*
  strip (compiler errors and warnings with a short plain-language message, excerpts not located in
  the source, files changed since acceptance, runs awaiting acceptance); a concepts-by-source matrix
  whose cells open the occurrences (excerpt, memo, concepts, validation state, link to the block).
- **Your sources**: formats, PDF instructions and the inventory of the inbox (§1b); it opens first while
  nothing is coded.
- **Where to start**: the next steps for this project, computed from its state, and how to cite
  Synesis.
- One tab per kind of file (awaiting acceptance, project, template, ontology, annotations,
  references): every block is a card with its line, its problems, where it came from (accepted in
  run N, changed since acceptance, written by hand) and an **Ask Claude** button.
- **Possibilities**: research intentions (compare, connect, organize, support an interpretation)
  mapped to Synesis features, with what this project already has and a request to adapt.

Hovering a word of the language (SCOPE, TYPE, END ITEM...) explains it in plain words.

**Requests pasted from the view.** *Ask Claude* and *Copy request to adapt* copy a request that the
researcher pastes into this conversation. They name the project, the file and the line, quote the
compiler message, and always end with "do not change any file before I approve". Treat them as the
researcher's own request: read the file at that line (in modality B, do not: explain from the
diagnostic and let the researcher look), explain in plain language, propose the change and wait for
approval. When the problem is in a `.syn`, propose its class first (§5): what usually changes is the
template or the source, followed by a new run, not the annotation. Requests from *Possibilities* ask you to clarify the intention first: ask
those questions before proposing a structure, and follow §2 (template design) for any change.

- It refreshes by itself after `check`, after a finished `code` run and after `accept`; run it
  yourself after you write or change a `.synp`, `.synt`, `.syno` or `.syn`. Add `--open` to open it
  in the browser.
- **The page speaks the language of the project.** It follows, in this order: the `project_language`
  decision (§0b), `SYNESIS_CODER_LANGUAGE` in the project `.env`, the language of the latest coder
  run, and the project's own prose (descriptions, questions, guidelines, memos; never the excerpts,
  which are in the language of the source); only then the operating system. `sk.py view` prints the
  language and where it came from. Recording the decision in §0b is what makes it certain;
  `--lang en|pt|es|fr|de|it|zh` forces it for one build. The interface exists in English, Portuguese,
  Spanish, French, German, Italian and Simplified Chinese; for any other project language it is in
  English. Only the interface is translated: the project's own text is shown as written.
- Tell the researcher the path and what to look at ("open `view/index.html`; the template is under
  Template, your proposals under Awaiting your acceptance"). **Do not paste file contents into the
  chat** when the view can show them, and ask the researcher to read the template and one or two
  items before you continue.
- It reads the Synesis, `.bib` and `.toml` files and compiles the project; to say whether each
  excerpt is located in its source it runs the same check as `sk.py anchor`, so in **modality B** you
  generate it and give the path, but you do not open it. It never changes the project and loads
  nothing from the network; the documentation and GitHub links only open when the researcher clicks.

## 3. Code (read `references/coder.md`)

One run per source, **one at a time**, accepting each before starting the next
(the coder's context includes what was already accepted):

    PY sk.py code project.synp --backend api|handoff --mode document --target <bibref> --input fontes/<bibref>.txt [--language "<language>"]
    PY sk.py code project.synp --backend ... --mode abstract --target <bibref>     # .bib abstract
    PY sk.py code project.synp --backend ... --mode dataset --target <record id> --input fontes/<file>.toml   # one record
    PY sk.py accept project.synp --run <run-id>
    ...after all sources:
    PY sk.py code project.synp --backend ... --mode ontology --target ontology

- **api**: needs a key in the project `.env`, typed by the researcher, never in
  the chat. Run a 2-3 source pilot first and report the cost.
- **handoff** (default for subscribers, modality A only): the run stops with
  `pending` requests. Answer each `runs/<id>/requests/<rid>.md` with a fresh
  subagent that reads only that file and writes only `responses/<rid>.txt`
  (exact prompt in `references/coder.md`), then rerun with `--run <id>` until
  `complete`. Declare your model with `--model` on the first pass. While requests are pending the
  coder logs `LLM call failed` or `failed validation`: it is the expected pause, not an error.

## 4. Validate and audit

    PY sk.py validate project.synp      # diagnostics as JSON-able report; never blocks
    PY sk.py anchor project.synp        # found / not_found / unverifiable per quotation
    PY sk.py dashboard project.synp     # dashboard/dashboard.html, offline, one file

"Ready" means: 0 errors, 0 warnings, every quotation `found`, nothing stale.
Do not say quotations "were verified" unless `anchor` printed `verified=True`.
The researcher audits in the dashboard (marks: correct / wrong / doubt + note),
exports the marks file, and you import it: `PY sk.py marks project.synp --import <file>`.

When a diagnostic appears, look it up before explaining it:
`PY sk.py help --lookup SYNESIS_E0NN` (the entry has the message, what the
compiler checks and the fix), then explain it in the researcher's language.

## 5. Problems: triage before fixing (read `references/triage.md`)

Classify each problem, propose the class, let the researcher confirm, record it:
`PY sk.py decide project.synp --type triage --class <class> --item <id> --note "..."`.
`ambiguous_instruction` → new template version + re-code the audited sample;
`model_failure` → re-run that source; `source_conversion` → fix the text, re-run;
`interpretive_divergence` → the researcher decides; record it.
Never hand-edit `.syn` files unless the researcher asks; the dashboard flags
edits made after acceptance.

## 6. Hand-over

Tell the researcher which guarantee they have (`references/coder.md` §Reproducibility):
re-running the protocol gives *similar* results; the run records reconstruct
*these* results exactly (`PY sk.py rebuild project.synp --out <dir>`).
Version everything except `.env`, the inbox, `dashboard/`, `view/`, `saida/`. Summarize: sources coded,
backend and model, decisions you made, open issues.
