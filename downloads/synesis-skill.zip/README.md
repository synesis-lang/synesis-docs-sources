# Synesis for researchers — a Claude plugin

This plugin lets a researcher run a qualitative research project in the
[Synesis](https://synesis-lang.org) language from the Claude Desktop **Code** tab (or Claude Code
in a terminal or IDE). Claude conducts the work, the researcher decides, **synesis-coder** codes,
and **synesis** validates. The plugin installs the Synesis tools, helps design a template whose
every field has guidelines, codes sources one at a time, checks that every quotation exists in
its source, lets the researcher read the files in a friendly project view, and builds an offline
dashboard to audit the result.

Documentation: **<https://synesis-lang.org>** · Guide for researchers:
[docs/RESEARCHER_GUIDE.md](docs/RESEARCHER_GUIDE.md) · Privacy: [PRIVACY.md](PRIVACY.md)

## What it does

- **Installs** the Synesis tools in one isolated environment, with exact pinned versions.
- **Designs** the research template with you: fields, types, relations, and **GUIDELINES in every
  field** (correct/wrong pairs), starting from a complete small example.
- **Codes** each source with `synesis-coder`, either through an API key you provide or by handing
  each request to your own Claude session (**handoff**), keeping a record of every run.
- **Receives your sources**: you drop the files in a folder; a local script says what each one is and
  how it can be used (`.bib` with abstracts, text, Word, TOML records), and prepares what you approve.
  The plugin does not convert PDF: the page explains how to turn it into text, or how a PDF
  connector you choose can do it.
- **Validates** with the Synesis compiler and **anchors** every quotation: it is *found*,
  *not found* or *unverifiable* in the original text.
- **Shows the project** in a friendly, read-only **project view** (`view/index.html`), built from
  your own template: an overview with the research questions, the state of validation and a
  concepts-by-source matrix that leads to the evidence; a "where to start" tab with the next steps;
  every block as a card with its problems and its origin; plain-language help on the words of the
  language; and a tab of research possibilities with requests you can adapt and paste to Claude.
  Large projects are read in breadth and depth (as in *Big Qual*): counts and the matrix cover the
  whole project, the cards are a panoramic selection, a stratified sample or one group read whole.
- **Reviews a sample** on its own page (`review/index.html`): the script draws and freezes a
  stratified sample of annotations; you approve, reject or doubt each one (optional 1–5 scale,
  reason, proposed correction), blind to the model. The export is one file for the coordinator of
  the project, with instructions for the AI that reads it, so a team can review on their own
  computers; Claude imports every file, reports the rejection observed in the sample and an estimate
  weighted by group, the agreement (Cohen's kappa, Krippendorff's alpha), and puts the proposed
  corrections side by side for the coordinator to approve.
- **Shows the results** in an offline page (`dashboard/dashboard.html`), with the reviews. In a large
  project it does not build that page: it shows you how to read the results with the Synesis tools
  directly (`synesis compile --xls/--csv/--json`, `synesis export`, the VS Code extension). The plugin
  teaches the language and reviews the data; it does not replace the tools.
- **Measures the project first** (`sk.py size`): in a large project Claude does not open the files
  itself and says how long a complete pass takes before starting one.
- **Consults the reference guide** (`synesis-help`) for every construct and diagnostic, and starts
  designs from nine complete case studies adapted from real research.
- **Talks to you in your language.** Synesis keywords and tool messages stay in English; Claude
  translates them and writes the prose of your project (descriptions, guidelines) in your language.

## Requirements

- A **local** Claude Code session: Claude Desktop **Code** tab, the CLI, or an IDE extension, with
  terminal access. It does not work in claude.ai chat or Cowork.
- Internet for the first installation (PyPI, and `uv` if it is missing).
- Windows, macOS or Linux. Tested end to end on Windows; the installers for macOS and Linux have
  not been run on those systems yet.
- Python is **not** required: the installer uses `uv`, which provides its own.

## Install

- **From the package:** in Claude Desktop, **Customize → Plugins → Add**, then upload
  `synesis-plugin-<version>.zip` (built with `python tools/build_dist.py` in the repository).
- **From the marketplace:**
  - Code tab: **+ → Add plugins**, then add `synesis-lang/synesis-skill`;
  - CLI: `/plugin marketplace add synesis-lang/synesis-skill`, then
    `/plugin install synesis@synesis-lang`.

On first use the skill installs the tools itself (`skills/synesis/scripts/install.ps1` on Windows,
`install.sh` elsewhere). Use the **Manual** permission mode, so you see each command before it runs.

## Try it

Say, for example:

1. *"I want to code three interviews about community gardens with Synesis; the transcripts are in
   the `fontes` folder."* — Claude asks about confidentiality, installs the tools, interviews you
   about the study, writes and shows a template, codes each interview, builds the ontology and
   opens the project view and the dashboard.
2. *"I have 20 articles in `refs.bib` for a review on the social acceptance of wind farms; extract
   the factors and their direction."* — Claude proposes a template with relations and qualifiers,
   runs a 2-source pilot with your API key to show the cost, then codes the rest.
3. *"Audit the project: show me what is not anchored and why."* — Claude runs the validation and
   the anchor check, draws a sample for you to review, imports your answers and walks you through
   the triage of each problem.
4. *"Open my project."* on a large one — Claude measures it, offers a numbered list of what you can
   do, and builds a panoramic view in seconds instead of a page too heavy to open.

A complete, small starter project with fictitious sources is in
`skills/synesis/examples/prova/`.

## What this plugin runs, sends and fetches

| What | When | Where it goes |
|---|---|---|
| Installs **`uv`** from `https://astral.sh/uv/install.ps1` (`irm … \| iex` with `-ExecutionPolicy ByPass` for that one command) or `https://astral.sh/uv/install.sh` (`curl … \| sh`); on Windows it falls back to `winget` | first use, **only if `uv` is not already installed**, after you approve the command | downloads from astral.sh and GitHub; to avoid it, install `uv` yourself first ([docs.astral.sh/uv](https://docs.astral.sh/uv/)) and the installer skips this step |
| `uv tool install synesis==0.16.0` with `synesis-coder==0.15.1`, `synesis-help==0.4.0` (and `synesis-graph==0.13.1` only if you ask for it) | first use | downloads exact versions from PyPI |
| Runs `synesis`, `synesis-coder`, `synesis-help` and `scripts/sk.py` | during the work | local only |
| `sk.py intake` | when you add sources | reads the files of the inbox folder on your computer, prints only counts, and writes `fontes/`, the bibliography and `view/`; no network |
| `sk.py view` | when files change | writes `view/index.html` in your project; local only, no network |
| `sk.py review` | when you review a sample | writes `review/index.html` and the sample in `runs/audit/`; your answers stay in your browser until you export them; local only, no network |
| `sk.py size` | when a project is opened | counts the blocks of the project files; prints counts only; no network |
| **api** backend: `synesis-coder` calls the model set in the project `.env` | coding, only if you chose it and typed a key | the provider you chose (Anthropic, OpenRouter…) receives the source texts and bills you |
| **handoff** backend: requests are answered by your own Claude session | coding, default for subscribers | Anthropic, as in any use of Claude Code |
| Claude reads sources, annotations, the dashboard or the view | confidentiality **modality A** only | Anthropic, as in any use of Claude Code |

The plugin collects no data of its own and sends nothing anywhere else. It has no hooks and no
MCP server. API keys are typed by you into the project `.env` and never pass through the chat.
Confidentiality modalities (A, B, C) are in `skills/synesis/references/confidentiality.md`.
Full details: [PRIVACY.md](PRIVACY.md).

## Layout

```
.claude-plugin/plugin.json   manifest
skills/synesis/
  SKILL.md                   the workflow Claude follows
  references/                confidentiality, template design, coder + handoff, triage, help, language,
                             project view, review
  scripts/install.*          uv + synesis, synesis-coder, synesis-help (pinned) in one environment
  scripts/sk.py              helpers: doctor, check, validate, anchor, code, accept, decide, size,
                             view, review, dashboard, intake, rebuild, runs, locale, help, marks (old)
  scripts/sklib/             the helper library (uses the published packages, never modifies them)
  assets/dashboard.html      offline results page template (no CDN, data embedded)
  examples/prova/            clean starter project (fictitious sources)
docs/                        guide for researchers (English; Portuguese translation in docs/pt/)
LICENSE  NOTICE  PRIVACY.md
```

## Support and contact

- Bugs, questions and suggestions: <https://github.com/synesis-lang/synesis-skill/issues>
- Security reports: see [SECURITY.md](../SECURITY.md) in the repository.
- Documentation and the Synesis language: <https://synesis-lang.org>
- Contact: christiandebritto@usp.br

## License

Licensed under the **Apache License, Version 2.0** (see [LICENSE](LICENSE) and [NOTICE](NOTICE)).
The Synesis packages that the plugin installs are separate works under their own license
(AGPL-3.0-only with the Synesis Data-Output Exception); the plugin only runs them.

If you use Synesis in academic work, please cite it (see the `CITATION.cff` file of the Synesis
repositories).
