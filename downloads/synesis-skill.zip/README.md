# synesis-skill

Claude skill (packaged as a Claude Code plugin) that lets a researcher run a
[Synesis](https://synesis-lang.org) project from the Claude Desktop **Code** tab: install the
Synesis tools, design a template whose every field has GUIDELINES, code sources with
synesis-coder, validate, check quotations against the sources, and audit the result in an
offline dashboard.

Status: **v0.1.0, ready for testing with researchers**. It was tested end to end on Windows
with synesis 0.15.0, synesis-coder 0.15.0 and synesis-help 0.3.0 (`proof/prova`), and has
not been evaluated with researchers yet. Guide for researchers (Portuguese):
[docs/GUIA_DO_PESQUISADOR.md](docs/GUIA_DO_PESQUISADOR.md).

## Install

- **From the package:** in Claude Desktop, **Customize → Plugins → Add**, then upload
  `synesis-plugin-<version>.zip` (built with `python tools/build_dist.py`).
- **From the marketplace:**
  - Code tab: **+ → Add plugins**, then add `synesis-lang/synesis-skill`;
  - CLI: `/plugin marketplace add synesis-lang/synesis-skill`, then
    `/plugin install synesis@synesis-lang`.

The skill only works in a **local Claude Code session** (Desktop Code tab, CLI or IDE), and
not in claude.ai chat or Cowork: it needs a terminal and the researcher's disk. On first use
it installs the Synesis tools itself (`skills/synesis/scripts/install.ps1` or `install.sh`).

## What this plugin runs, sends and fetches

| What | When | Where it goes |
|---|---|---|
| Installs `uv` (astral.sh installer, or winget on Windows) | first use, only if `uv` is missing, after the researcher approves | downloads from astral.sh / GitHub |
| `uv tool install synesis==0.15.0` with synesis-coder 0.15.0 and synesis-help 0.3.0 (exact versions) | first use | downloads from PyPI |
| Runs `synesis`, `synesis-coder` and `scripts/sk.py` locally | during the work | local only |
| **api** backend: synesis-coder calls the model set in the project `.env` | coding, only if the researcher chose it and provided a key | the chosen provider (Anthropic, OpenRouter…) receives the source texts |
| **handoff** backend: requests are answered by the researcher's own Claude session | coding, default for subscribers | Anthropic, as ordinary use of Claude Code |
| Claude reading sources, annotations, the dashboard | confidentiality modality A only | Anthropic |

The plugin collects no data of its own and sends nothing anywhere else. API keys are typed
by the researcher into the project `.env` and never pass through the chat. Confidentiality
modalities: `skills/synesis/references/confidentiality.md`.

## Usage examples

1. **"Quero codificar três entrevistas sobre hortas comunitárias; as transcrições estão em
   `fontes/`."** The skill asks about confidentiality, installs the tools, interviews the
   researcher, writes and shows a template, codes each interview (handoff), builds the
   ontology and opens the dashboard.
2. **"I have 20 articles in `refs.bib` for a review on social acceptance of wind farms;
   extract factors and their direction."** The skill proposes a template with relations and
   qualifiers, runs a 2-source pilot with the API to measure cost, then codes the rest.
3. **"Audit the project: show me what is not anchored and why."** The skill runs
   `sk.py validate` and `sk.py anchor`, rebuilds the dashboard, imports the researcher's
   marks and walks through the triage of each problem.

## Layout

```
.claude-plugin/          plugin.json, marketplace.json
skills/synesis/
  SKILL.md               the workflow Claude follows
  references/            confidentiality, template design, coder + handoff, triage, language
  scripts/install.*      uv + synesis, synesis-coder, synesis-help (pinned) in one environment
  scripts/sk.py          helpers: doctor, check, validate, anchor, code, accept, decide, marks, dashboard, rebuild, runs
  scripts/sklib/         the helper library (uses the published packages, never modifies them)
  assets/dashboard.html  offline dashboard template (no CDN, data embedded)
  examples/prova/        clean starter project (fictitious sources) shipped in the package
docs/                    guide for researchers
proof/prova/             the end-to-end proof with its full run record (repository only)
tests/                   pytest (14 tests)
tools/build_dist.py      builds and checks the installable zip
tools/build_references.py   regenerates references/language.md from synesis-docs-sources
```

## What the proof established (2026-11-20)

- **Installation:** one environment for the three CLIs; both installers pass their smoke
  test with pinned versions.
- **Handoff without changing synesis-coder:** the coder builds every prompt from the
  template and validates every answer. Request ids are stable across processes.
- **API path:** the same project completed through the API.
- **Result:** 0 errors, 0 warnings, every quotation found.
- **Planted problems are detected:** an invented quotation is `not_found`, a source without
  text is `unverifiable`, a file edited after acceptance is `stale`. Stale or tampered runs
  are refused at acceptance.
- **Reconstruction is byte-identical** from a copy in another folder.

**Not established:**
- handoff vs API with the same model;
- evaluation with researchers;
- real runs of the installer on macOS/Linux;
- rendering in a real browser (jsdom was used).

## Ecosystem defects found here

The full list is in `synesis-planning/synesis/Correcoes_Ecossistema_Achados_Skill.md`.

| Defect | State |
|---|---|
| Compiler dropped continuation lines silently (C-1) | fixed in a synesis branch, awaiting release |
| Empty `.syno` did not compile, so no first ontology (C-2/D-1) | fixed in a synesis branch, awaiting release; the skill keeps a shim until then |
| `synesis-coder anchor` reported "no problems" without checking (D-2) | fixed in a synesis-coder branch, awaiting release |
| Absolute paths in the JSON (C-3) | open; the skill relativizes |
| Alpaca export drops the epistemic status of relations | open; see `Estudo_Exportacao_Alpaca_Dirigida_pelo_Template.md` |

## License

AGPL-3.0 with the Synesis Data-Output Exception for the implementation, and a permissive
license for the copyable starter material (`skills/synesis/examples/`). Exact texts, notices
and SPDX identifier are pending legal review before publication. Please cite Synesis in
academic work.
