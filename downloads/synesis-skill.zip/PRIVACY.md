# Privacy

This is the privacy statement of the **Synesis plugin** for Claude (`synesis-skill`). It
explains what the plugin does with your data. Questions: see [Contact](#contact).

## In short

- The plugin **collects no data of its own**. It has no servers, no analytics, no telemetry and
  no accounts.
- It works on **your computer**. Your project files (sources, annotations, ontology, run
  records, dashboard, project view) stay in the project folder you chose, under your control.
- Your source texts leave your computer **only** through the coding backend you choose, as
  described below.

## What leaves your computer, and when

| Situation | Who receives what |
|---|---|
| You read or discuss your files in the Claude session (confidentiality **modality A**) | Anthropic receives what Claude reads, as in any use of Claude. See Anthropic's [privacy policy](https://www.anthropic.com/legal/privacy). |
| **handoff** coding (default for subscribers) | The coding requests are answered by your own Claude session; Anthropic receives them as in any use of Claude. |
| **api** coding, only if you choose it and type a key in the project `.env` | The provider you configured (for example Anthropic or OpenRouter) receives the source texts and the template, and bills you. See that provider's privacy policy, for example OpenRouter's [privacy policy](https://openrouter.ai/privacy). |
| Local model (for example Ollama), **modality B** | Nothing leaves your computer for the coding. Claude only sees the method, invented examples and counts. |
| **PDF connector**, only if you add one yourself and ask Claude to use it (modality A) | The connector is a third-party product with its own terms. What its tools return to Claude goes to Anthropic, as in any use of Claude. |
| First-time installation | Your computer downloads `uv` from astral.sh (only if it is missing) and the pinned Synesis packages from PyPI. No data of yours is sent. |

You choose the modality **before** any source file is opened, and Claude states it back to
you. For data under strict legal or ethical confidentiality, use **modality C** (no Claude
involvement): Synesis in VS Code with a local model.

## What is stored, and where

- The plugin writes only inside your project folder: the inbox and `fontes/` (your sources), annotations, ontology, `runs/` (the record
  of each run: requests to the model, answers, decisions), `dashboard/`, `view/`, `review/` and
  `saida/`. The review page keeps your answers in your browser until you export them; imported
  answers are kept in `runs/audit/`.
  These files may contain text from your sources. Treat the folder with the same care as the
  sources themselves.
- **API keys** are typed by you into the project `.env`, never into the chat. The plugin's own
  scripts read only the `SYNESIS_CODER_LANGUAGE` line of that file, to detect your language. In
  **api** mode, `synesis-coder` reads the key from it to call the provider you configured.
- Nothing is uploaded or synchronized by the plugin. Retention is up to you: delete the folder,
  or the `runs/` folder, whenever you wish. Deleting `runs/` removes the audit trail, not the
  annotations.

## Personal data and age

The plugin does not itself read or keep personal data, but your sources may contain it
(interviews, for example). You are responsible for having the right to process them and for
choosing the modality that fits their confidentiality. The plugin is **intended for adult
researchers**, and not for people under 18.

## Third parties

The plugin does not send data to any service other than the ones you choose above. It installs
open-source packages from PyPI and the `uv` tool from astral.sh; see their own policies.

## Changes

Changes to this statement are recorded in the repository history.

## Contact

Open an issue at <https://github.com/synesis-lang/synesis-skill/issues>, or write to
**christiandebritto@usp.br**. Documentation: <https://synesis-lang.org>.
