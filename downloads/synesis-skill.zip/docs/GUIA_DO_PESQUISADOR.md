# Synesis no Claude — guia do pesquisador

Este guia mostra como usar o Synesis com a ajuda do Claude para organizar e codificar suas
fontes (entrevistas, artigos, documentos) e auditar o resultado num painel que abre no seu
computador.

Você conduz as decisões de pesquisa. O Claude instala as ferramentas, conversa com você
sobre o desenho do estudo, prepara os arquivos, roda a codificação e monta o painel.

---

## 1. O que você precisa

- **Claude Desktop** instalado (Windows ou macOS), numa conta com plano pago e acesso à
  aba **Code**.
- **Uma pasta** no seu computador para o projeto, com as suas fontes:
  - entrevistas e documentos em `.txt` ou `.md`;
  - artigos numa bibliografia `.bib` com os resumos.
- **Internet** na primeira vez, para instalar as ferramentas.
- **Cerca de uma hora** para a primeira sessão.

Você **não** precisa instalar Python nem saber programar. O VS Code também é opcional: só
serve para quem quiser ler os arquivos do projeto diretamente.

## 2. Instalar o plugin (uma vez)

1. No Claude Desktop, abra **Customize → Plugins** e use **Add** para enviar o arquivo
   `synesis-plugin-<versão>.zip` que você recebeu.
2. Se a sua organização não permitir enviar plugins, peça ao administrador, ou use o
   marketplace: na aba **Code**, botão **+** → **Add plugins** → adicione
   `synesis-lang/synesis-skill`.
3. O Desktop avisa para instalar só plugins em que você confia. Este é o plugin do projeto
   Synesis.

## 3. Primeira sessão

1. Abra a aba **Code** e escolha a **pasta do projeto**.
2. Escolha o modo de permissão **Manual**. Assim o Claude pede a sua aprovação antes de cada
   comando, e você vê o que será instalado.
3. Escreva, por exemplo:
   > Quero codificar minhas três entrevistas sobre hortas comunitárias com o Synesis.
   > As transcrições estão na pasta `fontes`.

O Claude vai então, em ordem:
1. **Perguntar sobre sigilo** antes de abrir qualquer arquivo (§5).
2. **Instalar as ferramentas** do Synesis e mostrar um relatório. Isso só acontece uma vez
   por computador.
3. **Conversar sobre o estudo:** suas perguntas de pesquisa, o que deve ser extraído das
   fontes e se você quer categorias livres ou fechadas, relações de causa ou escalas.
4. **Escrever o template,** que é a descrição do que será codificado, e mostrar um exemplo
   antes de seguir. **Você aprova o template.**
5. **Codificar cada fonte,** uma por vez.
6. **Validar e montar o painel.**

## 4. Custos

Há dois modos de codificação, e o Claude explica os dois antes de começar:

| Modo | Quem codifica | Custo |
|---|---|---|
| **Sessão do Claude (handoff)** | o próprio Claude da sua assinatura | coberto pela assinatura, dentro dos limites do plano |
| **API** | um modelo por chave de API (Anthropic, OpenRouter) | cobrado pelo provedor; o Claude faz um piloto com 2–3 fontes e mostra o custo antes de codificar tudo |

**Chaves de API nunca devem ser digitadas no chat.** O Claude cria um arquivo `.env` na
pasta do projeto com o campo vazio, e você cola a chave diretamente nesse arquivo.

## 5. Sigilo dos dados

Tudo o que o Claude lê sai do seu computador e vai para a Anthropic (e, no modo API, para o
provedor escolhido). Por isso o Claude pergunta antes de abrir as fontes e propõe uma
modalidade:

- **A — Nuvem:** o Claude lê as fontes. Use quando não houver dados sigilosos.
- **B — Exposição reduzida:** o Claude trabalha só com o método e com exemplos inventados;
  a codificação roda num modelo local (Ollama). **Não é um processamento inteiramente
  local.**
- **C — Local:** o Claude não participa. Para dados sob sigilo legal ou ético estrito, use
  o Synesis no VS Code com um modelo local.

## 6. Auditar o resultado

O painel fica em `dashboard/dashboard.html`. Ele abre com dois cliques, sem internet e sem
servidor.

| Aba | O que mostra |
|---|---|
| **Fontes** | cada trecho codificado, com a citação, a nota e os códigos. A citação é marcada como *encontrada*, *não encontrada* ou *não verificável* no texto original |
| **Códigos** | cada código, com a definição e todas as evidências |
| **Relações**, **Questões** | as relações entre conceitos e onde estão as evidências de cada pergunta de pesquisa |
| **Qualidade** | o que ainda precisa de atenção |
| **Método** | o template completo e como o resultado foi produzido |

**Para registrar a sua auditoria:**
1. Marque os trechos e códigos como *correto*, *incorreto* ou *dúvida*, com uma nota.
2. Use **Exportar marcações** e entregue o arquivo ao Claude na conversa, para que ele o
   registre no projeto. **As marcações não exportadas ficam só no navegador e podem se
   perder.**

**Quando algo estiver errado,** o Claude não corrige o trecho à mão. Ele classifica o
problema com você antes de agir: instrução ambígua no template, falha pontual, texto-fonte
mal convertido ou divergência legítima de interpretação.

## 7. O que fica na pasta do projeto

| Arquivo ou pasta | Conteúdo |
|---|---|
| `*.synp` | o projeto |
| `template.synt` | o método |
| `*.bib` | as fontes bibliográficas |
| `fontes/` | os textos |
| `anotacoes/`, `ontologia/` | o resultado da codificação |
| `runs/` | o registro de cada execução: o que foi pedido ao modelo, o que ele respondeu e as decisões que você tomou |
| `dashboard/`, `saida/` | arquivos gerados, que podem ser refeitos a qualquer momento |

Guarde a pasta inteira, exceto o `.env`. Com ela, qualquer pessoa reconstrói exatamente os
seus resultados e o seu painel.

## 8. Se algo der errado

- **"comando não encontrado"** logo depois da instalação: abra uma nova sessão na aba Code.
  Na mesma sessão, o Claude usa o caminho completo das ferramentas.
- **O Windows bloqueou o instalador:** o Claude tenta outro caminho (winget). Se a máquina
  for institucional, pode ser preciso falar com o suporte de TI.
- **Dúvidas sobre a linguagem:** peça ao Claude, que consulta o guia de referência
  instalado (`synesis-help`).
- **Erros do Synesis e sugestões:** abra uma *issue* em
  <https://github.com/synesis-lang/synesis-skill>.

---

Se usar o Synesis num trabalho acadêmico, cite o software (veja o arquivo `CITATION.cff`
dos repositórios do Synesis).
