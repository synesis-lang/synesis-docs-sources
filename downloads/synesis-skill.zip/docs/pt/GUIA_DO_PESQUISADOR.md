# Synesis no Claude — guia do pesquisador

> Tradução de [RESEARCHER_GUIDE.md](../RESEARCHER_GUIDE.md). Em caso de diferença, vale a versão em inglês.

Este guia mostra como usar o Synesis com a ajuda do Claude para organizar e codificar suas
fontes (entrevistas, artigos, documentos), conferir o resultado e ver o que ele encontrou, em
páginas que abrem no seu computador.

Você conduz as decisões de pesquisa. O Claude instala as ferramentas, conversa com você
sobre o desenho do estudo, prepara os arquivos, roda a codificação e monta três páginas: a
**visão do projeto**, a **conferência** e os **resultados**.

---

## 1. O que você precisa

- **Claude Desktop** instalado (Windows ou macOS), numa conta com plano pago e acesso à
  aba **Code**.
- **Uma pasta** no seu computador para o projeto, com as suas fontes:
  - entrevistas e documentos em `.txt` ou `.md`;
  - artigos numa bibliografia `.bib` com os resumos.
- **Internet** na primeira vez, para instalar as ferramentas.
- **Cerca de uma hora** para a primeira sessão.

Você **não** precisa instalar Python nem saber programar. O VS Code também é opcional: só
serve para quem quiser ler os arquivos do projeto diretamente.

## 2. Instalar o plugin (uma vez)

1. No Claude Desktop, abra **Customize → Plugins** e use **Add** para enviar o arquivo
   `synesis-plugin-<versão>.zip` que você recebeu.
2. Se a sua organização não permitir enviar plugins, peça ao administrador, ou use o
   marketplace: na aba **Code**, botão **+** → **Add plugins** → adicione
   `synesis-lang/synesis-skill`.
3. O Desktop avisa para instalar só plugins em que você confia. Este é o plugin do projeto
   Synesis.

## 3. Primeira sessão

1. Abra a aba **Code** e escolha a **pasta do projeto**.
2. Escolha o modo de permissão **Manual**. Assim o Claude pede a sua aprovação antes de cada
   comando, e você vê o que será instalado.
3. Escreva, por exemplo:
   > Quero codificar minhas entrevistas sobre hortas comunitárias com o Synesis. Onde ponho os arquivos?

   O Claude cria uma pasta para eles e abre uma página, **Suas fontes**, que explica os formatos
   (referências com resumo, textos, registros). Você copia os arquivos do jeito que estão; um programa
   os examina **no seu computador**, e você decide como cada tipo será usado. Arquivos **PDF** precisam
   ser convertidos por você em `.txt`: a página mostra como, e o que conferir.

O Claude vai então, em ordem:
1. **Perguntar sobre sigilo** antes de abrir qualquer arquivo (§5).
2. **Instalar as ferramentas** do Synesis e mostrar um relatório. Isso só acontece uma vez
   por computador.
3. **Conversar sobre o estudo:** suas perguntas de pesquisa, o que deve ser extraído das
   fontes e se você quer categorias livres ou fechadas, relações de causa ou escalas.
4. **Escrever o template,** que é a descrição do que será codificado, e mostrar um exemplo
   antes de seguir. **Você aprova o template.**
5. **Codificar cada fonte,** uma por vez.
6. **Validar, pedir que você confira uma amostra e montar a página de resultados.**

Quando você volta a um projeto que já existe, o Claude primeiro mede o tamanho dele (um segundo,
sem ler os seus arquivos) e oferece uma lista curta e numerada do que dá para fazer: conhecer o
projeto, ler mais a fundo, conferir uma amostra das anotações, ver os resultados, descobrir o que
o projeto pode responder, resolver problemas, continuar, exportar. Escolha uma ou mais opções.

## 4. Custos

Há dois modos de codificação, e o Claude explica os dois antes de começar:

| Modo | Quem codifica | Custo |
|---|---|---|
| **Sessão do Claude (handoff)** | o próprio Claude da sua assinatura | coberto pela assinatura, dentro dos limites do plano |
| **API** | um modelo por chave de API (Anthropic, OpenRouter) | cobrado pelo provedor; o Claude faz um piloto com 2–3 fontes e mostra o custo antes de codificar tudo |

**Chaves de API nunca devem ser digitadas no chat.** O Claude cria um arquivo `.env` na
pasta do projeto com o campo vazio, e você cola a chave diretamente nesse arquivo.

## 5. Sigilo dos dados

Tudo o que o Claude lê sai do seu computador e vai para a Anthropic (e, no modo API, para o
provedor escolhido). Por isso o Claude pergunta antes de abrir as fontes e propõe uma
modalidade:

- **A — Nuvem:** o Claude lê as fontes. Use quando não houver dados sigilosos.
- **B — Exposição reduzida:** o Claude trabalha só com o método e com exemplos inventados;
  a codificação roda num modelo local (Ollama). **Não é um processamento inteiramente
  local.**
- **C — Local:** o Claude não participa. Para dados sob sigilo legal ou ético estrito, use
  o Synesis no VS Code com um modelo local.

## 6. Ler os seus arquivos: a visão do projeto

Você não precisa de um editor de código para ler o que o Synesis escreveu. O Claude monta uma
**visão do projeto** em `view/index.html` (dois cliques, sem internet e sem servidor) e a
atualiza sempre que arquivos são criados ou mudam.

- O **Resumo** abre com o seu projeto, as questões de pesquisa e o tamanho do corpus. A faixa
  *Validação e revisão* diz o que pede atenção; *ver detalhes* lista cada problema e leva até ele.
  A **matriz de conceitos por fonte** mostra onde cada conceito aparece: clique num conceito para
  vê-lo em foco, ou numa célula para ler os trechos daquela fonte.
- **Por onde começar** lista os próximos passos deste projeto, em ordem, com links.
- Cada bloco de cada arquivo é um **cartão** (uma fonte, um item, um conceito, um campo do
  template). As linhas do bloco (`ITEM @entrevista1` … `END ITEM`) continuam visíveis, para você
  se familiarizar com a linguagem. Cada cartão diz de onde veio (aceito numa execução, alterado
  desde a aceitação) e mostra os seus problemas em linguagem simples.
- Passe o mouse sobre uma **palavra em azul** (SCOPE, TYPE, END ITEM…), um nome de campo, um
  conceito ou uma relação: aparece uma explicação curta.
- **Pedir ao Claude** copia um pedido pronto sobre aquele bloco. Cole na conversa: o Claude
  explica e propõe, e não altera nada antes da sua aprovação.
- **Possibilidades** parte do que você quer investigar (comparar, conectar, organizar, sustentar
  uma interpretação) e mostra o recurso do Synesis que faz isso, com um pedido para adaptar.
- O que o coder acabou de escrever e você ainda não aceitou aparece em **Aguardando aceitação**.
  Leia ali antes de aceitar a execução.
- A página é só de leitura e não carrega nada da internet: para mudar algo, peça ao Claude ou
  edite o arquivo.

**Projetos grandes.** Um projeto com milhares de anotações não cabe numa página que o navegador
abra depressa. A visão passa então a trabalhar em *amplitude e profundidade*, como em Big Qual
(Weller et al., 2023): os números, a matriz (por grupo: as pastas das suas anotações, ou uma
categoria das suas fontes) e os problemas valem sempre para o projeto inteiro, mas os cartões
mostrados são uma seleção.

- **Visão panorâmica** (padrão nos projetos grandes): o template completo, uma fonte de cada um dos
  maiores grupos (no máximo oito), os conceitos mais usados e alguns raros.
- **Visão por amostragem**: cerca de 30 fontes sorteadas em todos os grupos, proporcionalmente ao
  tamanho.
- **Visão completa**, ou um grupo, uma fonte ou um conceito lido por inteiro.

O aviso no alto da página diz o que ela mostra e tem botões para pedir mais ao Claude, com o tempo
que a visão completa leva. Blocos com problema aparecem mesmo fora da seleção (até 40), marcados
*fora da seleção*; os demais continuam na lista de problemas.

## 7. Conferir uma amostra das anotações

O Claude sorteia uma amostra das anotações (30 por padrão, espalhadas pelos grupos do projeto) e
monta a página de **conferência** em `review/index.html`. Você julga uma anotação por vez:

1. Escreva seu nome ou iniciais.
2. Leia o trecho (o computador já conferiu que ele está na fonte; abra *O trecho na fonte* para ler
   em volta) e o que foi codificado: códigos, cadeias, notas, categorias.
3. Escolha **Aprovada**, **Reprovada** ou **Dúvida** (teclas 1, 2, 3). Ao reprovar ou ficar em
   dúvida, escolha um motivo e, se quiser, escreva uma nota. A *avaliação detalhada* dá uma escala de
   1 a 5 para cada campo. *Propor correção* deixa você escrever o bloco como acha que deveria ficar
   (mantenha o trecho palavra por palavra).
4. Clique em **Exportar para o coordenador**. Sai um arquivo (`.md`) com as suas respostas, as suas
   correções e instruções para a IA que vai lê-lo. **Respostas não exportadas ficam só no seu
   navegador.**

A amostra fica fixa no sorteio: você julga as anotações como estavam naquele momento, e a página
avisa se alguma mudou no projeto depois. Ela não mostra qual modelo produziu a anotação, para não
influenciar você. Ela mostra a reprovação **observada na amostra** enquanto você avança; a amostra
dá mais peso aos grupos pequenos, então o Claude informa à parte uma estimativa para o projeto
inteiro. Se muitas das primeiras 20 forem reprovadas, a página sugere parar e ajustar o template
antes.

**Em equipe.** O coordenador do projeto envia a página de conferência a cada pesquisador (ela traz
trechos das fontes: envie só a quem pode lê-los). Cada um julga no seu computador, com o seu nome;
colegas que dividem um computador começam, cada um, com a página vazia. Cada pesquisador envia o
arquivo exportado ao coordenador, que entrega todos ao Claude. O Claude os registra, informa o
quanto vocês concordam (kappa de Cohen, alfa de Krippendorff) e põe lado a lado todas as correções
propostas. Uma correção só entra no projeto quando o coordenador aprova; quando o mesmo problema se
repete, mudar o template e codificar de novo costuma ser melhor do que muitas correções à mão.

## 8. Ver os resultados

A página de resultados fica em `dashboard/dashboard.html`. Ela abre com dois cliques, sem internet
e sem servidor.

**Num projeto grande** o Claude não monta esta página: ela demoraria para ser feita e pesaria para
abrir. Ele mostra como ler os resultados com as próprias ferramentas do Synesis, o que também é um
bom jeito de aprendê-las: `synesis compile projeto.synp --xls resultados.xlsx` (uma planilha, em
segundos; também `--csv` ou `--json`), `synesis export projeto.synp` (as exportações que o seu
projeto declara), ou a extensão do Synesis para o VS Code. A visão do projeto e a conferência
continuam funcionando em qualquer tamanho. O plugin ajuda você a aprender a linguagem e a conferir
os seus dados; ele não substitui as ferramentas.

| Aba | O que mostra |
|---|---|
| **Fontes** | cada trecho codificado, com a citação, a nota e os códigos. A citação é marcada como *encontrada*, *não encontrada* ou *não verificável* no texto original |
| **Códigos** | cada código, com a definição e todas as evidências |
| **Relações**, **Questões** | as relações entre conceitos e onde estão as evidências de cada pergunta de pesquisa |
| **Conferência** | o resultado de cada conferência: aprovadas, reprovadas, dúvidas, reprovação observada na amostra e a estimativa para o projeto, motivos, correções propostas, concordância |
| **Qualidade** | o que ainda precisa de atenção |
| **Método** | o template completo e como o resultado foi produzido |

**Quando algo estiver errado,** o Claude não corrige o trecho à mão. Ele classifica o
problema com você antes de agir: instrução ambígua no template, falha pontual, texto-fonte
mal convertido ou divergência legítima de interpretação.

## 9. O que fica na pasta do projeto

| Arquivo ou pasta | Conteúdo |
|---|---|
| `*.synp` | o projeto |
| `template.synt` | o método |
| `*.bib` | as fontes bibliográficas |
| `fontes/` | os textos |
| `anotacoes/`, `ontologia/` | o resultado da codificação |
| `runs/` | o registro de cada execução: o que foi pedido ao modelo, o que ele respondeu e as decisões que você tomou |
| `view/`, `review/`, `dashboard/`, `saida/` | arquivos gerados, que podem ser refeitos a qualquer momento (as respostas da conferência ficam em `runs/` depois de importadas) |

Guarde a pasta inteira, exceto o `.env`. Com ela, qualquer pessoa reconstrói exatamente os
seus resultados e as suas páginas.

## 10. Se algo der errado

- **"comando não encontrado"** logo depois da instalação: abra uma nova sessão na aba Code.
  Na mesma sessão, o Claude usa o caminho completo das ferramentas.
- **O Windows bloqueou o instalador:** o Claude tenta outro caminho (winget). Se a máquina
  for institucional, pode ser preciso falar com o suporte de TI.
- **Dúvidas sobre a linguagem:** peça ao Claude, que consulta o guia de referência
  instalado (`synesis-help`).
- **Erros do Synesis e sugestões:** abra uma *issue* em
  <https://github.com/synesis-lang/synesis-skill>.

---

Se usar o Synesis num trabalho acadêmico, cite o software (veja o arquivo `CITATION.cff`
dos repositórios do Synesis).
