# Synesis in Claude — guide for researchers

This guide shows how to use [Synesis](https://synesis-lang.org) with the help of Claude to
organize and code your sources (interviews, articles, documents), review the result and see what
it found, in pages that open on your own computer.

You make the research decisions. Claude installs the tools, talks with you about the design of
the study, prepares the files, runs the coding and builds three pages: the **project view**, the
**review** and the **results**. A Portuguese
translation of this guide is in [pt/GUIA_DO_PESQUISADOR.md](pt/GUIA_DO_PESQUISADOR.md).

---

## 1. What you need

- **Claude Desktop** (Windows or macOS) on a paid plan with access to the **Code** tab, or
  Claude Code in a terminal or IDE.
- **A folder** on your computer for the project, with your sources:
  - interviews and documents as `.txt` or `.md`;
  - articles in a `.bib` bibliography with their abstracts.
- **Internet** the first time, to install the tools.
- **About one hour** for the first session.

You do **not** need to install Python or know how to program. VS Code is optional: it only
helps if you want to read the project files directly.

## 2. Install the plugin (once)

1. In Claude Desktop open **Customize → Plugins**, choose **Add**, and upload the
   `synesis-plugin-<version>.zip` you received.
2. If your organization does not allow uploading plugins, ask the administrator, or use the
   marketplace: in the **Code** tab, **+** → **Add plugins** → add `synesis-lang/synesis-skill`.
   In the CLI: `/plugin marketplace add synesis-lang/synesis-skill`, then
   `/plugin install synesis@synesis-lang`.
3. Claude warns you to install only plugins you trust. This is the plugin of the Synesis
   project; its source is open at <https://github.com/synesis-lang/synesis-skill>.

## 3. First session

1. Open the **Code** tab and choose the **project folder**.
2. Choose the **Manual** permission mode, so Claude asks for your approval before each
   command and you see what is going to be installed.
3. Write something like:
   > I want to code my interviews about community gardens with Synesis. Where do I put my files?

   Claude creates a folder for them and opens a page, **Your sources**, that explains the formats
   (references with abstracts, texts, records). You copy the files as they are; a script looks at
   them **on your computer**, and you decide how each kind will be used. **PDF files** have to be
   converted to `.txt` by you: the page shows how, and what to check.

Claude then, in order:
1. **Asks about confidentiality** before opening any file (§5).
2. **Installs the Synesis tools** and shows you a report. This happens once per computer.
3. **Talks about the study:** your research questions, what should be extracted from the
   sources, and whether you want free or closed categories, cause relations or scales.
4. **Writes the template**, the description of what will be coded, and shows one example
   before going on. **You approve the template.**
5. **Codes each source**, one at a time.
6. **Validates, asks you to review a sample, and builds the results page.**

When you come back to a project that already exists, Claude first measures its size (a second,
without reading your files) and offers a short numbered list of what you can do: know the
project, read it more deeply, review a sample of the annotations, see the results, find out what
the project can answer, fix problems, continue, export. Pick one or more.

Claude talks to you in the language you write in. The Synesis keywords, the tool messages and
the reference guide stay in English; Claude translates them when it relays them to you, and
writes the prose of your project (descriptions, guidelines, questions) in your language.

## 4. Costs

There are two ways to code, and Claude explains both before starting:

| Mode | Who codes | Cost |
|---|---|---|
| **Claude session (handoff)** | your own Claude subscription | covered by the subscription, within the limits of your plan |
| **API** | a model through an API key (Anthropic, OpenRouter) | billed by the provider; Claude runs a pilot with 2–3 sources and shows the cost before coding everything |

**API keys must never be typed in the chat.** Claude creates a `.env` file in the project
folder with the field empty, and you paste the key directly into that file.

## 5. Confidentiality of your data

Everything Claude reads leaves your computer and goes to Anthropic (and, in API mode, to the
chosen provider). That is why Claude asks before opening the sources and proposes a modality:

- **A — Cloud:** Claude reads the sources. Use it when there is no confidential data.
- **B — Reduced exposure:** Claude works only with the method and with invented examples;
  the coding runs on a local model (Ollama). **It is not fully local processing.**
- **C — Local:** Claude does not take part. For data under strict legal or ethical
  confidentiality, use Synesis in VS Code with a local model.

## 6. Read your files: the project view

You should not need a code editor to read what Synesis wrote. Claude builds a **project view**
at `view/index.html` (two clicks, no internet, no server) and refreshes it whenever files are
created or change.

- **Overview** opens with your project, its research questions and the size of the corpus. The
  *Validation and review* strip says what needs attention; *see details* lists each problem and
  takes you to it. The **concepts-by-source matrix** shows where each concept appears: click a
  concept to put it in focus, or a cell to read the excerpts of that source.
- **Where to start** lists the next steps for this project, in order, with links.
- Every block of every file is a **card** (a source, an item, a concept, a template field). The
  block lines (`ITEM @interview1` … `END ITEM`) stay visible, so you get used to the language.
  Each card says where it came from (accepted in a run, changed since acceptance) and shows its
  problems in plain words.
- Hover over a **word in blue** (SCOPE, TYPE, END ITEM…), a field name, a concept or a relation:
  a short explanation appears.
- **Ask Claude** copies a ready request about that block. Paste it in the conversation: Claude
  explains and proposes, and changes nothing before you approve.
- **Possibilities** starts from what you want to investigate (compare, connect, organize, support
  an interpretation) and shows the Synesis feature that does it, with a request to adapt.
- What the coder just wrote, and you have not accepted yet, is listed under **Awaiting
  acceptance**. Read it there before you accept the run.
- The page is read-only and loads nothing from the internet. To change something, ask Claude or
  edit the file itself.

**Large projects.** A project with thousands of annotations does not fit in one page that a
browser opens quickly. The view then works in *breadth and depth*, as in Big Qual (Weller et al.,
2023): the numbers, the matrix (by group: the folders of your annotations, or a category of your
sources) and the problems always cover the whole project, but the cards shown are a selection.

- **Panoramic view** (default for large projects): the template whole, one source from each of the
  largest groups (eight at most), the most used and a few rare concepts.
- **Sampled view**: about 30 sources drawn in every group, in proportion to its size.
- **Complete view**, or one group, source or concept read whole.

The banner at the top says what the page shows and has buttons to ask Claude for more, with the
time a complete view takes. Blocks with a problem appear even outside the selection (up to 40),
marked *outside the selection*; the others stay in the list of problems.

## 7. Review a sample of the annotations

Claude draws a sample of the annotations (30 by default, spread over the groups of your project)
and builds a **review** page at `review/index.html`. You judge one annotation at a time:

1. Write your name or initials.
2. Read the excerpt (the computer already checked that it is in the source; open *The excerpt in
   its source* to read around it) and what was coded: codes, chains, notes, categories.
3. Choose **Approved**, **Rejected** or **Doubt** (keys 1, 2, 3). If you reject or doubt, choose a
   reason and, if you like, write a note. *Detailed rating* gives a 1–5 scale for each field.
   *Propose a correction* lets you write the block as you think it should be (keep the excerpt word
   for word).
4. Click **Export for the coordinator**. You get one file (`.md`) with your answers, your
   corrections and instructions for the AI that will read it. **Answers that are not exported stay
   only in your browser.**

The sample is fixed when it is drawn: you judge the annotations as they were then, and the page
tells you if one changed in the project afterwards. It does not show which model produced the
annotation, so it does not sway you. It shows the rejection **observed in the sample** as you go;
the sample gives more weight to small groups, so Claude reports a separate estimate for the whole
project. If many of the first 20 are rejected, the page suggests stopping to fix the template first.

**A team.** The coordinator of the project sends the review page to each researcher (it contains
excerpts of the sources: send it only to people allowed to read them). Everyone judges on their own
computer, with their own name; colleagues sharing a computer each start with an empty page. Each
one sends their exported file to the coordinator, who gives them all to Claude. Claude records
them, says how much you agree (Cohen's kappa, Krippendorff's alpha) and puts every proposed
correction side by side. A correction enters the project only when the coordinator approves it;
when the same problem repeats, changing the template and coding again is usually better than many
corrections by hand.

## 8. See the results

The results page is at `dashboard/dashboard.html`. It opens with two clicks, without internet and
without a server.

**In a large project** Claude does not build this page: it would be slow to make and heavy to open.
It shows you how to read the results with the Synesis tools themselves, which is also a good way
to learn them: `synesis compile project.synp --xls results.xlsx` (a spreadsheet, in seconds; also
`--csv` or `--json`), `synesis export project.synp` (the exports your project declares), or the
Synesis extension for VS Code. The project view and the review keep working at any size. The plugin
helps you learn the language and check your data; it does not replace the tools.

| Tab | What it shows |
|---|---|
| **Sources** | every coded excerpt, with the quotation, the note and the codes. The quotation is marked *found*, *not found* or *unverifiable* in the original text |
| **Codes** | each code, with its definition and all its evidence |
| **Relations**, **Questions** | the relations between concepts and where the evidence for each research question is |
| **Review** | the result of each review: approved, rejected, doubt, rejection observed in the sample and the estimate for the project, reasons, proposed corrections, agreement |
| **Quality** | what still needs attention |
| **Method** | the whole template and how the result was produced |

**When something is wrong,** Claude does not fix the excerpt by hand. It classifies the
problem with you before acting: ambiguous instruction in the template, a one-off model
failure, a badly converted source text, or a legitimate difference of interpretation.

## 9. What stays in the project folder

| File or folder | Content |
|---|---|
| `*.synp` | the project |
| `template.synt` | the method |
| `*.bib` | the bibliographic sources |
| `fontes/` | the texts |
| `anotacoes/`, `ontologia/` | the result of the coding |
| `runs/` | the record of every run: what was asked of the model, what it answered and the decisions you made |
| `view/`, `review/`, `dashboard/`, `saida/` | generated files, which can be rebuilt at any time (your review answers are kept in `runs/` once imported) |

Keep the whole folder except `.env`. With it, anyone can rebuild exactly your results and your
pages.

## 10. If something goes wrong

- **"command not found"** right after the installation: open a new session in the Code tab.
  In the same session, Claude uses the full path of the tools.
- **Windows blocked the installer:** Claude tries another route (winget). On an institutional
  machine you may need to talk to IT support.
- **Questions about the language:** ask Claude, which consults the installed reference guide
  (`synesis-help`).
- **Bugs and suggestions:** open an issue at <https://github.com/synesis-lang/synesis-skill>.
  Documentation: <https://synesis-lang.org>.

---

If you use Synesis in academic work, please cite the software (see the `CITATION.cff` file in
the Synesis repositories).
